# Verification: what has been checked, and what has not

Read this before you quote any result or claim in a submission. "Checked" means a test or a person actually ran it. Anything not listed as checked is **not** verified.

## Checked by a person on the real system

Reported by the project owner using the Evaluation Lab on the real XAMPP + Python setup:

* Speech-to-text ran and was saved for Hausa, Yoruba and Igbo (tests ASR-000001 to ASR-000004), after the pipeline fix.
* Text-to-speech produced playable audio for Hausa and Yoruba. One Yoruba attempt failed with `AI_UNREACHABLE` while the service was not running, and was recorded as failed.
* Only one speech test (Igbo, ASR-000004) had a typed reference transcript, so only one WER (0.0%) exists. Verdicts without a reference are human judgement only.

## Checked by automated tests (in a separate Linux test environment)

The tests ran with Python 3.12, PHP 8.3.6 and MariaDB 10.11. Your XAMPP versions may differ.

| Area | What ran | Result |
|---|---|---|
| AI service | 27 pytest tests: authentication, error format, audio limits, no-library behaviour, ASR call shape (regression for the `generate_kwargs=None` crash), translation/voice download guard | all passed |
| PHP libraries | 114 checks against a real database: conversation flow and failures, report filters, consent exclusion, WER/summary figures, PDF and Excel building, evidence pack and manifest hashes, integrity check | all passed |
| PHP pages over HTTP | 60 checks with real file uploads: VoiceBridge steps, access control between users, authenticated audio, CSV/Excel/PDF downloads, evidence pack download, role restrictions, no PHP warnings | all passed |
| Output files | the Excel file opened in a spreadsheet library; the PDF was rendered and read | opened and read |

Limits of those tests, stated plainly:

* The AI service was replaced by a stand-in that returns canned answers. No real N-ATLaS, NLLB or MMS model ran in the tests.
* The pages were run with a simplified copy of the login and page-frame code, not your real `bootstrap.php`, `header.php` and `ai_client.php`. Those real files were read and their function names and result shapes were matched by hand.
* The browser script (`voicebridge.js`) was checked for syntax only. **It has not been run in a real browser**: microphone recording, the review box, playback and the in-page buttons are untested.
* Excel was opened with a library, not Microsoft Excel. The PDF was rendered with a standard viewer library, not every PDF reader.

## Not checked at all

* **VoiceBridge end to end on your PC**: record, recognise, confirm, translate, speak.
* **Translation**: the NLLB download and any real translation. Translation quality for Hausa, Yoruba, Igbo and English pairs is **unknown**. The N-ATLaS LLM as a translator is also unvalidated (its best prompt was not tested).
* **English speech recognition** after the fix (no English test appears in the saved results yet).
* **Igbo and English text-to-speech**: whether those voice checkpoints exist and load.
* **The Colab notebook**: it was syntax-checked and its JSON validated, but never run on Colab. The Cloudflare tunnel download address and behaviour are also unverified. The ngrok alternative in the guide is untested.
* **Exact library versions** the N-ATLaS models need. Nothing is pinned. Your machine reports Python 3.9.13, PyTorch 2.8.0 and Transformers 4.57.6; record these with your results (the Evidence pack does this automatically).
* **Whether the speech models need a forced language setting.** It is off by default (`NATLAS_FORCE_WHISPER_LANGUAGE`).
* **Performance and many-user load.**

## Model facts, as read from the Hugging Face model cards

* The four speech models (`NCAIR1/Hausa-ASR`, `Yoruba-ASR`, `Igbo-ASR`, `NigerianAccentedEnglish`) are small Whisper-based models (about 244 million parameters). They expect 16 kHz audio and handle up to 30 seconds per clip. They are gated: access needs accepted terms and a token.
* `NCAIR1/N-ATLaS` is a separate 8-billion-parameter text model, also gated. It is used only for the optional LLM translation engine and needs a GPU.
* The model terms include conditions such as attribution and limits on the number of active users. Read the current model cards yourself before wider use; this project does not interpret them for you.
* MMS-TTS voices (Meta) are published for Hausa and Yoruba; Igbo and English availability is unconfirmed. Their licence is non-commercial.

## How to read the numbers the app shows

* **WER and CER** compare the raw model output with a reference typed by an evaluator, after lower-casing and removing punctuation. They exist only for tests that have a reference. The "mean" is the average of per-clip rates.
* **Verdict and rating** are human judgements, not model measurements.
* **"Speaker edited the text"** in VoiceBridge is the share of confirmed turns where the speaker changed the recognised text. It is a practical signal of recognition errors, not a WER.
* **Translations and voices** are shown and counted but **not scored for quality**.
* **The Settings connection test** ("pass") means a model loaded and ran on one second of silence. It does not measure accuracy.
* This is a small prototype data set. Do not present it as a benchmark.

## Before you submit

1. Run an English speech test and a Translation test and a full VoiceBridge conversation in a real browser, in each language pair you will claim.
2. Type a reference transcript for every speech test you intend to report.
3. Build an Evidence pack and keep it with your submission; it lists software versions, models and file hashes.
4. Update this file with what you actually ran.
