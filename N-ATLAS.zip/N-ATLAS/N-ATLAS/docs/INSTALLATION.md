# Installation (Windows + XAMPP)

This guide matches the layout in `C:\xampp\htdocs\N-ATLAS`.

## 1. Requirements

* XAMPP (Apache, MySQL/MariaDB, PHP). The code was tested on PHP 8.3 with MariaDB 10.11; use PHP 8.1 or newer.
* PHP extensions switched on in `C:\xampp\php\php.ini`: `curl`, `mbstring`, `openssl`, `pdo_mysql`, `fileinfo`, `zip` (needed only for Excel export and the evidence pack), `intl` (optional; improves PDF text clean-up). A line starting with `;` means off; remove the `;` and restart Apache.
* Python 3.9 or newer for the AI service, and **ffmpeg** on the PATH (browser recordings are webm and need it).
* A Hugging Face account that has **accepted the terms** of the four N-ATLaS ASR models, and a read token.

## 2. Upload limits

In `php.ini` make sure `upload_max_filesize` and `post_max_size` are at least `12M`, then restart Apache. A 30-second browser recording is usually under 1 MB.

## 3. Database

1. Start Apache and MySQL in the XAMPP control panel.
2. Open `http://localhost/phpmyadmin`, **Import** `arc_nbridge/database/schema.sql`. It creates the `arc_nbridge` database. It creates no users and no passwords.
3. **Already imported an earlier version?** You do not need to import again. The Reports and Evidence pages add the one missing value (`zip` in `exports.format`) by themselves. If that fails you will see the exact SQL to run.

## 4. Web app configuration

Open `http://localhost/N-ATLAS/arc_nbridge/`. While no users exist, the app shows its setup page where you create the administrator. Secrets (the AI secret) are stored encrypted in the database using a key kept in `config.local.php`. Never share that file.

## 5. AI service (on this PC)

```
cd C:\xampp\htdocs\N-ATLAS\arc_nbridge_ai
python -m venv .venv
.venv\Scripts\activate
pip install torch            (choose the build at https://pytorch.org/get-started/locally/)
pip install -r requirements.txt
copy .env.example .env       (then edit .env)
uvicorn app:app --host 127.0.0.1 --port 8000
```

Edit `.env`: set `AI_API_SECRET` to a long random string and `HF_TOKEN` to your token. Keep `ALLOW_MODEL_DOWNLOAD=false` on a slow connection (see below).

Then in the web app, **Settings > AI service**: Backend URL `http://127.0.0.1:8000` and the same API secret. Press the connection test.

The first request for each language loads its model, which can take several minutes on a CPU. Later requests are quick.

### Translation and voice models

Translation (NLLB, about 2.5 GB) and the MMS voice models are **not downloaded automatically**. With `ALLOW_MODEL_DOWNLOAD=false` a request for a model that is not on the disk fails at once with `MODEL_NOT_DOWNLOADED` instead of silently starting a huge download. To allow it, set `ALLOW_MODEL_DOWNLOAD=true` in `.env` and restart the service. Models already in your Hugging Face cache keep working either way. The speech models are not affected by this switch.

On a slow connection, run the service on Colab instead: `docs/COLAB_SETUP.md`.

## 6. Turn things on

As the administrator, in **Settings**: set the translation engine (NLLB is the light one), choose **Text to speech > Local MMS-TTS** if you want spoken output, and review the VoiceBridge and Privacy options.

## 7. Microphone

Browsers allow the microphone only on `http://localhost` or on HTTPS. Open the site as `http://localhost/...` (not by your PC's network name or IP address).

## 8. Backups

Back up three things together: the `arc_nbridge` database (phpMyAdmin > Export), the `arc_nbridge/storage` folder (recordings and exports) and `arc_nbridge/config.local.php` (it holds the key that decrypts the stored secret).

## Tests

* AI service: `cd arc_nbridge_ai`, then `python -m pytest`.
* Details of what was and was not tested: `docs/VERIFICATION.md`.
