# Troubleshooting

The AI service writes its log to `arc_nbridge_ai/logs/ai_service.log` (secrets are removed). A failed speech inference now logs the real exception and a full traceback there. PHP errors go to `C:\xampp\apache\logs\error.log`.

## Messages you may see

| Message / code | Meaning | What to do |
|---|---|---|
| `AI_UNREACHABLE` | PHP cannot reach the Python service | Start `uvicorn`, check the Backend URL in Settings (`http://127.0.0.1:8000`), or paste the new Colab link |
| `AI_TIMEOUT` | The service took too long | The first call for a model loads it (minutes on CPU). Wait and retry, or raise the timeout in Settings |
| `UNAUTHORIZED` | The API secret in Settings does not match `AI_API_SECRET` | Make both identical, restart the service |
| `AUTH_NOT_CONFIGURED` | The service has no `AI_API_SECRET` | Set it in `arc_nbridge_ai/.env` and restart |
| `MODEL_ACCESS_DENIED` | Hugging Face refused the gated model | Accept the model terms with the account that owns `HF_TOKEN`; check the token; restart |
| `MODEL_NOT_DOWNLOADED` | A translation or voice model is not on this machine and downloads are off | Set `ALLOW_MODEL_DOWNLOAD=true` and restart (large download), or use Colab (`COLAB_SETUP.md`) |
| `MODEL_LOAD_FAILED` | The model exists but could not load | Read `ai_service.log` (memory, disk space, a wrong repository name) |
| `DEPENDENCY_MISSING` | PyTorch or Transformers is missing in the service's Python | Install them in the same virtual environment that runs `uvicorn` |
| `MODEL_DISABLED` | The language or engine is switched off in the service | Check `NATLAS_ENABLED_LANGUAGES` or `ENABLE_NATLAS_LLM` in `.env` |
| `INFERENCE_FAILED` | The speech model crashed while transcribing | Open `ai_service.log`; the exception type, message and traceback are logged |
| `AUDIO_INVALID` | The file could not be decoded | Install ffmpeg and make sure it is on the PATH; try a WAV file |
| `AUDIO_TOO_LONG` | Longer than the limit (30 s) | Record shorter clips |
| `FILE_TOO_LARGE` / `UPLOAD_FAILED` | Over the app limit or the PHP limit | Raise `upload_max_filesize` and `post_max_size` in `php.ini`, or the limit in Settings |
| `FORMAT_NOT_ALLOWED` | The audio type is not allowed | Settings > Recording > Allowed formats |
| `CONSENT_REQUIRED` | A participant has no consent on file | Participants page > Record consent |
| `TTS_DISABLED` | Voice output is off | Settings > Text to speech > Local MMS-TTS |
| `CURL_MISSING` | PHP cURL is off | Enable `extension=curl` in `php.ini`, restart Apache |
| "PHP zip extension" | Excel export and evidence pack need `zip` | Enable `extension=zip` in `php.ini`, restart Apache |

## Microphone does not work

* Use `http://localhost/...`. Browsers block the microphone on other addresses without HTTPS.
* Allow the microphone in the browser's address bar.
* Close other programs that hold the microphone.

## Speech or translation is very slow

On a CPU, loading a model takes minutes and each clip takes seconds. Keep the service running between tests. A GPU (for example on Colab) is much faster.

## "Nothing was recognised"

The recording was silent or the wrong language was chosen for the speaker. Check the language on the speaker's card and speak closer to the microphone.

## A report or export is empty

Check the filters (dates, language) and whether demo records are included. Records of participants who withdrew consent are always left out.

## Changing the AI service secret

Change `AI_API_SECRET` in `.env` (or the Colab session) **and** in Settings > AI service, then restart the service.
