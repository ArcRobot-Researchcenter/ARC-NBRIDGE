# Running the AI service on Google Colab

Use this when your own connection is too slow to download the translation model (NLLB is about 2.5 GB) or when you want a GPU. Colab downloads over its own fast connection. Your web app on XAMPP then calls Colab through a temporary HTTPS link.

Your PHP app, database and recordings stay on your PC. Only the audio clip or text being processed is sent to Colab for each request.

## One-time preparation

1. Make a zip of the `arc_nbridge_ai` folder named `arc_nbridge_ai.zip`. **Leave out** `.venv`, `.env` and `logs` (the notebook makes its own secrets).
2. In Colab open `colab/ARC_NBridge_Colab.ipynb` (File > Upload notebook).
3. Runtime > Change runtime type > pick a **GPU**.
4. In the left sidebar open **Secrets** (key icon), add `HF_TOKEN` with your Hugging Face token and switch on *Notebook access*.

## Each session

1. Run the notebook cells from the top. In step 3 upload the zip.
2. Step 7 prints a **Backend URL** (ending in `trycloudflare.com`) and an **API secret**. Both change every session.
3. In the web app, as administrator: **Settings > AI service (Python)**. Paste both, save, then press the connection test.
4. Optional: run step 9 once. It loads the translation model (downloading it on Colab) so the first conversation is quick.
5. When finished, run step 11 to stop the service and the link.

## Security notes

* The link is protected by the API secret. Anyone who has **both** the link and the secret can use the service, so do not share them or screenshots of step 7.
* The Hugging Face token stays inside Colab. It is never printed and never sent to your PC.
* The link stops working when the session ends or when you run step 11.
* Free Colab sessions have usage limits and can disconnect after a period of inactivity. If that happens, run the notebook again and paste the new link and secret.

## If the tunnel does not start

The notebook uses a Cloudflare quick tunnel (no account). If step 7 cannot find a link (for example the download from GitHub fails), use ngrok instead: create a free ngrok account, add `NGROK_TOKEN` to Colab Secrets, `pip install pyngrok`, then in a new cell:

```python
from google.colab import userdata
from pyngrok import ngrok
ngrok.set_auth_token(userdata.get("NGROK_TOKEN"))
print(ngrok.connect(8000).public_url)
```

Use that address as the Backend URL, with the same API secret. This alternative has not been run in this project; the Cloudflare route has not been run on Colab either (see `VERIFICATION.md`).

## Cost and time

Model downloads count against the Colab session, and the first request for each model loads it into memory, which takes minutes. Keep the notebook running during a test session.
