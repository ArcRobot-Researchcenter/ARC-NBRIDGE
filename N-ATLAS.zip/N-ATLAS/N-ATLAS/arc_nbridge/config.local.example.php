<?php
/**
 * Copy this file to config.local.php and edit it. setup.php will also create/extend config.local.php
 * (it adds a generated app_key). Never commit or share config.local.php.
 */
return [
    'db_host' => '127.0.0.1',
    'db_port' => 3306,
    'db_name' => 'arc_nbridge',
    'db_user' => 'root',
    'db_pass' => '',
    // 'app_key' => '',   // generated automatically by setup.php
    // 'debug'   => true, // local development only
];
