<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';

$state = setup_state();
if ($state === 'ok') {
    redirect('login.php');          // setup is a one-time page: it is closed once any user exists
}

$errors = [];
$old = ['full_name' => '', 'username' => '', 'email' => ''];
$needsKey = (app_key_bytes() === null);

if ($state === 'ready' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $old = [
        'full_name' => trim((string)($_POST['full_name'] ?? '')),
        'username'  => trim((string)($_POST['username'] ?? '')),
        'email'     => trim((string)($_POST['email'] ?? '')),
    ];
    $password = (string)($_POST['password'] ?? '');
    $confirm  = (string)($_POST['password_confirm'] ?? '');

    $nameLen = mb_strlen($old['full_name']);
    if ($nameLen < 2 || $nameLen > 120) { $errors[] = 'Full name must be 2 to 120 characters.'; }
    if (!preg_match('/^[A-Za-z0-9._-]{3,32}$/', $old['username'])) { $errors[] = 'Username must be 3 to 32 letters, numbers, dots, dashes or underscores.'; }
    if ($old['email'] !== '' && !filter_var($old['email'], FILTER_VALIDATE_EMAIL)) { $errors[] = 'That email address is not valid.'; }
    if (strlen($password) < 10) { $errors[] = 'Password must be at least 10 characters.'; }
    if ($password !== $confirm) { $errors[] = 'The two passwords do not match.'; }

    if (!$errors && $needsKey) {
        // Encryption key for stored secrets (AI API secret, TTS keys). Kept in config.local.php, never in the database.
        if (!config_local_write(['app_key' => base64_encode(random_bytes(32))])) {
            $errors[] = 'Could not write config.local.php. Make sure the arc_nbridge folder is writable, or copy '
                      . 'config.local.example.php to config.local.php and add an app_key (base64 of 32 random bytes).';
        }
    }

    if (!$errors) {
        try {
            $pdo = db();
            $pdo->beginTransaction();
            if ((int)$pdo->query('SELECT COUNT(*) FROM users FOR UPDATE')->fetchColumn() !== 0) {
                $pdo->rollBack();
                redirect('login.php');
            }
            $roleId = (int)db_value("SELECT id FROM roles WHERE name = 'admin'");
            if ($roleId === 0) {
                throw new RuntimeException('The roles table is empty. Re-import database/schema.sql.');
            }
            db_exec('INSERT INTO users (uuid, username, email, password_hash, full_name, role_id) VALUES (?,?,?,?,?,?)', [
                uuid4(), $old['username'], $old['email'] !== '' ? $old['email'] : null,
                password_hash($password, PASSWORD_DEFAULT), $old['full_name'], $roleId,
            ]);
            $newId = (int)$pdo->lastInsertId();
            $pdo->commit();
            auth_start_session($newId);
            activity('setup.admin_created', 'user', $newId);
            flash('success', 'Setup complete. You are signed in as the administrator.');
            redirect('index.php');
        } catch (PDOException $e) {
            if (db()->inTransaction()) { db()->rollBack(); }
            error_log('setup failed: ' . $e->getMessage());
            $errors[] = 'The administrator could not be saved. Check the PHP error log.';
        }
    }
}

$pageTitle = 'First-time setup';
$active = '';
require __DIR__ . '/includes/header.php';
?>
<div class="auth-wrap">
<div class="card auth-card"><div class="card-body p-4">
    <div class="brand"><span class="arc-logo"><i class="bi bi-soundwave"></i></span>
        <h1 class="h4 mt-2 mb-0">First-time setup</h1>
        <div class="text-muted small">Create the administrator account</div></div>

    <?php if ($state === 'no_database'): ?>
        <div class="alert alert-danger">
            <strong>The database is not ready.</strong>
            <ol class="mb-0 mt-2 small">
                <li>Start <b>MySQL</b> in the XAMPP control panel.</li>
                <li>Open phpMyAdmin → <b>Import</b> → choose <code>database/schema.sql</code> → Go.</li>
                <li>If your MySQL user is not <code>root</code> with an empty password, copy <code>config.local.example.php</code> to
                    <code>config.local.php</code> and enter the right details.</li>
                <li>Reload this page.</li>
            </ol>
        </div>
    <?php else: ?>
        <?php foreach ($errors as $err): ?><div class="alert alert-danger py-2"><?= e($err) ?></div><?php endforeach; ?>
        <form method="post" autocomplete="off" novalidate>
            <?= csrf_field() ?>
            <div class="mb-3"><label class="form-label" for="full_name">Full name</label>
                <input class="form-control" id="full_name" name="full_name" value="<?= e($old['full_name']) ?>" required></div>
            <div class="mb-3"><label class="form-label" for="username">Username</label>
                <input class="form-control" id="username" name="username" value="<?= e($old['username']) ?>" required></div>
            <div class="mb-3"><label class="form-label" for="email">Email <span class="text-muted">(optional)</span></label>
                <input class="form-control" type="email" id="email" name="email" value="<?= e($old['email']) ?>"></div>
            <div class="mb-3"><label class="form-label" for="password">Password</label>
                <input class="form-control" type="password" id="password" name="password" minlength="10" required>
                <div class="form-text">At least 10 characters. It is stored only as a one-way hash.</div></div>
            <div class="mb-3"><label class="form-label" for="password_confirm">Confirm password</label>
                <input class="form-control" type="password" id="password_confirm" name="password_confirm" minlength="10" required></div>
            <?php if ($needsKey): ?><div class="small text-muted mb-3"><i class="bi bi-key"></i> An encryption key for stored secrets will be generated and saved to <code>config.local.php</code>.</div><?php endif; ?>
            <button class="btn btn-arc w-100" type="submit"><i class="bi bi-check2-circle"></i> Create administrator</button>
        </form>
    <?php endif; ?>
</div></div></div>
<?php require __DIR__ . '/includes/footer.php'; ?>
