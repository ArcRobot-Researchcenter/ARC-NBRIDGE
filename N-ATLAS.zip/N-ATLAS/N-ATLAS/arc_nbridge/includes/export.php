<?php
declare(strict_types=1);

/**
 * Dependency-free export writers: CSV (UTF-8 with BOM, opens correctly in Excel), XLSX (needs the PHP zip extension) and a
 * small PDF writer (built-in Helvetica fonts only). No Composer packages are required.
 */

/** Neutralises spreadsheet formula injection: text starting with = + - @ TAB or CR is prefixed with an apostrophe. */
function export_cell($v)
{
    if ($v === null) {
        return '';
    }
    if (is_bool($v)) {
        return $v ? 1 : 0;
    }
    if (is_int($v) || is_float($v)) {
        return $v;
    }
    $s = (string)$v;
    if ($s !== '' && strpbrk($s[0], "=+-@\t\r") !== false) {
        return "'" . $s;
    }
    return $s;
}

function export_csv(array $headers, array $rows): string
{
    $fh = fopen('php://temp', 'r+');
    fwrite($fh, "\xEF\xBB\xBF");
    fputcsv($fh, array_map('export_cell', $headers), ',', '"', '\\', "\r\n");
    foreach ($rows as $row) {
        fputcsv($fh, array_map('export_cell', $row), ',', '"', '\\', "\r\n");
    }
    rewind($fh);
    $out = (string)stream_get_contents($fh);
    fclose($fh);
    return $out;
}

/* --------------------------------------------------------------------- XLSX */
function export_xml(string $s): string
{
    $s = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $s) ?? $s;
    return htmlspecialchars($s, ENT_XML1 | ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function export_xlsx_col(int $i): string
{
    $s = '';
    $n = $i + 1;
    while ($n > 0) {
        $m = ($n - 1) % 26;
        $s = chr(65 + $m) . $s;
        $n = intdiv($n - 1, 26);
    }
    return $s;
}

function export_sheet_name(string $name, array $used): string
{
    $name = trim(preg_replace('/[\[\]:*?\/\\\\]/', ' ', $name) ?? $name);
    $name = mb_substr($name === '' ? 'Sheet' : $name, 0, 31);
    $base = $name;
    $i = 2;
    while (in_array(mb_strtolower($name), array_map('mb_strtolower', $used), true)) {
        $suffix = ' ' . $i++;
        $name = mb_substr($base, 0, 31 - mb_strlen($suffix)) . $suffix;
    }
    return $name;
}

/** @param array<string, array{headers: array, rows: array}> $sheets sheet name => data. Returns the .xlsx file as a binary string. */
function export_xlsx(array $sheets): string
{
    if (!class_exists('ZipArchive')) {
        throw new RuntimeException('The PHP zip extension is not enabled. In XAMPP, enable extension=zip in php.ini and restart Apache.');
    }
    if (!$sheets) {
        throw new InvalidArgumentException('An Excel file needs at least one sheet.');
    }
    $tmp = tempnam(sys_get_temp_dir(), 'arcx');
    $zip = new ZipArchive();
    if ($zip->open($tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        throw new RuntimeException('Could not create the Excel file.');
    }
    $ns = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
    $head = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n";
    $names = [];
    $sheetXml = [];
    foreach ($sheets as $title => $data) {
        $names[] = export_sheet_name((string)$title, $names);
        $headers = array_values($data['headers']);
        $widths = [];
        foreach ($headers as $c => $h) {
            $widths[$c] = min(60, max(10, mb_strlen((string)$h) + 2));
        }
        $rowsXml = '<row r="1">';
        foreach ($headers as $c => $h) {
            $rowsXml .= '<c r="' . export_xlsx_col($c) . '1" s="1" t="inlineStr"><is><t xml:space="preserve">' . export_xml((string)$h) . '</t></is></c>';
        }
        $rowsXml .= '</row>';
        $r = 2;
        foreach ($data['rows'] as $row) {
            $rowsXml .= '<row r="' . $r . '">';
            foreach (array_values($row) as $c => $v) {
                $v = export_cell($v);
                $ref = export_xlsx_col($c) . $r;
                if (is_int($v) || is_float($v)) {
                    $num = is_int($v) ? (string)$v : rtrim(rtrim(sprintf('%.6F', $v), '0'), '.');
                    $rowsXml .= '<c r="' . $ref . '"><v>' . $num . '</v></c>';
                } elseif ($v !== '') {
                    $text = mb_substr((string)$v, 0, 32000);
                    $widths[$c] = min(60, max($widths[$c] ?? 10, mb_strlen($text) + 2));
                    $rowsXml .= '<c r="' . $ref . '" t="inlineStr"><is><t xml:space="preserve">' . export_xml($text) . '</t></is></c>';
                }
            }
            $rowsXml .= '</row>';
            $r++;
        }
        $cols = '<cols>';
        foreach ($widths as $c => $w) {
            $cols .= '<col min="' . ($c + 1) . '" max="' . ($c + 1) . '" width="' . $w . '" customWidth="1"/>';
        }
        $cols .= '</cols>';
        $sheetXml[] = $head . '<worksheet xmlns="' . $ns . '"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
            . $cols . '<sheetData>' . $rowsXml . '</sheetData></worksheet>';
    }
    $types = '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
           . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>';
    $wbSheets = '';
    $wbRels = '';
    foreach ($names as $i => $n) {
        $k = $i + 1;
        $types .= '<Override PartName="/xl/worksheets/sheet' . $k . '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
        $wbSheets .= '<sheet name="' . export_xml($n) . '" sheetId="' . $k . '" r:id="rId' . $k . '"/>';
        $wbRels .= '<Relationship Id="rId' . $k . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' . $k . '.xml"/>';
        $zip->addFromString('xl/worksheets/sheet' . $k . '.xml', $sheetXml[$i]);
    }
    $wbRels .= '<Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>';
    $zip->addFromString('[Content_Types].xml', $head . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>' . $types . '</Types>');
    $zip->addFromString('_rels/.rels', $head . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
    $zip->addFromString('xl/workbook.xml', $head . '<workbook xmlns="' . $ns . '" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>' . $wbSheets . '</sheets></workbook>');
    $zip->addFromString('xl/_rels/workbook.xml.rels', $head . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' . $wbRels . '</Relationships>');
    $zip->addFromString('xl/styles.xml', $head . '<styleSheet xmlns="' . $ns . '"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts>'
        . '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFD9EFE4"/><bgColor indexed="64"/></patternFill></fill></fills>'
        . '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
        . '<cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/></cellXfs>'
        . '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>');
    if (!$zip->close()) {
        @unlink($tmp);
        throw new RuntimeException('Could not finish the Excel file.');
    }
    $bin = (string)file_get_contents($tmp);
    @unlink($tmp);
    return $bin;
}

/* ---------------------------------------------------------------------- PDF */
/**
 * Minimal single-purpose PDF writer: A4, Helvetica / Helvetica-Bold (WinAnsi), rectangles, lines and text.
 * y coordinates are measured from the TOP of the page. Built-in fonts cannot show Hausa hooked letters or Yoruba tone
 * marks, so text goes through ascii() which removes combining marks and maps hooked letters to plain ones.
 * Exact text is always in the CSV / Excel exports.
 */
final class SimplePdf
{
    public const W = 595.28;
    public const H = 841.89;
    private const WIDTHS = [32 => 278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556,
        278, 278, 584, 584, 584, 556, 1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611,
        278, 278, 278, 469, 556, 333, 556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556, 556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584];

    /** @var string[] */
    private array $pages = [];
    private int $cur = -1;

    public function __construct()
    {
        $this->addPage();
    }

    public function addPage(): void
    {
        $this->pages[] = '';
        $this->cur = count($this->pages) - 1;
    }

    public function pageCount(): int
    {
        return count($this->pages);
    }

    /** Switches drawing to an existing page (0-based), e.g. to add "page X of Y" footers at the end. */
    public function setPage(int $index): void
    {
        if ($index >= 0 && $index < count($this->pages)) {
            $this->cur = $index;
        }
    }

    public static function ascii(string $s): string
    {
        $map = ['ɓ' => 'b', 'Ɓ' => 'B', 'ɗ' => 'd', 'Ɗ' => 'D', 'ƙ' => 'k', 'Ƙ' => 'K', 'ƴ' => 'y', 'Ƴ' => 'Y', 'ʼ' => "'", '’' => "'", '‘' => "'",
                '“' => '"', '”' => '"', '–' => '-', '—' => '-', '…' => '...', '→' => '->', '≥' => '>=', '≤' => '<=', '×' => 'x'];
        if (class_exists('Normalizer')) {
            $d = Normalizer::normalize($s, Normalizer::FORM_D);
            if ($d !== false) {
                $s = $d;
            }
        }
        $s = preg_replace('/\p{Mn}+/u', '', $s) ?? $s;
        $s = strtr($s, $map);
        $s = preg_replace('/[^\x20-\x7E\x{A0}-\x{FF}]/u', '?', $s) ?? $s;
        return $s;
    }

    private static function enc(string $s): string
    {
        $s = self::ascii($s);
        $s = function_exists('mb_convert_encoding') ? mb_convert_encoding($s, 'Windows-1252', 'UTF-8') : utf8_decode($s);
        return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $s);
    }

    public static function width(string $s, float $size, bool $bold = false): float
    {
        $w = 0;
        foreach (preg_split('//u', self::ascii($s), -1, PREG_SPLIT_NO_EMPTY) ?: [] as $ch) {
            $o = strlen($ch) === 1 ? ord($ch) : 0;
            $w += self::WIDTHS[$o] ?? 556;
        }
        return $w / 1000 * $size * ($bold ? 1.07 : 1.0);
    }

    /** Shortens text with an ellipsis so it fits in $maxWidth points. */
    public static function fit(string $s, float $maxWidth, float $size, bool $bold = false): string
    {
        $s = self::ascii($s);
        if (self::width($s, $size, $bold) <= $maxWidth) {
            return $s;
        }
        while ($s !== '' && self::width($s . '...', $size, $bold) > $maxWidth) {
            $s = mb_substr($s, 0, -1);
        }
        return rtrim($s) . '...';
    }

    /** @return string[] */
    public static function wrap(string $s, float $maxWidth, float $size, bool $bold = false): array
    {
        $lines = [];
        foreach (preg_split('/\R/u', self::ascii($s)) ?: [''] as $para) {
            $line = '';
            foreach (preg_split('/\s+/u', trim($para), -1, PREG_SPLIT_NO_EMPTY) ?: [] as $word) {
                $try = $line === '' ? $word : $line . ' ' . $word;
                if ($line !== '' && self::width($try, $size, $bold) > $maxWidth) {
                    $lines[] = $line;
                    $line = $word;
                } else {
                    $line = $try;
                }
            }
            $lines[] = $line;
        }
        return $lines;
    }

    public function text(float $x, float $yTop, string $s, float $size = 10, bool $bold = false, array $rgb = [0.09, 0.19, 0.16]): void
    {
        $this->pages[$this->cur] .= sprintf("BT /%s %.2F Tf %.3F %.3F %.3F rg %.2F %.2F Td (%s) Tj ET\n",
            $bold ? 'F2' : 'F1', $size, $rgb[0], $rgb[1], $rgb[2], $x, self::H - $yTop, self::enc($s));
    }

    public function rect(float $x, float $yTop, float $w, float $h, array $rgb): void
    {
        $this->pages[$this->cur] .= sprintf("q %.3F %.3F %.3F rg %.2F %.2F %.2F %.2F re f Q\n", $rgb[0], $rgb[1], $rgb[2], $x, self::H - $yTop - $h, $w, $h);
    }

    public function line(float $x1, float $y1, float $x2, float $y2, array $rgb = [0.8, 0.85, 0.83], float $width = 0.5): void
    {
        $this->pages[$this->cur] .= sprintf("q %.3F %.3F %.3F RG %.2F w %.2F %.2F m %.2F %.2F l S Q\n", $rgb[0], $rgb[1], $rgb[2], $width,
            $x1, self::H - $y1, $x2, self::H - $y2);
    }

    public function output(string $title = ''): string
    {
        $n = count($this->pages);
        $objs = [];
        $objs[1] = '<< /Type /Catalog /Pages 2 0 R >>';
        $kids = [];
        for ($i = 0; $i < $n; $i++) {
            $kids[] = (6 + 2 * $i) . ' 0 R';
        }
        $objs[2] = '<< /Type /Pages /Kids [' . implode(' ', $kids) . '] /Count ' . $n . ' >>';
        $objs[3] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
        $objs[4] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
        $objs[5] = '<< /Title (' . self::enc($title) . ') /Producer (ARC N-BRIDGE) >>';
        foreach ($this->pages as $i => $content) {
            $page = 6 + 2 * $i;
            $objs[$page] = sprintf('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %.2F %.2F] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents %d 0 R >>',
                self::W, self::H, $page + 1);
            $objs[$page + 1] = '<< /Length ' . strlen($content) . " >>\nstream\n" . $content . "endstream";
        }
        $out = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
        $offsets = [];
        foreach ($objs as $num => $body) {
            $offsets[$num] = strlen($out);
            $out .= $num . " 0 obj\n" . $body . "\nendobj\n";
        }
        $xref = strlen($out);
        $count = count($objs) + 1;
        $out .= "xref\n0 $count\n0000000000 65535 f \n";
        foreach ($offsets as $off) {
            $out .= sprintf("%010d 00000 n \n", $off);
        }
        $out .= "trailer\n<< /Size $count /Root 1 0 R /Info 5 0 R >>\nstartxref\n$xref\n%%EOF\n";
        return $out;
    }
}
