<?php
/** Page chrome. Set $pageTitle and $active before requiring this file. */
$user = current_user();
$pageTitle = $pageTitle ?? 'ARC N-BRIDGE';
$active = $active ?? '';
$appName = (string)setting('app.name', 'ARC N-BRIDGE');
$nav = [
    ['dashboard', 'index.php', 'bi-speedometer2', 'Dashboard', ['admin', 'researcher', 'participant']],
    ['lab', 'evaluation_lab.php', 'bi-mic', 'Evaluation Lab', ['admin', 'researcher']],
    ['voicebridge', 'voicebridge.php', 'bi-chat-dots', 'VoiceBridge', ['admin', 'researcher', 'participant']],
    ['participants', 'participants.php', 'bi-people', 'Participants', ['admin', 'researcher']],
    ['reports', 'reports.php', 'bi-file-earmark-bar-graph', 'Reports', ['admin', 'researcher']],
    ['evidence', 'evidence.php', 'bi-archive', 'Evidence', ['admin', 'researcher']],
    ['settings', 'settings.php', 'bi-sliders', 'Settings', ['admin']],
];
?><!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($pageTitle) ?> · <?= e($appName) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= e(url('assets/css/app.css')) ?>" rel="stylesheet">
</head>
<body class="app-body">
<nav class="navbar navbar-expand-lg navbar-dark arc-nav">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?= e(url('index.php')) ?>">
            <span class="arc-logo"><i class="bi bi-soundwave"></i></span> <?= e($appName) ?>
        </a>
        <?php if ($user): ?>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav"
                aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <?php foreach ($nav as [$key, $href, $icon, $label, $roles]): if (!in_array($user['role'], $roles, true)) { continue; } ?>
                    <li class="nav-item">
                        <a class="nav-link <?= $active === $key ? 'active' : '' ?>" href="<?= e(url($href)) ?>"><i class="bi <?= e($icon) ?>"></i> <?= e($label) ?></a>
                    </li>
                <?php endforeach; ?>
            </ul>
            <div class="dropdown">
                <a class="nav-link dropdown-toggle text-white" href="#" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="bi bi-person-circle"></i> <?= e($user['full_name']) ?>
                    <span class="badge text-bg-light ms-1"><?= e($user['role_label']) ?></span>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><span class="dropdown-item-text small text-muted">Signed in as <?= e($user['username']) ?></span></li>
                    <li><hr class="dropdown-divider"></li>
                    <li>
                        <form method="post" action="<?= e(url('logout.php')) ?>" class="px-3">
                            <?= csrf_field() ?>
                            <button class="btn btn-sm btn-outline-secondary w-100" type="submit"><i class="bi bi-box-arrow-right"></i> Sign out</button>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
        <?php endif; ?>
    </div>
</nav>
<main class="container py-4">
<?php foreach (flash_pull() as $f): ?>
    <div class="alert alert-<?= e($f['type']) ?> alert-dismissible fade show" role="alert">
        <?= e($f['message']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endforeach; ?>
