<?php
declare(strict_types=1);

/**
 * Report and export data layer. Every figure comes from the database; nothing is estimated or invented.
 * Demo records are excluded unless asked for. Records tied to a participant whose consent was withdrawn are always excluded.
 */

const REPORT_ROW_CAP = 50000;
const REPORT_DATASETS = [
    'asr'           => 'Speech-to-text tests',
    'translations'  => 'Translations',
    'tts'           => 'Text-to-speech outputs',
    'conversations' => 'VoiceBridge conversation turns',
    'participants'  => 'Participants (no names, no notes)',
];

function report_date($v): string
{
    $v = (string)$v;
    $d = DateTime::createFromFormat('!Y-m-d', $v);
    return ($d && $d->format('Y-m-d') === $v) ? $v : '';
}

function report_filters(array $in): array
{
    $from = report_date($in['date_from'] ?? '');
    $to = report_date($in['date_to'] ?? '');
    if ($from !== '' && $to !== '' && $from > $to) {
        [$from, $to] = [$to, $from];
    }
    $lang = (string)($in['language'] ?? '');
    return ['date_from' => $from, 'date_to' => $to, 'language' => isset(LANGS[$lang]) ? $lang : '', 'include_demo' => !empty($in['include_demo'])];
}

/** @return array{0:string,1:array} SQL conditions (joined with AND) and their parameters */
function report_where(array $f, string $dateCol, string $demoCol, array $langCols = []): array
{
    $c = ['1=1'];
    $p = [];
    if (!$f['include_demo']) {
        $c[] = "$demoCol = 0";
    }
    if ($f['date_from'] !== '') {
        $c[] = "$dateCol >= ?";
        $p[] = $f['date_from'] . ' 00:00:00';
    }
    if ($f['date_to'] !== '') {
        $c[] = "$dateCol < ?";
        $p[] = date('Y-m-d', strtotime($f['date_to'] . ' +1 day')) . ' 00:00:00';
    }
    if ($f['language'] !== '' && $langCols) {
        $c[] = '(' . implode(' OR ', array_map(function ($col) { return "$col = ?"; }, $langCols)) . ')';
        foreach ($langCols as $_) {
            $p[] = $f['language'];
        }
    }
    return [implode(' AND ', $c), $p];
}

/** SQL: no withdrawn participant is linked to the conversation turn identified by $turnIdExpr. */
function report_turn_consent_clause(string $turnIdExpr): string
{
    return "NOT EXISTS (SELECT 1 FROM conversation_turns ctx JOIN conversations cvx ON cvx.id = ctx.conversation_id
            JOIN participants pwx ON pwx.id IN (cvx.person_a_part_id, cvx.person_b_part_id)
            WHERE ctx.id = $turnIdExpr AND pwx.consent_status = 'withdrawn')";
}

function report_participant_consent_clause(string $participantIdExpr): string
{
    return "NOT EXISTS (SELECT 1 FROM participants pwy WHERE pwy.id = $participantIdExpr AND pwy.consent_status = 'withdrawn')";
}

function report_num($v, bool $int = false)
{
    if ($v === null || $v === '') {
        return null;
    }
    return $int ? (int)$v : (float)$v;
}

function report_lang_label(?string $code): string
{
    return $code === null ? '' : (LANGS[$code] ?? $code);
}

/** @return array{title:string, headers:array, rows:array, truncated:bool} */
function report_dataset(string $key, array $f): array
{
    if (!isset(REPORT_DATASETS[$key])) {
        throw new InvalidArgumentException('Unknown dataset.');
    }
    $limit = REPORT_ROW_CAP + 1;
    switch ($key) {
        case 'asr':
            [$w, $p] = report_where($f, 'a.created_at', 'a.is_demo', ['a.language_code']);
            $sql = "SELECT a.test_code, a.created_at, a.language_code, a.source, p.code AS participant_code, a.model_repo, a.audio_duration_sec,
                           a.audio_sha256, a.natlas_text, a.reference_text, a.corrected_text, a.verdict, a.rating, a.wer, a.cer,
                           a.ai_time_ms, a.roundtrip_ms, a.status, a.comments, a.is_demo
                    FROM asr_tests a LEFT JOIN participants p ON p.id = a.participant_id
                    WHERE $w AND " . report_participant_consent_clause('a.participant_id') . " ORDER BY a.id LIMIT $limit";
            $headers = ['Test code', 'Created', 'Language code', 'Language', 'Source', 'Participant', 'Model', 'Audio seconds', 'Audio SHA-256',
                        'Model output (raw)', 'Reference transcript', 'Corrected text', 'Verdict', 'Rating', 'WER', 'CER',
                        'Model ms', 'Round trip ms', 'Status', 'Comments', 'Demo'];
            $map = function (array $r): array {
                return [$r['test_code'], $r['created_at'], $r['language_code'], report_lang_label($r['language_code']), $r['source'], $r['participant_code'],
                        $r['model_repo'], report_num($r['audio_duration_sec']), $r['audio_sha256'], $r['natlas_text'], $r['reference_text'],
                        $r['corrected_text'], $r['verdict'], report_num($r['rating'], true), report_num($r['wer']), report_num($r['cer']),
                        report_num($r['ai_time_ms'], true), report_num($r['roundtrip_ms'], true), $r['status'], $r['comments'], (int)$r['is_demo']];
            };
            break;

        case 'translations':
            [$w, $p] = report_where($f, 't.created_at', 't.is_demo', ['t.source_lang', 't.target_lang']);
            $sql = "SELECT t.id, t.created_at, t.source_lang, t.target_lang, t.mode, t.provider, t.model, t.source_text, t.translated_text,
                           t.pivot_text, t.processing_ms, t.status, t.error_code, t.turn_id, t.is_demo
                    FROM translations t WHERE $w AND " . report_turn_consent_clause('t.turn_id') . " ORDER BY t.id LIMIT $limit";
            $headers = ['ID', 'Created', 'From code', 'From', 'To code', 'To', 'Route', 'Engine', 'Model', 'Source text', 'Translation',
                        'English in between', 'Model ms', 'Status', 'Error code', 'VoiceBridge turn ID', 'Demo'];
            $map = function (array $r): array {
                return [(int)$r['id'], $r['created_at'], $r['source_lang'], report_lang_label($r['source_lang']), $r['target_lang'],
                        report_lang_label($r['target_lang']), $r['mode'], $r['provider'], $r['model'], $r['source_text'], $r['translated_text'],
                        $r['pivot_text'], report_num($r['processing_ms'], true), $r['status'], $r['error_code'], report_num($r['turn_id'], true), (int)$r['is_demo']];
            };
            break;

        case 'tts':
            [$w, $p] = report_where($f, 'o.created_at', 'o.is_demo', ['o.language_code']);
            $sql = "SELECT o.id, o.created_at, o.language_code, o.provider, o.model, o.status, o.error_code, o.processing_ms, o.turn_id, o.is_demo
                    FROM tts_outputs o WHERE $w AND " . report_turn_consent_clause('o.turn_id') . " ORDER BY o.id LIMIT $limit";
            $headers = ['ID', 'Created', 'Language code', 'Language', 'Provider', 'Model', 'Status', 'Error code', 'Model ms', 'VoiceBridge turn ID', 'Demo'];
            $map = function (array $r): array {
                return [(int)$r['id'], $r['created_at'], $r['language_code'], report_lang_label($r['language_code']), $r['provider'], $r['model'],
                        $r['status'], $r['error_code'], report_num($r['processing_ms'], true), report_num($r['turn_id'], true), (int)$r['is_demo']];
            };
            break;

        case 'conversations':
            [$w, $p] = report_where($f, 'ct.created_at', 'ct.is_demo', ['ct.source_lang', 'ct.target_lang']);
            $sql = "SELECT cv.conv_code, ct.turn_no, ct.speaker, ct.created_at, ct.source_lang, ct.target_lang, ct.asr_model, ct.asr_text, ct.confirmed_text,
                           ct.was_edited, ct.asr_ms, ct.status, tr.mode AS tr_mode, tr.translated_text, tr.status AS tr_status, tr.processing_ms AS tr_ms,
                           tt.status AS tts_status, tt.processing_ms AS tts_ms, ct.is_demo
                    FROM conversation_turns ct JOIN conversations cv ON cv.id = ct.conversation_id
                    LEFT JOIN translations tr ON tr.id = (SELECT MAX(t2.id) FROM translations t2 WHERE t2.turn_id = ct.id)
                    LEFT JOIN tts_outputs tt ON tt.id = (SELECT MAX(o2.id) FROM tts_outputs o2 WHERE o2.turn_id = ct.id)
                    WHERE $w AND " . report_turn_consent_clause('ct.id') . " ORDER BY cv.id, ct.turn_no LIMIT $limit";
            $headers = ['Conversation', 'Turn', 'Speaker', 'Created', 'Spoken language code', 'Spoken language', 'Heard by code', 'Heard by', 'Speech model',
                        'Model output (raw)', 'Text confirmed by speaker', 'Speaker edited the text', 'Speech ms', 'Turn status', 'Translation route',
                        'Translation', 'Translation status', 'Translation ms', 'Voice output status', 'Voice ms', 'Demo'];
            $map = function (array $r): array {
                return [$r['conv_code'], (int)$r['turn_no'], $r['speaker'], $r['created_at'], $r['source_lang'], report_lang_label($r['source_lang']),
                        $r['target_lang'], report_lang_label($r['target_lang']), $r['asr_model'], $r['asr_text'], $r['confirmed_text'],
                        (int)$r['was_edited'] === 1 ? 'yes' : 'no', report_num($r['asr_ms'], true), $r['status'], $r['tr_mode'], $r['translated_text'],
                        $r['tr_status'], report_num($r['tr_ms'], true), $r['tts_status'], report_num($r['tts_ms'], true), (int)$r['is_demo']];
            };
            break;

        default: // participants
            [$w, $p] = report_where($f, 'pt.created_at', 'pt.is_demo', ['pt.language_code']);
            $sql = "SELECT pt.code, pt.created_at, pt.language_code, pt.age_group, pt.gender, pt.consent_status, pt.is_demo
                    FROM participants pt WHERE $w ORDER BY pt.id LIMIT $limit";
            $headers = ['Participant', 'Created', 'Language code', 'Language', 'Age group', 'Gender', 'Consent', 'Demo'];
            $map = function (array $r): array {
                return [$r['code'], $r['created_at'], $r['language_code'], report_lang_label($r['language_code']), $r['age_group'], $r['gender'],
                        $r['consent_status'], (int)$r['is_demo']];
            };
    }
    $rows = [];
    foreach (db_all($sql, $p) as $r) {
        $rows[] = $map($r);
    }
    $truncated = count($rows) > REPORT_ROW_CAP;
    if ($truncated) {
        array_pop($rows);
    }
    return ['title' => REPORT_DATASETS[$key], 'headers' => $headers, 'rows' => $rows, 'truncated' => $truncated];
}

/** Row count for a dataset under the filters (shown next to each download button). */
function report_dataset_count(string $key, array $f): int
{
    switch ($key) {
        case 'asr':
            [$w, $p] = report_where($f, 'a.created_at', 'a.is_demo', ['a.language_code']);
            return (int)db_value("SELECT COUNT(*) FROM asr_tests a WHERE $w AND " . report_participant_consent_clause('a.participant_id'), $p);
        case 'translations':
            [$w, $p] = report_where($f, 't.created_at', 't.is_demo', ['t.source_lang', 't.target_lang']);
            return (int)db_value("SELECT COUNT(*) FROM translations t WHERE $w AND " . report_turn_consent_clause('t.turn_id'), $p);
        case 'tts':
            [$w, $p] = report_where($f, 'o.created_at', 'o.is_demo', ['o.language_code']);
            return (int)db_value("SELECT COUNT(*) FROM tts_outputs o WHERE $w AND " . report_turn_consent_clause('o.turn_id'), $p);
        case 'conversations':
            [$w, $p] = report_where($f, 'ct.created_at', 'ct.is_demo', ['ct.source_lang', 'ct.target_lang']);
            return (int)db_value("SELECT COUNT(*) FROM conversation_turns ct WHERE $w AND " . report_turn_consent_clause('ct.id'), $p);
        default:
            [$w, $p] = report_where($f, 'pt.created_at', 'pt.is_demo', ['pt.language_code']);
            return (int)db_value("SELECT COUNT(*) FROM participants pt WHERE $w", $p);
    }
}

function report_summary(array $f): array
{
    $out = ['filters' => $f];

    // ---- speech to text
    [$w, $p] = report_where($f, 'a.created_at', 'a.is_demo', ['a.language_code']);
    $rows = db_all("SELECT a.language_code, COUNT(*) AS total, SUM(a.status = 'evaluated') AS evaluated, COUNT(a.wer) AS with_ref,
                           SUM(a.verdict = 'correct') AS correct, SUM(a.verdict = 'partial') AS partial, SUM(a.verdict = 'incorrect') AS incorrect,
                           AVG(a.wer) AS mean_wer, AVG(a.cer) AS mean_cer, AVG(a.rating) AS mean_rating, AVG(a.ai_time_ms) AS mean_ms
                    FROM asr_tests a WHERE $w AND " . report_participant_consent_clause('a.participant_id') . ' GROUP BY a.language_code', $p);
    $asr = [];
    foreach ($rows as $r) {
        $asr[$r['language_code']] = ['total' => (int)$r['total'], 'evaluated' => (int)$r['evaluated'], 'with_reference' => (int)$r['with_ref'],
            'correct' => (int)$r['correct'], 'partial' => (int)$r['partial'], 'incorrect' => (int)$r['incorrect'],
            'mean_wer' => report_num($r['mean_wer']), 'mean_cer' => report_num($r['mean_cer']), 'mean_rating' => report_num($r['mean_rating']),
            'mean_ms' => report_num($r['mean_ms'])];
    }
    $out['asr_by_language'] = $asr;

    // ---- translation
    [$w, $p] = report_where($f, 't.created_at', 't.is_demo', ['t.source_lang', 't.target_lang']);
    $rows = db_all("SELECT t.source_lang, t.target_lang, COUNT(*) AS total, SUM(t.status = 'ok') AS ok_n, SUM(t.status = 'failed') AS failed_n,
                           SUM(t.status = 'ok' AND t.mode = 'direct') AS direct_n, SUM(t.status = 'ok' AND t.mode = 'pivot') AS pivot_n,
                           AVG(CASE WHEN t.status = 'ok' THEN t.processing_ms END) AS mean_ms
                    FROM translations t WHERE $w AND " . report_turn_consent_clause('t.turn_id') . ' GROUP BY t.source_lang, t.target_lang ORDER BY t.source_lang, t.target_lang', $p);
    $out['translation_by_pair'] = array_map(function ($r) {
        return ['source' => $r['source_lang'], 'target' => $r['target_lang'], 'total' => (int)$r['total'], 'ok' => (int)$r['ok_n'], 'failed' => (int)$r['failed_n'],
                'direct' => (int)$r['direct_n'], 'pivot' => (int)$r['pivot_n'], 'mean_ms' => report_num($r['mean_ms'])];
    }, $rows);

    // ---- text to speech
    [$w, $p] = report_where($f, 'o.created_at', 'o.is_demo', ['o.language_code']);
    $rows = db_all("SELECT o.language_code, SUM(o.status = 'ok') AS ok_n, SUM(o.status = 'failed') AS failed_n, SUM(o.status = 'unavailable') AS unavailable_n
                    FROM tts_outputs o WHERE $w AND " . report_turn_consent_clause('o.turn_id') . ' GROUP BY o.language_code', $p);
    $tts = [];
    foreach ($rows as $r) {
        $tts[$r['language_code']] = ['ok' => (int)$r['ok_n'], 'failed' => (int)$r['failed_n'], 'unavailable' => (int)$r['unavailable_n']];
    }
    $out['tts_by_language'] = $tts;

    // ---- VoiceBridge turns
    [$w, $p] = report_where($f, 'ct.created_at', 'ct.is_demo', ['ct.source_lang', 'ct.target_lang']);
    $t = db_row("SELECT COUNT(*) AS total, SUM(ct.confirmed_at IS NOT NULL) AS confirmed, SUM(ct.was_edited) AS edited,
                        SUM(ct.status IN ('translated','spoken')) AS translated, SUM(ct.status = 'spoken') AS spoken, SUM(ct.status = 'failed') AS failed,
                        COUNT(DISTINCT ct.conversation_id) AS conversations
                 FROM conversation_turns ct WHERE $w AND " . report_turn_consent_clause('ct.id'), $p) ?: [];
    $confirmed = (int)($t['confirmed'] ?? 0);
    $out['turns'] = ['total' => (int)($t['total'] ?? 0), 'confirmed' => $confirmed, 'edited' => (int)($t['edited'] ?? 0),
        'edited_share' => $confirmed > 0 ? round((int)$t['edited'] / $confirmed, 4) : null, 'translated' => (int)($t['translated'] ?? 0),
        'spoken' => (int)($t['spoken'] ?? 0), 'failed' => (int)($t['failed'] ?? 0), 'conversations' => (int)($t['conversations'] ?? 0)];

    // ---- participants
    [$w, $p] = report_where($f, 'pt.created_at', 'pt.is_demo', ['pt.language_code']);
    $out['participants'] = (int)db_value("SELECT COUNT(*) FROM participants pt WHERE $w AND pt.consent_status = 'granted'", $p);

    // ---- models actually used (from the stored records)
    [$w, $p] = report_where($f, 'a.created_at', 'a.is_demo', ['a.language_code']);
    $asrModels = array_column(db_all("SELECT DISTINCT a.model_repo FROM asr_tests a WHERE $w AND a.model_repo IS NOT NULL AND " . report_participant_consent_clause('a.participant_id') . " ORDER BY 1", $p), 'model_repo');
    [$w, $p] = report_where($f, 't.created_at', 't.is_demo', ['t.source_lang', 't.target_lang']);
    $trModels = array_column(db_all("SELECT DISTINCT t.model FROM translations t WHERE $w AND t.status = 'ok' AND t.model IS NOT NULL AND " . report_turn_consent_clause('t.turn_id') . " ORDER BY 1", $p), 'model');
    [$w, $p] = report_where($f, 'o.created_at', 'o.is_demo', ['o.language_code']);
    $ttsModels = array_column(db_all("SELECT DISTINCT o.model FROM tts_outputs o WHERE $w AND o.status = 'ok' AND o.model IS NOT NULL AND " . report_turn_consent_clause('o.turn_id') . " ORDER BY 1", $p), 'model');
    $out['models'] = ['asr' => $asrModels, 'translation' => $trModels, 'tts' => $ttsModels];

    // ---- date range of the records included
    $first = $last = null;
    foreach ([['asr_tests', 'a'], ['translations', 't'], ['conversation_turns', 'ct']] as [$tbl, $al]) {
        [$w, $p] = report_where($f, "$al.created_at", "$al.is_demo", $tbl === 'asr_tests' ? ["$al.language_code"] : ["$al.source_lang", "$al.target_lang"]);
        $consent = $tbl === 'asr_tests' ? report_participant_consent_clause("$al.participant_id")
            : report_turn_consent_clause($tbl === 'translations' ? "$al.turn_id" : "$al.id");
        $r = db_row("SELECT MIN($al.created_at) AS a, MAX($al.created_at) AS b FROM $tbl $al WHERE $w AND $consent", $p);
        if ($r && $r['a'] !== null) {
            $first = $first === null || $r['a'] < $first ? $r['a'] : $first;
            $last = $last === null || $r['b'] > $last ? $r['b'] : $last;
        }
    }
    $out['date_range'] = ['first' => $first, 'last' => $last];
    return $out;
}

/** Up to $n evaluated ASR tests that have a reference transcript, for the PDF appendix. */
function report_asr_examples(array $f, int $n = 15): array
{
    [$w, $p] = report_where($f, 'a.created_at', 'a.is_demo', ['a.language_code']);
    return db_all("SELECT a.test_code, a.language_code, a.verdict, a.wer, a.reference_text, a.natlas_text FROM asr_tests a
                   WHERE $w AND a.status = 'evaluated' AND a.reference_text IS NOT NULL AND " . report_participant_consent_clause('a.participant_id') . '
                   ORDER BY a.id DESC LIMIT ' . (int)$n, $p);
}
