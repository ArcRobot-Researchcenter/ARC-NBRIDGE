<?php
declare(strict_types=1);

const AUTH_MAX_FAILS = 5;
const AUTH_LOCK_MINUTES = 15;

function current_user(bool $refresh = false): ?array
{
    static $user = false;
    if ($refresh) {
        $user = false;
    }
    if ($user === false) {
        $user = null;
        if (!empty($_SESSION['uid'])) {
            try {
                $row = db_row('SELECT u.id, u.username, u.full_name, u.email, u.is_active, r.name AS role, r.label AS role_label
                               FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = ?', [(int)$_SESSION['uid']]);
                $user = ($row && (int)$row['is_active'] === 1) ? $row : null;
            } catch (Throwable $e) {
                $user = null;
            }
            if ($user === null) {
                unset($_SESSION['uid']);
            }
        }
    }
    return $user;
}

function has_role(array $roles): bool
{
    $u = current_user();
    return $u !== null && in_array($u['role'], $roles, true);
}

function require_login(): array
{
    $u = current_user();
    if ($u === null) {
        if (wants_json()) {
            json_out(['success' => false, 'error_code' => 'NOT_LOGGED_IN', 'message' => 'Please sign in again.'], 401);
        }
        redirect('login.php');
    }
    return $u;
}

function require_role(array $roles): array
{
    $u = require_login();
    if (!in_array($u['role'], $roles, true)) {
        if (wants_json()) {
            json_out(['success' => false, 'error_code' => 'FORBIDDEN', 'message' => 'Your role cannot do this.'], 403);
        }
        http_response_code(403);
        $pageTitle = 'Access denied';
        $active = '';
        require __DIR__ . '/header.php';
        echo '<div class="alert alert-warning mt-4"><i class="bi bi-shield-lock"></i> Your role (' . e($u['role_label']) . ') does not have access to this page.</div>';
        require __DIR__ . '/footer.php';
        exit;
    }
    return $u;
}

/** 'ready' = no users yet (show setup), 'ok' = users exist, 'no_database' = tables not reachable. */
function setup_state(): string
{
    try {
        return ((int)db_value('SELECT COUNT(*) FROM users') === 0) ? 'ready' : 'ok';
    } catch (Throwable $e) {
        return 'no_database';
    }
}

function auth_start_session(int $userId): void
{
    session_regenerate_id(true);
    $_SESSION['uid'] = $userId;
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
    current_user(true);
}

/** @return array{ok:bool,message:string} */
function auth_attempt(string $username, string $password): array
{
    $generic = 'Invalid username or password.';
    $username = trim($username);
    $u = db_row('SELECT id, password_hash, is_active, failed_logins, locked_until FROM users WHERE username = ?', [$username]);

    if ($u === null) {
        password_verify($password, password_hash('arc-timing-padding', PASSWORD_DEFAULT)); // keeps timing similar
        return ['ok' => false, 'message' => $generic];
    }
    if ($u['locked_until'] !== null && strtotime((string)$u['locked_until']) > time()) {
        $mins = (int)ceil((strtotime((string)$u['locked_until']) - time()) / 60);
        return ['ok' => false, 'message' => "Too many failed attempts. Try again in about {$mins} minute(s)."];
    }
    if (!password_verify($password, (string)$u['password_hash']) || (int)$u['is_active'] !== 1) {
        $fails = (int)$u['failed_logins'] + 1;
        if ($fails >= AUTH_MAX_FAILS) {
            db_exec('UPDATE users SET failed_logins = 0, locked_until = ? WHERE id = ?',
                [date('Y-m-d H:i:s', time() + AUTH_LOCK_MINUTES * 60), $u['id']]);
        } else {
            db_exec('UPDATE users SET failed_logins = ? WHERE id = ?', [$fails, $u['id']]);
        }
        return ['ok' => false, 'message' => $generic];
    }
    if (password_needs_rehash((string)$u['password_hash'], PASSWORD_DEFAULT)) {
        db_exec('UPDATE users SET password_hash = ? WHERE id = ?', [password_hash($password, PASSWORD_DEFAULT), $u['id']]);
    }
    db_exec('UPDATE users SET failed_logins = 0, locked_until = NULL, last_login_at = ? WHERE id = ?', [date('Y-m-d H:i:s'), $u['id']]);
    auth_start_session((int)$u['id']);
    activity('auth.login', 'user', $u['id']);
    return ['ok' => true, 'message' => ''];
}

function auth_logout(): void
{
    activity('auth.logout');
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 3600, $p['path'], $p['domain'] ?? '', (bool)$p['secure'], (bool)$p['httponly']);
    }
    session_destroy();
}
