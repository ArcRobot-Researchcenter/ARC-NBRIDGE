<?php
declare(strict_types=1);

require_once __DIR__ . '/storage.php';
require_once __DIR__ . '/export.php';
require_once __DIR__ . '/reports.php';
require_once __DIR__ . '/report_pdf.php';

/* ------------------------------------------------------- stored export files */
function export_filename(string $dataset, string $ext): string
{
    $dataset = preg_replace('/[^a-z0-9_]/', '', strtolower($dataset)) ?: 'data';
    return 'arc-nbridge_' . $dataset . '_' . date('Ymd-His') . '_' . bin2hex(random_bytes(3)) . '.' . preg_replace('/[^a-z0-9]/', '', strtolower($ext));
}

/** Saves bytes under storage/exports and returns true on success. */
function export_store(string $filename, string $bytes): bool
{
    $dir = storage_dir_for('exports');
    return $dir !== null && @file_put_contents($dir[0] . '/' . $filename, $bytes, LOCK_EX) !== false;
}

/** Absolute path of a stored export, or null when the name is invalid or the file is missing. */
function export_path(string $filename): ?string
{
    if (!preg_match('/^[A-Za-z0-9._-]{1,160}$/', $filename) || strpos($filename, '..') !== false) {
        return null;
    }
    return storage_safe_path('exports/' . $filename);
}

function export_register(string $kind, string $format, string $dataset, string $filename, ?int $rows, bool $includeDemo, ?int $userId): int
{
    db_exec('INSERT INTO exports (kind, format, dataset, filename, row_count, include_demo, created_by) VALUES (?,?,?,?,?,?,?)',
        [$kind, $format, $dataset, $filename, $rows, $includeDemo ? 1 : 0, $userId]);
    return (int)db()->lastInsertId();
}

function export_mime(string $format): string
{
    return ['csv' => 'text/csv; charset=utf-8', 'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'pdf' => 'application/pdf', 'zip' => 'application/zip'][$format] ?? 'application/octet-stream';
}

/**
 * Older databases were created with exports.format = ('pdf','csv','xlsx'). The evidence pack is a ZIP, so add 'zip'.
 * @return string|null null when the schema is fine (or was fixed), otherwise a message for the user
 */
function evidence_ensure_schema(): ?string
{
    try {
        $col = db_row("SHOW COLUMNS FROM exports LIKE 'format'");
        if ($col !== null && strpos((string)$col['Type'], "'zip'") === false) {
            db()->exec("ALTER TABLE exports MODIFY format ENUM('pdf','csv','xlsx','zip') NOT NULL");
        }
        return null;
    } catch (Throwable $e) {
        error_log('ARC N-BRIDGE: exports schema update failed: ' . $e->getMessage());
        return "The database needs one small update. Run this in phpMyAdmin (SQL tab) and try again: ALTER TABLE exports MODIFY format ENUM('pdf','csv','xlsx','zip') NOT NULL;";
    }
}

/* ---------------------------------------------------------- audio integrity */
/**
 * Re-hashes every stored recording and compares it with the SHA-256 saved when it was uploaded.
 * @return array{checked:int, ok:int, missing:int, mismatch:int, no_hash:int, problems:array, limit_reached:bool, checked_at:string}
 */
function evidence_audio_integrity(int $limit = 5000): array
{
    $rows = db_all("SELECT 'asr' AS kind, id, test_code AS ref, audio_path, audio_sha256 FROM asr_tests WHERE audio_path IS NOT NULL
                    UNION ALL
                    SELECT 'turn', ct.id, CONCAT(cv.conv_code, ' turn ', ct.turn_no), ct.audio_path, ct.audio_sha256
                    FROM conversation_turns ct JOIN conversations cv ON cv.id = ct.conversation_id WHERE ct.audio_path IS NOT NULL
                    LIMIT " . ($limit + 1));
    $limitReached = count($rows) > $limit;
    $rows = array_slice($rows, 0, $limit);
    $out = ['checked' => 0, 'ok' => 0, 'missing' => 0, 'mismatch' => 0, 'no_hash' => 0, 'problems' => [], 'limit_reached' => $limitReached,
            'checked_at' => date('Y-m-d H:i:s')];
    foreach ($rows as $r) {
        $out['checked']++;
        $path = storage_safe_path((string)$r['audio_path']);
        $problem = null;
        if ($path === null) {
            $out['missing']++;
            $problem = 'file missing';
        } elseif (empty($r['audio_sha256'])) {
            $out['no_hash']++;
            $problem = 'no hash was stored';
        } elseif (!hash_equals((string)$r['audio_sha256'], (string)hash_file('sha256', $path))) {
            $out['mismatch']++;
            $problem = 'file changed since upload';
        } else {
            $out['ok']++;
        }
        if ($problem !== null && count($out['problems']) < 50) {
            $out['problems'][] = ['kind' => $r['kind'], 'ref' => (string)$r['ref'], 'problem' => $problem];
        }
    }
    return $out;
}

/* -------------------------------------------------------------- evidence pack */
/**
 * Builds the evidence pack ZIP in storage/exports.
 * @param array $user   current_user()
 * @param array $aiInfo result of ai_models() ('ok' bool, 'data' array, 'message' string)
 * @return array{filename:string, manifest:array}
 */
function evidence_pack(array $f, array $user, array $aiInfo): array
{
    if (!class_exists('ZipArchive')) {
        throw new RuntimeException('The PHP zip extension is not enabled. In XAMPP, enable extension=zip in php.ini and restart Apache.');
    }
    $now = date('Y-m-d H:i:s');
    $app = (string)setting('app.name', 'ARC N-BRIDGE');
    $version = (string)setting('app.version', '0.1.0-prototype');
    $files = [];     // path in zip => bytes
    $counts = [];

    foreach (['asr' => 'asr_tests', 'translations' => 'translations', 'tts' => 'tts_outputs', 'conversations' => 'conversation_turns', 'participants' => 'participants'] as $key => $name) {
        $d = report_dataset($key, $f);
        $files['data/' . $name . '.csv'] = export_csv($d['headers'], $d['rows']);
        $counts[$name] = ['rows' => count($d['rows']), 'truncated' => $d['truncated']];
    }
    $summary = report_summary($f);
    $files['report_summary.pdf'] = report_pdf($summary, report_asr_examples($f), ['app' => $app, 'version' => $version, 'generated_by' => $user['full_name'], 'generated_at' => $now]);

    $integrity = evidence_audio_integrity();
    $files['audio_integrity.json'] = json_encode($integrity, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    $env = ['generated_at' => $now, 'php' => PHP_VERSION, 'os' => php_uname('s') . ' ' . php_uname('r'), 'database' => (string)db_value('SELECT VERSION()'),
            'ai_service' => $aiInfo['ok'] ? $aiInfo['data'] : ['reachable' => false, 'reason' => (string)($aiInfo['message'] ?? 'unknown')]];
    if ($aiInfo['ok']) {
        unset($env['ai_service']['request_id'], $env['ai_service']['success'], $env['ai_service']['error']);
    }
    $files['environment.json'] = json_encode($env, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    $files['README.txt'] = "ARC N-BRIDGE evidence pack\n==========================\n\n"
        . "Generated $now by {$user['full_name']} ($app $version).\n\n"
        . "data/*.csv           Exact records (UTF-8 with BOM). Open in Excel, or import with any tool.\n"
        . "report_summary.pdf   Human-readable summary (diacritics are simplified in the PDF only).\n"
        . "environment.json     Software versions and model repositories reported by the AI service at the time of generation.\n"
        . "audio_integrity.json Result of re-hashing every stored recording against the SHA-256 saved at upload.\n"
        . "manifest.json        SHA-256 and size of every file in this pack, plus the filters used.\n\n"
        . "To verify a file: compute its SHA-256 and compare it with manifest.json.\n"
        . "Audio recordings are NOT included (privacy). Their hashes are in data/asr_tests.csv and the integrity report.\n"
        . "Demo records are " . ($f['include_demo'] ? 'INCLUDED' : 'excluded') . ". Records of participants who withdrew consent are excluded.\n";

    $manifestFiles = [];
    foreach ($files as $path => $bytes) {
        $manifestFiles[] = ['path' => $path, 'bytes' => strlen($bytes), 'sha256' => hash('sha256', $bytes)];
    }
    $manifest = ['generated_at' => $now, 'generated_by' => $user['full_name'], 'application' => $app, 'version' => $version, 'filters' => $f,
                 'record_counts' => $counts, 'files' => $manifestFiles,
                 'limitations' => ['Prototype evaluation set; not a benchmark.', 'WER/CER only for tests with a reference transcript.',
                                   'Translation and voice output were not scored for quality.']];
    $files['manifest.json'] = json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    $dir = storage_dir_for('exports');
    if ($dir === null) {
        throw new RuntimeException('The exports folder cannot be created. Check permissions on the storage folder.');
    }
    $filename = export_filename('evidence_pack', 'zip');
    $zip = new ZipArchive();
    if ($zip->open($dir[0] . '/' . $filename, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        throw new RuntimeException('The evidence pack could not be created.');
    }
    foreach ($files as $path => $bytes) {
        $zip->addFromString($path, $bytes);
    }
    if (!$zip->close()) {
        throw new RuntimeException('The evidence pack could not be written.');
    }
    return ['filename' => $filename, 'manifest' => $manifest];
}
