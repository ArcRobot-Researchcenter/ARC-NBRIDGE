<?php
declare(strict_types=1);

/* ------------------------------------------------ secret encryption (APP_KEY) */
function app_key_bytes(): ?string
{
    $raw = base64_decode((string)cfg('app_key', ''), true);
    return ($raw !== false && strlen($raw) === 32) ? $raw : null;
}

function secret_encrypt(string $plain): ?string
{
    $key = app_key_bytes();
    if ($key === null || !function_exists('openssl_encrypt')) {
        return null;
    }
    $iv = random_bytes(12);
    $tag = '';
    $cipher = openssl_encrypt($plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
    return $cipher === false ? null : 'enc1:' . base64_encode($iv . $tag . $cipher);
}

function secret_decrypt(string $stored): string
{
    if ($stored === '' || strpos($stored, 'enc1:') !== 0) {
        return '';
    }
    $key = app_key_bytes();
    $bin = base64_decode(substr($stored, 5), true);
    if ($key === null || $bin === false || strlen($bin) < 29 || !function_exists('openssl_decrypt')) {
        return '';
    }
    $plain = openssl_decrypt(substr($bin, 28), 'aes-256-gcm', $key, OPENSSL_RAW_DATA, substr($bin, 0, 12), substr($bin, 12, 16));
    return $plain === false ? '' : $plain;
}

/* ------------------------------------------------------------- settings API */
/** All rows keyed by setting_key => ['value' => raw string, 'secret' => bool]. Cached per request. */
function settings_all(bool $refresh = false): array
{
    static $cache = null;
    if ($cache === null || $refresh) {
        $cache = [];
        try {
            foreach (db_all('SELECT setting_key, setting_value, is_secret FROM system_settings') as $r) {
                $cache[$r['setting_key']] = ['value' => (string)$r['setting_value'], 'secret' => (bool)$r['is_secret']];
            }
        } catch (Throwable $e) {
            error_log('settings unavailable: ' . $e->getMessage());
        }
    }
    return $cache;
}

function setting(string $key, $default = null)
{
    $all = settings_all();
    if (!isset($all[$key])) {
        return $default;
    }
    $row = $all[$key];
    if ($row['secret']) {
        $plain = secret_decrypt($row['value']);
        return $plain === '' ? $default : $plain;
    }
    return $row['value'] === '' ? $default : $row['value'];
}

function setting_bool(string $key, bool $default = false): bool
{
    $v = setting($key, null);
    return $v === null ? $default : in_array((string)$v, ['1', 'true', 'yes', 'on'], true);
}

function setting_int(string $key, int $default = 0): int
{
    $v = setting($key, null);
    return ($v !== null && is_numeric($v)) ? (int)$v : $default;
}

/** True when a secret setting currently holds a value (the value itself is never shown). */
function setting_secret_is_set(string $key): bool
{
    $all = settings_all();
    return isset($all[$key]) && $all[$key]['value'] !== '';
}

/** Saves a setting. Secrets are encrypted; returns false if a secret cannot be encrypted (no usable APP_KEY). */
function setting_set(string $key, string $value, ?int $userId = null): bool
{
    $all = settings_all();
    $isSecret = isset($all[$key]) ? $all[$key]['secret'] : false;
    $stored = $value;
    if ($isSecret && $value !== '') {
        $stored = secret_encrypt($value);
        if ($stored === null) {
            return false;
        }
    }
    db_exec('INSERT INTO system_settings (setting_key, setting_value, is_secret, updated_by) VALUES (?,?,?,?)
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_by = VALUES(updated_by)',
        [$key, $stored, $isSecret ? 1 : 0, $userId]);
    settings_all(true);
    return true;
}
