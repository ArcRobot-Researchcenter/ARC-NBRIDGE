<?php
declare(strict_types=1);

const LANGS = ['ha' => 'Hausa', 'yo' => 'Yoruba', 'ig' => 'Igbo', 'en' => 'Nigerian English'];

function cfg(string $key, $default = null)
{
    return $GLOBALS['ARC_CONFIG'][$key] ?? $default;
}

function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function is_https(): bool
{
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
}

function base_path(): string
{
    $dir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
    return ($dir === '/' || $dir === '.' || $dir === '') ? '' : rtrim($dir, '/');
}

function url(string $path = ''): string
{
    return base_path() . '/' . ltrim($path, '/');
}

function redirect(string $path): void
{
    header('Location: ' . url($path));
    exit;
}

function lang_name(?string $code): string
{
    return LANGS[$code ?? ''] ?? (string)$code;
}

function new_request_id(): string
{
    return bin2hex(random_bytes(8));
}

function uuid4(): string
{
    $b = random_bytes(16);
    $b[6] = chr((ord($b[6]) & 0x0f) | 0x40);
    $b[8] = chr((ord($b[8]) & 0x3f) | 0x80);
    $h = bin2hex($b);
    return sprintf('%s-%s-%s-%s-%s', substr($h, 0, 8), substr($h, 8, 4), substr($h, 12, 4), substr($h, 16, 4), substr($h, 20));
}

function client_ip(): string
{
    return substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45); // proxy headers are deliberately not trusted
}

/* ------------------------------------------------------------------ CSRF */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}

function csrf_valid(): bool
{
    $sent = $_POST['_csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    return is_string($sent) && $sent !== '' && hash_equals(csrf_token(), $sent);
}

/** Stops the request with a 419 when the CSRF token is missing or wrong. */
function require_csrf(): void
{
    if (!csrf_valid()) {
        if (wants_json()) {
            json_out(['success' => false, 'error_code' => 'CSRF_INVALID',
                      'message' => 'Your session expired. Reload the page and try again.'], 419);
        }
        http_response_code(419);
        exit('Your session expired. Go back, reload the page and try again.');
    }
}

/* ----------------------------------------------------------------- flash */
function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function flash_pull(): array
{
    $items = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $items;
}

/* ------------------------------------------------------------------ JSON */
function wants_json(): bool
{
    return (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false)
        || (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'fetch');
}

function json_out(array $data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

/* --------------------------------------------------------------- logging */
function activity(string $action, ?string $entityType = null, $entityId = null, array $meta = []): void
{
    try {
        $user = current_user();
        db_exec('INSERT INTO activity_logs (user_id, action, entity_type, entity_id, ip_address, metadata) VALUES (?,?,?,?,?,?)', [
            $user['id'] ?? null, $action, $entityType, $entityId === null ? null : (string)$entityId, client_ip(),
            $meta ? json_encode($meta, JSON_UNESCAPED_UNICODE) : null,
        ]);
    } catch (Throwable $e) {
        error_log('activity log failed: ' . $e->getMessage());
    }
}

function api_log(string $requestId, string $operation, ?string $provider, string $status, ?int $http, ?int $ms, ?string $errorCode): void
{
    try {
        $user = current_user();
        db_exec('INSERT INTO api_logs (request_id, operation, provider, status, http_code, processing_ms, error_code, user_id) VALUES (?,?,?,?,?,?,?,?)',
            [$requestId, $operation, $provider, $status, $http, $ms, $errorCode, $user['id'] ?? null]);
    } catch (Throwable $e) {
        error_log('api log failed: ' . $e->getMessage());
    }
}

/* ------------------------------------------------------- local config file */
/** Merge $changes into config.local.php. Returns false if the file cannot be written. */
function config_local_write(array $changes): bool
{
    $file = APP_ROOT . '/config.local.php';
    $current = [];
    if (is_file($file)) {
        $loaded = require $file;
        if (is_array($loaded)) {
            $current = $loaded;
        }
    }
    $merged = array_replace($current, $changes);
    $php = "<?php\n// Written by ARC N-BRIDGE setup. Contains secrets: never share or commit this file.\nreturn " . var_export($merged, true) . ";\n";
    if (@file_put_contents($file, $php, LOCK_EX) === false) {
        return false;
    }
    $GLOBALS['ARC_CONFIG'] = array_replace($GLOBALS['ARC_CONFIG'], $changes);
    return true;
}
