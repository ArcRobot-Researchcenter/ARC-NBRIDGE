<?php
declare(strict_types=1);

/** Private file storage (audio, exports). The storage folder is protected by its own .htaccess and is only served through PHP. */

/** @return array{0:string,1:string}|null [absolute dir, relative dir]; the folder is created when missing */
function storage_dir_for(string $kind): ?array
{
    $rel = 'audio/' . $kind . '/' . date('Y/m');
    if ($kind === 'exports') {
        $rel = 'exports';
    }
    $abs = rtrim((string)cfg('storage_path'), '/\\') . '/' . $rel;
    if (!is_dir($abs) && !@mkdir($abs, 0775, true) && !is_dir($abs)) {
        error_log('ARC N-BRIDGE: cannot create storage directory ' . $abs);
        return null;
    }
    return [$abs, $rel];
}

/** Resolves a stored relative path and refuses anything outside the storage folder. */
function storage_safe_path(string $relative): ?string
{
    $root = realpath((string)cfg('storage_path'));
    $full = realpath(rtrim((string)cfg('storage_path'), '/\\') . '/' . $relative);
    if ($root === false || $full === false || strpos($full, $root . DIRECTORY_SEPARATOR) !== 0 || !is_file($full)) {
        return null;
    }
    return $full;
}

/** Streams a stored file to the browser (caller has already checked permissions). */
function storage_stream(string $fullPath, string $mime, ?string $downloadName = null): void
{
    header('Content-Type: ' . $mime);
    header('Content-Length: ' . filesize($fullPath));
    header('X-Content-Type-Options: nosniff');
    if ($downloadName !== null) {
        header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9._-]/', '_', $downloadName) . '"');
        header('Cache-Control: no-store');
    } else {
        header('Cache-Control: private, max-age=3600');
    }
    readfile($fullPath);
    exit;
}
