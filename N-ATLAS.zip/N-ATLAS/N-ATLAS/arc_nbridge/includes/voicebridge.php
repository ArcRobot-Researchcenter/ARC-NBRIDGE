<?php
declare(strict_types=1);

require_once __DIR__ . '/storage.php';

/**
 * VoiceBridge business logic: two people speak different languages, each turn goes
 * record -> speech to text -> speaker confirms/edits -> translation -> voice output.
 * Every step is stored, so a failure at any step can be retried without losing the earlier ones.
 * The functions return ['ok'=>bool, 'code'=>string, 'message'=>string, ...] and never print anything.
 */

const VB_AUDIO_EXT = ['wav' => 'audio/wav', 'webm' => 'audio/webm', 'ogg' => 'audio/ogg', 'mp3' => 'audio/mpeg', 'm4a' => 'audio/mp4', 'flac' => 'audio/flac'];
const VB_TEXT_MAX = 1000;     // keep in step with MAX_TRANSLATION_CHARS in the Python service
const VB_TTS_MAX = 500;       // keep in step with MAX_TTS_CHARS in the Python service
const VB_UNAVAILABLE_CODES = ['MODEL_LOAD_FAILED', 'MODEL_ACCESS_DENIED', 'MODEL_NOT_DOWNLOADED', 'DEPENDENCY_MISSING', 'MODEL_DISABLED'];

function vb_result(bool $ok, string $code = '', string $message = '', array $extra = []): array
{
    return ['ok' => $ok, 'code' => $code, 'message' => $message] + $extra;
}

function vb_enabled_languages(): array
{
    $out = [];
    foreach (LANGS as $code => $name) {
        if (setting_bool("natlas.enabled.$code", true)) {
            $out[$code] = $name;
        }
    }
    return $out;
}

function vb_norm_text(string $s): string
{
    return trim(preg_replace('/\s+/u', ' ', $s) ?? $s);
}

function vb_conv(int $id): ?array
{
    return db_row('SELECT * FROM conversations WHERE id = ?', [$id]);
}

function vb_can_access(?array $conv, array $user): bool
{
    if ($conv === null) {
        return false;
    }
    return in_array($user['role'], ['admin', 'researcher'], true) || (int)$conv['created_by'] === (int)$user['id'];
}

function vb_turn(int $id): ?array
{
    return db_row('SELECT t.*, c.status AS conv_status, c.created_by AS conv_owner FROM conversation_turns t JOIN conversations c ON c.id = t.conversation_id WHERE t.id = ?', [$id]);
}

/** @return array{0:string,1:string} [spoken language, heard-by language] for a speaker */
function vb_pair(array $conv, string $speaker): array
{
    return $speaker === 'A' ? [$conv['lang_a'], $conv['lang_b']] : [$conv['lang_b'], $conv['lang_a']];
}

/* ------------------------------------------------------------- conversations */
function vb_create_conversation(array $user, string $langA, string $langB, ?int $partA, ?int $partB, bool $demo): array
{
    $enabled = vb_enabled_languages();
    if (!isset($enabled[$langA]) || !isset($enabled[$langB])) {
        return vb_result(false, 'LANGUAGE_UNSUPPORTED', 'Choose two enabled languages.');
    }
    if ($langA === $langB) {
        return vb_result(false, 'SAME_LANGUAGE', 'The two people must speak different languages.');
    }
    foreach ([[$partA, 'Person A'], [$partB, 'Person B']] as [$pid, $label]) {
        if ($pid === null) {
            continue;
        }
        $p = db_row('SELECT id, consent_status FROM participants WHERE id = ?', [$pid]);
        if ($p === null) {
            return vb_result(false, 'PARTICIPANT_NOT_FOUND', "$label: that participant does not exist.");
        }
        if (setting_bool('privacy.require_consent', true) && $p['consent_status'] !== 'granted') {
            return vb_result(false, 'CONSENT_REQUIRED', "$label has not given consent (or withdrew it). Record consent on the Participants page first.");
        }
    }
    db_exec('INSERT INTO conversations (created_by, person_a_part_id, person_b_part_id, lang_a, lang_b, is_demo) VALUES (?,?,?,?,?,?)',
        [(int)$user['id'], $partA, $partB, $langA, $langB, $demo ? 1 : 0]);
    $id = (int)db()->lastInsertId();
    db_exec('UPDATE conversations SET conv_code = ? WHERE id = ?', [sprintf('CNV-%06d', $id), $id]);
    return vb_result(true, '', '', ['id' => $id, 'conv_code' => sprintf('CNV-%06d', $id)]);
}

function vb_close_conversation(int $id): void
{
    db_exec("UPDATE conversations SET status = 'closed', closed_at = NOW() WHERE id = ? AND status = 'active'", [$id]);
}

/* ------------------------------------------------------------------- uploads */
/** Validates an uploaded audio file. @return array ok result with 'ext' and 'mime', or a failure result */
function vb_validate_upload($f): array
{
    if (!is_array($f) || ($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return vb_result(false, 'NO_AUDIO', 'Record something first.');
    }
    if ($f['error'] !== UPLOAD_ERR_OK) {
        $big = in_array($f['error'], [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true);
        return vb_result(false, 'UPLOAD_FAILED', $big ? 'The recording is larger than the PHP upload limit (upload_max_filesize in php.ini).' : 'The upload did not finish. Please try again.');
    }
    if ((int)$f['size'] <= 0) {
        return vb_result(false, 'AUDIO_EMPTY', 'The recording is empty.');
    }
    $maxMb = setting_int('recording.max_upload_mb', 10);
    if ((int)$f['size'] > $maxMb * 1024 * 1024) {
        return vb_result(false, 'FILE_TOO_LARGE', "The recording is larger than the limit of $maxMb MB set in Settings.");
    }
    $ext = strtolower(pathinfo((string)$f['name'], PATHINFO_EXTENSION));
    $allowed = array_filter(array_map('trim', explode(',', (string)setting('recording.allowed_formats', 'wav,webm,ogg,mp3,m4a,flac'))));
    if (!isset(VB_AUDIO_EXT[$ext]) || !in_array($ext, $allowed, true)) {
        return vb_result(false, 'FORMAT_NOT_ALLOWED', 'This audio format is not allowed. Allowed: ' . implode(', ', $allowed) . '.');
    }
    return vb_result(true, '', '', ['ext' => $ext, 'mime' => VB_AUDIO_EXT[$ext]]);
}

/** Moves/renames $src into storage. @return array{0:string,1:string}|null [relative path, absolute path] */
function vb_store_file(string $src, string $ext, string $kind, bool $uploaded): ?array
{
    $dir = storage_dir_for($kind);
    if ($dir === null) {
        return null;
    }
    $name = uuid4() . '.' . $ext;
    $ok = $uploaded ? move_uploaded_file($src, $dir[0] . '/' . $name) : @rename($src, $dir[0] . '/' . $name);
    return $ok ? [$dir[1] . '/' . $name, $dir[0] . '/' . $name] : null;
}

/* --------------------------------------------------------------------- turns */
/** Creates a turn in the 'failed' (not yet recognised) state. Retries once if two requests race for the same turn number. */
function vb_create_turn(array $conv, string $speaker, ?string $audioRel, ?string $sha): int
{
    [$src, $tgt] = vb_pair($conv, $speaker);
    $pdo = db();
    $pdo->beginTransaction();
    try {
        db_value('SELECT id FROM conversations WHERE id = ? FOR UPDATE', [(int)$conv['id']]);
        $next = (int)db_value('SELECT COALESCE(MAX(turn_no), 0) + 1 FROM conversation_turns WHERE conversation_id = ?', [(int)$conv['id']]);
        db_exec("INSERT INTO conversation_turns (conversation_id, turn_no, speaker, source_lang, target_lang, audio_path, audio_sha256, status, is_demo)
                 VALUES (?,?,?,?,?,?,?,'failed',?)", [(int)$conv['id'], $next, $speaker, $src, $tgt, $audioRel, $sha, (int)$conv['is_demo']]);
        $id = (int)$pdo->lastInsertId();
        $pdo->commit();
        return $id;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

/** Sends the turn's audio to the speech model and stores the raw result. */
function vb_run_asr(int $turnId, string $absPath, string $mime, string $name): array
{
    $turn = vb_turn($turnId);
    if ($turn === null) {
        return vb_result(false, 'NOT_FOUND', 'This turn no longer exists.');
    }
    $res = ai_asr($absPath, $name, $mime, $turn['source_lang']);
    if (!$res['ok']) {
        return vb_result(false, (string)$res['error_code'], (string)$res['message'], ['http' => $res['http']]);
    }
    $d = $res['data'];
    $text = trim((string)($d['transcription'] ?? ''));
    $auto = $text !== '' && !setting_bool('conversation.require_confirmation', true);
    db_exec('UPDATE conversation_turns SET asr_request_id = ?, asr_model = ?, asr_text = ?, asr_ms = ?, status = ?, confirmed_text = ?, confirmed_at = ?, was_edited = 0 WHERE id = ?', [
        $res['request_id'], $d['model_repo'] ?? ($d['model'] ?? null), $text, is_numeric($d['processing_time'] ?? null) ? (int)round((float)$d['processing_time'] * 1000) : null,
        $auto ? 'confirmed' : 'transcribed', $auto ? $text : null, $auto ? date('Y-m-d H:i:s') : null, $turnId,
    ]);
    return vb_result(true, '', '', ['empty' => $text === '', 'low_energy' => !empty($d['low_energy'])]);
}

function vb_confirm(int $turnId, string $text): array
{
    $turn = vb_turn($turnId);
    if ($turn === null) {
        return vb_result(false, 'NOT_FOUND', 'This turn no longer exists.');
    }
    if ($turn['conv_status'] !== 'active') {
        return vb_result(false, 'CONVERSATION_CLOSED', 'This conversation is closed.');
    }
    if (!in_array($turn['status'], ['transcribed', 'confirmed'], true)) {
        return vb_result(false, 'BAD_STATE', $turn['status'] === 'failed' ? 'Speech recognition failed for this turn. Try it again or record again.'
            : 'This turn was already translated. Record a new turn instead of changing it.');
    }
    $text = trim($text);
    if ($text === '') {
        return vb_result(false, 'TEXT_EMPTY', 'The text is empty. Type what was said, or record again.');
    }
    if (mb_strlen($text) > VB_TEXT_MAX) {
        return vb_result(false, 'TEXT_TOO_LONG', 'The text is longer than ' . VB_TEXT_MAX . ' characters. Split it into shorter turns.');
    }
    $edited = vb_norm_text($text) !== vb_norm_text((string)$turn['asr_text']) ? 1 : 0;
    db_exec("UPDATE conversation_turns SET confirmed_text = ?, was_edited = ?, status = 'confirmed', confirmed_at = NOW() WHERE id = ?", [$text, $edited, $turnId]);
    return vb_result(true, '', '', ['was_edited' => (bool)$edited]);
}

function vb_translate(int $turnId, string $mode): array
{
    $turn = vb_turn($turnId);
    if ($turn === null) {
        return vb_result(false, 'NOT_FOUND', 'This turn no longer exists.');
    }
    if (!in_array($turn['status'], ['confirmed', 'translated', 'spoken'], true) || trim((string)$turn['confirmed_text']) === '') {
        return vb_result(false, 'NOT_CONFIRMED', 'Confirm the text first.');
    }
    if (!in_array($mode, ['direct', 'pivot'], true)) {
        return vb_result(false, 'BAD_REQUEST', 'Unknown translation route.');
    }
    if (($mode === 'direct' && !setting_bool('translation.direct_enabled', true)) || ($mode === 'pivot' && !setting_bool('translation.pivot_enabled', true))) {
        return vb_result(false, 'MODE_DISABLED', 'This translation route is switched off in Settings.');
    }
    $engine = (string)setting('translation.engine', 'nllb');
    $engine = in_array($engine, ['nllb', 'natlas_llm'], true) ? $engine : 'nllb';
    $res = ai_request('POST', '/translate', ['json' => ['source_language' => $turn['source_lang'], 'target_language' => $turn['target_lang'],
        'text' => $turn['confirmed_text'], 'engine' => $engine, 'mode' => $mode], 'timeout' => setting_int('translation.timeout_sec', 90), 'operation' => 'translate']);
    $d = $res['data'] ?? [];
    $ms = $res['ok'] ? (is_numeric($d['processing_time'] ?? null) ? (int)round((float)$d['processing_time'] * 1000) : null) : $res['ms'];
    db_exec('INSERT INTO translations (turn_id, source_lang, target_lang, source_text, translated_text, provider, model, mode, pivot_text, request_id, processing_ms, status, error_code, is_demo)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)', [
        $turnId, $turn['source_lang'], $turn['target_lang'], $turn['confirmed_text'], $res['ok'] ? (string)($d['translation'] ?? '') : null,
        $res['ok'] ? (string)($d['provider'] ?? $engine) : $engine, $res['ok'] ? ($d['model'] ?? null) : null, $res['ok'] ? ($d['mode'] ?? $mode) : $mode,
        $res['ok'] ? ($d['pivot_text'] ?? null) : null, $res['request_id'], $ms, $res['ok'] ? 'ok' : 'failed',
        $res['ok'] ? null : mb_substr((string)$res['error_code'], 0, 48), (int)$turn['is_demo'],
    ]);
    if (!$res['ok']) {
        return vb_result(false, (string)$res['error_code'], (string)$res['message']);
    }
    db_exec("UPDATE conversation_turns SET status = 'translated' WHERE id = ?", [$turnId]);
    return vb_result(true);
}

function vb_tts(int $turnId): array
{
    $turn = vb_turn($turnId);
    if ($turn === null) {
        return vb_result(false, 'NOT_FOUND', 'This turn no longer exists.');
    }
    $tr = db_row("SELECT id, translated_text FROM translations WHERE turn_id = ? AND status = 'ok' ORDER BY id DESC LIMIT 1", [$turnId]);
    if ($tr === null || trim((string)$tr['translated_text']) === '') {
        return vb_result(false, 'NOT_TRANSLATED', 'Translate the text first.');
    }
    if ((string)setting('tts.provider', 'disabled') !== 'local_mms' || !setting_bool('conversation.tts_enabled', true)) {
        return vb_result(false, 'TTS_DISABLED', 'Voice output is switched off. The translated text is shown instead.');
    }
    $text = trim((string)$tr['translated_text']);
    if (mb_strlen($text) > VB_TTS_MAX) {
        return vb_result(false, 'TEXT_TOO_LONG', 'The translation is longer than ' . VB_TTS_MAX . ' characters, so it cannot be spoken. Use shorter turns.');
    }
    $res = ai_request('POST', '/tts', ['json' => ['language' => $turn['target_lang'], 'text' => $text], 'timeout' => 180, 'operation' => 'tts']);
    $d = $res['data'] ?? [];
    $status = $res['ok'] ? 'ok' : (in_array((string)$res['error_code'], VB_UNAVAILABLE_CODES, true) ? 'unavailable' : 'failed');
    $rel = null;
    if ($res['ok'] && setting_bool('recording.save_generated', true)) {
        $bin = base64_decode((string)($d['audio_base64'] ?? ''), true);
        $dir = ($bin !== false && substr($bin, 0, 4) === 'RIFF') ? storage_dir_for('tts') : null;
        if ($dir !== null) {
            $name = uuid4() . '.wav';
            if (@file_put_contents($dir[0] . '/' . $name, $bin) !== false) {
                $rel = $dir[1] . '/' . $name;
            }
        }
    }
    $ms = $res['ok'] ? (is_numeric($d['processing_time'] ?? null) ? (int)round((float)$d['processing_time'] * 1000) : null) : $res['ms'];
    db_exec('INSERT INTO tts_outputs (turn_id, translation_id, language_code, provider, model, audio_path, audio_mime, request_id, processing_ms, status, error_code, is_demo)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?)', [
        $turnId, (int)$tr['id'], $turn['target_lang'], 'local_mms', $res['ok'] ? ($d['model'] ?? null) : null, $rel, $res['ok'] ? ($d['mime'] ?? 'audio/wav') : null,
        $res['request_id'], $ms, $status, $res['ok'] ? null : mb_substr((string)$res['error_code'], 0, 48), (int)$turn['is_demo'],
    ]);
    if (!$res['ok']) {
        return vb_result(false, (string)$res['error_code'], (string)$res['message']);
    }
    if ($rel === null) {
        return vb_result(false, 'AUDIO_NOT_SAVED', 'The voice was made but could not be saved. Check that "Keep generated speech" is on in Settings and that the storage folder is writable.');
    }
    db_exec("UPDATE conversation_turns SET status = 'spoken' WHERE id = ?", [$turnId]);
    return vb_result(true);
}

/* ------------------------------------------------------------------- payload */
function vb_turn_payload(int $turnId): ?array
{
    $t = vb_turn($turnId);
    if ($t === null) {
        return null;
    }
    $tr = db_row('SELECT id, translated_text, mode, pivot_text, model, processing_ms, status, error_code FROM translations WHERE turn_id = ? ORDER BY id DESC LIMIT 1', [$turnId]);
    $tts = db_row('SELECT id, status, error_code, processing_ms, audio_path FROM tts_outputs WHERE turn_id = ? ORDER BY id DESC LIMIT 1', [$turnId]);
    $hasAudio = !empty($t['audio_path']) && storage_safe_path((string)$t['audio_path']) !== null;
    return [
        'id' => (int)$t['id'], 'turn_no' => (int)$t['turn_no'], 'speaker' => $t['speaker'],
        'source_lang' => $t['source_lang'], 'source_name' => lang_name($t['source_lang']),
        'target_lang' => $t['target_lang'], 'target_name' => lang_name($t['target_lang']),
        'status' => $t['status'], 'asr_text' => $t['asr_text'], 'confirmed_text' => $t['confirmed_text'], 'was_edited' => (int)$t['was_edited'] === 1,
        'asr_ms' => $t['asr_ms'] === null ? null : (int)$t['asr_ms'], 'created_at' => $t['created_at'],
        'audio_url' => $hasAudio ? url('voicebridge.php?audio=turn&id=' . (int)$t['id']) : null,
        'translation' => $tr === null ? null : ['text' => $tr['translated_text'], 'mode' => $tr['mode'], 'pivot_text' => $tr['pivot_text'], 'model' => $tr['model'],
            'ms' => $tr['processing_ms'] === null ? null : (int)$tr['processing_ms'], 'status' => $tr['status'], 'error_code' => $tr['error_code']],
        'tts' => $tts === null ? null : ['status' => $tts['status'], 'error_code' => $tts['error_code'], 'ms' => $tts['processing_ms'] === null ? null : (int)$tts['processing_ms'],
            'audio_url' => (!empty($tts['audio_path']) && $tts['status'] === 'ok') ? url('voicebridge.php?audio=tts&id=' . (int)$tts['id']) : null],
    ];
}

function vb_conversation_turns(int $convId): array
{
    $out = [];
    foreach (db_all('SELECT id FROM conversation_turns WHERE conversation_id = ? ORDER BY turn_no', [$convId]) as $r) {
        $p = vb_turn_payload((int)$r['id']);
        if ($p !== null) {
            $out[] = $p;
        }
    }
    return $out;
}
