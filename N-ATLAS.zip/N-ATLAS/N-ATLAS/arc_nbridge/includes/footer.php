</main>
<footer class="arc-footer text-center small text-muted py-3">
    <?= e((string)setting('app.name', 'ARC N-BRIDGE')) ?> · <?= e((string)setting('app.organization', 'ARC Robotics')) ?>
    · v<?= e((string)setting('app.version', '0.1.0-prototype')) ?>
    · Research prototype. Models by NCAIR1 (N-ATLaS), used under their terms.
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<?php foreach (($extraScripts ?? []) as $src): ?>
<script src="<?= e(url($src)) ?>"></script>
<?php endforeach; ?>
</body>
</html>
