<?php
declare(strict_types=1);

/**
 * Word / character error rate between a reference transcript and an ASR hypothesis.
 * Text is lower-cased and stripped of punctuation (letters, combining marks, digits and apostrophes are kept,
 * so Yoruba tone marks and Hausa hooked letters are preserved).
 */
function metrics_normalise(string $text): string
{
    if (class_exists('Normalizer')) {
        $n = Normalizer::normalize($text, Normalizer::FORM_C);
        $text = $n === false ? $text : $n;
    }
    $text = mb_strtolower($text, 'UTF-8');
    $text = preg_replace("/[^\\p{L}\\p{M}\\p{N}\\s'’ʼ]+/u", ' ', $text) ?? $text;
    return trim(preg_replace('/\s+/u', ' ', $text) ?? $text);
}

/** Levenshtein distance over arrays of tokens (words or characters). */
function metrics_edit_distance(array $a, array $b): int
{
    $n = count($a);
    $m = count($b);
    if ($n === 0) {
        return $m;
    }
    if ($m === 0) {
        return $n;
    }
    $prev = range(0, $m);
    for ($i = 1; $i <= $n; $i++) {
        $cur = [$i];
        for ($j = 1; $j <= $m; $j++) {
            $cost = ($a[$i - 1] === $b[$j - 1]) ? 0 : 1;
            $cur[$j] = min($prev[$j] + 1, $cur[$j - 1] + 1, $prev[$j - 1] + $cost);
        }
        $prev = $cur;
    }
    return $prev[$m];
}

/** @return float|null null when the reference has no words (the rate is undefined) */
function metrics_wer(string $reference, string $hypothesis): ?float
{
    $ref = metrics_normalise($reference);
    if ($ref === '') {
        return null;
    }
    $refWords = preg_split('/\s+/u', $ref) ?: [];
    $hypNorm = metrics_normalise($hypothesis);
    $hypWords = $hypNorm === '' ? [] : (preg_split('/\s+/u', $hypNorm) ?: []);
    return round(metrics_edit_distance($refWords, $hypWords) / count($refWords), 4);
}

function metrics_cer(string $reference, string $hypothesis): ?float
{
    $ref = metrics_normalise($reference);
    if ($ref === '') {
        return null;
    }
    $refChars = preg_split('//u', $ref, -1, PREG_SPLIT_NO_EMPTY) ?: [];
    $hyp = metrics_normalise($hypothesis);
    $hypChars = $hyp === '' ? [] : (preg_split('//u', $hyp, -1, PREG_SPLIT_NO_EMPTY) ?: []);
    return round(metrics_edit_distance($refChars, $hypChars) / count($refChars), 4);
}
