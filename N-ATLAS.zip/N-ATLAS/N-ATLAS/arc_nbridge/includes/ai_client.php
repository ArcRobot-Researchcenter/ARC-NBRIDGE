<?php
declare(strict_types=1);

/**
 * PHP -> Python AI service client. The API secret is read from encrypted settings on the server and
 * sent in the X-API-Secret header; it never reaches the browser or JavaScript.
 *
 * Every call returns the same shape:
 *   ok (bool), http (int), data (array|null), error_code (string|null), message (string|null), ms (int), request_id (string)
 */
function ai_result(bool $ok, int $http, ?array $data, ?string $code, ?string $message, float $start, string $rid): array
{
    return ['ok' => $ok, 'http' => $http, 'data' => $data, 'error_code' => $code, 'message' => $message,
            'ms' => (int)round((microtime(true) - $start) * 1000), 'request_id' => $rid];
}

function ai_request(string $method, string $path, array $opts = []): array
{
    $start = microtime(true);
    $rid = new_request_id();
    $operation = (string)($opts['operation'] ?? trim($path, '/'));

    $finish = function (array $r) use ($operation) {
        api_log($r['request_id'], $operation, 'ai_service', $r['ok'] ? 'ok' : ($r['error_code'] === 'AI_TIMEOUT' ? 'timeout' : 'error'),
            $r['http'] ?: null, $r['ms'], $r['error_code']);
        return $r;
    };

    if (!function_exists('curl_init')) {
        return $finish(ai_result(false, 0, null, 'CURL_MISSING',
            'The PHP cURL extension is not enabled. In XAMPP, enable extension=curl in php.ini and restart Apache.', $start, $rid));
    }

    $base = rtrim((string)setting('ai.backend_url', 'http://127.0.0.1:8000'), '/');
    $secret = (string)setting('ai.api_secret', '');
    $timeout = (int)($opts['timeout'] ?? setting_int('ai.timeout_sec', 120));

    $headers = ['Accept: application/json', 'X-Request-ID: ' . $rid];
    if ($secret !== '') {
        $headers[] = 'X-API-Secret: ' . $secret;
    }

    $ch = curl_init($base . $path);
    curl_setopt_array($ch, [
        CURLOPT_CUSTOMREQUEST  => $method,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT        => max(2, $timeout),
        CURLOPT_FOLLOWLOCATION => false,
    ]);
    if (isset($opts['file'])) {                       // multipart upload: ['path'=>, 'name'=>, 'mime'=>, 'fields'=>[]]
        $f = $opts['file'];
        $fields = ($f['fields'] ?? []) + ['file' => new CURLFile($f['path'], $f['mime'] ?? 'application/octet-stream', $f['name'] ?? basename($f['path']))];
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
    } elseif (isset($opts['json'])) {
        $headers[] = 'Content-Type: application/json';
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($opts['json'], JSON_UNESCAPED_UNICODE));
    }
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $body = curl_exec($ch);
    $errno = curl_errno($ch);
    $http = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);

    if ($errno !== 0 || $body === false) {
        $timedOut = ($errno === 28);
        return $finish(ai_result(false, 0, null, $timedOut ? 'AI_TIMEOUT' : 'AI_UNREACHABLE',
            $timedOut ? 'The AI service took too long to answer.'
                      : 'The AI service is not reachable. Check that it is running and that the backend URL in Settings is correct.',
            $start, $rid));
    }
    $data = json_decode((string)$body, true);
    if (!is_array($data)) {
        return $finish(ai_result(false, $http, null, 'AI_BAD_RESPONSE', 'The AI service returned an unreadable response.', $start, $rid));
    }
    if (empty($data['success'])) {
        return $finish(ai_result(false, $http, $data, (string)($data['error_code'] ?? 'AI_ERROR'),
            (string)($data['message'] ?? 'The AI service reported an error.'), $start, $rid));
    }
    return $finish(ai_result(true, $http, $data, null, null, $start, $rid));
}

function ai_health(): array
{
    return ai_request('GET', '/health', ['timeout' => 4, 'operation' => 'health']);
}

function ai_models(): array
{
    return ai_request('GET', '/models', ['timeout' => 8, 'operation' => 'models']);
}

function ai_system_test(bool $loadModels = false): array
{
    return ai_request('POST', '/system-test', ['json' => ['load_models' => $loadModels], 'timeout' => $loadModels ? 600 : 20,
                                              'operation' => 'system-test']);
}

function ai_asr(string $path, string $name, string $mime, string $language): array
{
    return ai_request('POST', '/asr', ['file' => ['path' => $path, 'name' => $name, 'mime' => $mime, 'fields' => ['language' => $language]],
                                       'operation' => 'asr']);
}
