<?php
declare(strict_types=1);

define('APP_ROOT', dirname(__DIR__));
$GLOBALS['ARC_CONFIG'] = require APP_ROOT . '/config.php';

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/settings.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/metrics.php';
require_once __DIR__ . '/ai_client.php';

date_default_timezone_set('Africa/Lagos');
mb_internal_encoding('UTF-8');

header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: same-origin');

if (session_status() === PHP_SESSION_NONE) {
    session_name('arc_nbridge');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => base_path() === '' ? '/' : base_path(),
        'httponly' => true,
        'samesite' => 'Lax',
        'secure'   => is_https(),
    ]);
    session_start();
}

set_exception_handler(function (Throwable $e) {
    error_log('ARC N-BRIDGE: ' . get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    $detail = cfg('debug') ? $e->getMessage() : 'Unexpected server error. Details were written to the PHP error log.';
    if (!headers_sent()) {
        http_response_code(500);
    }
    if (wants_json()) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'error_code' => 'SERVER_ERROR', 'message' => $detail]);
    } else {
        echo '<!doctype html><meta charset="utf-8"><title>Error</title><body style="font-family:sans-serif;max-width:640px;margin:10vh auto">'
           . '<h2>Something went wrong</h2><p>' . htmlspecialchars($detail, ENT_QUOTES, 'UTF-8') . '</p></body>';
    }
});
