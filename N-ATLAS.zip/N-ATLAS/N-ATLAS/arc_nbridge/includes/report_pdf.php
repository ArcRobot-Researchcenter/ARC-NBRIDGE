<?php
declare(strict_types=1);

require_once __DIR__ . '/export.php';

/**
 * Builds the summary PDF from report_summary() output plus a few evaluated examples.
 * @param array $meta ['app'=>, 'version'=>, 'generated_by'=>, 'generated_at'=>]
 */
function report_pdf(array $s, array $examples, array $meta): string
{
    $pdf = new SimplePdf();
    $L = 40.0;
    $W = SimplePdf::W - 2 * $L;
    $green = [0.06, 0.48, 0.31];
    $dark = [0.04, 0.24, 0.17];
    $grey = [0.4, 0.46, 0.43];
    $y = 0.0;

    $space = function (float $need) use (&$y, $pdf): void {
        if ($y + $need > 790) {
            $pdf->addPage();
            $y = 50.0;
        }
    };
    $h2 = function (string $t) use (&$y, $pdf, $space, $L, $W, $green): void {
        $space(90);
        $y += 8;
        $pdf->text($L, $y + 12, $t, 13, true, $green);
        $pdf->line($L, $y + 18, $L + $W, $y + 18, [0.06, 0.48, 0.31], 0.8);
        $y += 30;
    };
    $para = function (string $t, float $size = 9, array $rgb = [0.09, 0.19, 0.16]) use (&$y, $pdf, $space, $L, $W): void {
        foreach (SimplePdf::wrap($t, $W, $size) as $line) {
            $space($size + 5);
            $pdf->text($L, $y + $size, $line, $size, false, $rgb);
            $y += $size + 4;
        }
        $y += 3;
    };
    /** @param array<int, array{0:string,1:float,2:string}> $cols label, width, align (l|r) */
    $table = function (array $cols, array $rows) use (&$y, $pdf, $space, $L, $W, $grey): void {
        $draw = function (array $cells, bool $head, bool $shade) use (&$y, $pdf, $L, $cols): void {
            if ($head) {
                $pdf->rect($L, $y, array_sum(array_column($cols, 1)), 17, [0.85, 0.94, 0.9]);
            } elseif ($shade) {
                $pdf->rect($L, $y, array_sum(array_column($cols, 1)), 15, [0.965, 0.98, 0.972]);
            }
            $x = $L;
            foreach ($cols as $i => [$label, $w, $align]) {
                $txt = SimplePdf::fit((string)$cells[$i], $w - 8, 8.5, $head);
                $tx = $align === 'r' ? $x + $w - 4 - SimplePdf::width($txt, 8.5, $head) : $x + 4;
                $pdf->text($tx, $y + ($head ? 12 : 11), $txt, 8.5, $head);
                $x += $w;
            }
            $y += $head ? 17 : 15;
        };
        $header = array_column($cols, 0);
        $space(60);
        $draw($header, true, false);
        foreach ($rows as $n => $r) {
            if ($y + 16 > 790) {
                $pdf->addPage();
                $y = 50.0;
                $draw($header, true, false);
            }
            $draw($r, false, $n % 2 === 1);
        }
        $y += 6;
    };
    $pct = function ($v, int $d = 1): string { return $v === null ? '-' : number_format((float)$v * 100, $d) . '%'; };
    $num = function ($v, int $d = 0): string { return $v === null ? '-' : number_format((float)$v, $d); };

    // ---- title band
    $pdf->rect(0, 0, SimplePdf::W, 84, $green);
    $pdf->rect(0, 84, SimplePdf::W, 4, [0.88, 0.65, 0.15]);
    $pdf->text($L, 38, $meta['app'] . ' - Evaluation report', 20, true, [1, 1, 1]);
    $pdf->text($L, 60, 'Nigerian multilingual voice communication, built on N-ATLaS models', 10, false, [0.85, 0.95, 0.9]);
    $y = 104.0;

    $f = $s['filters'];
    $period = ($f['date_from'] ?: 'start') . ' to ' . ($f['date_to'] ?: 'today');
    $para('Generated ' . $meta['generated_at'] . ' by ' . $meta['generated_by'] . '. Version ' . $meta['version'] . '.', 9, $grey);
    $para('Period: ' . $period . '. Language filter: ' . ($f['language'] !== '' ? LANGS[$f['language']] : 'all four languages') . '. '
        . ($f['include_demo'] ? 'Demo records ARE included.' : 'Demo records are excluded.')
        . ' Records of participants who withdrew consent are always excluded.', 9, $grey);
    if (!empty($s['date_range']['first'])) {
        $para('Records in this report span ' . $s['date_range']['first'] . ' to ' . $s['date_range']['last'] . '.', 9, $grey);
    }

    // ---- headline numbers
    $asrTotal = array_sum(array_column($s['asr_by_language'], 'total'));
    $asrEval = array_sum(array_column($s['asr_by_language'], 'evaluated'));
    $trOk = array_sum(array_column($s['translation_by_pair'], 'ok'));
    $trAll = array_sum(array_column($s['translation_by_pair'], 'total'));
    $ttsOk = array_sum(array_column($s['tts_by_language'], 'ok'));
    $boxes = [[(string)$asrTotal, 'speech-to-text tests'], [(string)$asrEval, 'evaluated by a person'], [$trOk . ' / ' . $trAll, 'translations succeeded'],
              [(string)$ttsOk, 'voice outputs made'], [(string)$s['turns']['conversations'], 'conversations'], [(string)$s['turns']['total'], 'conversation turns'],
              [(string)$s['participants'], 'participants with consent'], [$pct($s['turns']['edited_share'], 0), 'turns edited by speaker']];
    $h2('Overview');
    $bw = ($W - 30) / 4;
    foreach (array_chunk($boxes, 4) as $row) {
        $space(60);
        foreach ($row as $i => [$big, $lab]) {
            $x = $L + $i * ($bw + 10);
            $pdf->rect($x, $y, $bw, 48, [0.945, 0.975, 0.96]);
            $pdf->text($x + 8, $y + 24, SimplePdf::fit($big, $bw - 12, 17, true), 17, true, $dark);
            $pdf->text($x + 8, $y + 39, SimplePdf::fit($lab, $bw - 12, 7.5), 7.5, false, $grey);
        }
        $y += 58;
    }

    // ---- speech to text
    $h2('Speech to text (ASR) by language');
    if (!$s['asr_by_language']) {
        $para('No speech-to-text tests match these filters.');
    } else {
        $rows = [];
        foreach (LANGS as $code => $name) {
            if (!isset($s['asr_by_language'][$code])) {
                continue;
            }
            $a = $s['asr_by_language'][$code];
            $rows[] = [$name, (string)$a['total'], (string)$a['evaluated'], (string)$a['with_reference'], (string)$a['correct'], (string)$a['partial'],
                       (string)$a['incorrect'], $pct($a['mean_wer']), $pct($a['mean_cer']), $num($a['mean_rating'], 1), $num($a['mean_ms'])];
        }
        $table([['Language', 134, 'l'], ['Tests', 36, 'r'], ['Eval.', 36, 'r'], ['Ref.', 30, 'r'], ['Correct', 44, 'r'], ['Partial', 40, 'r'], ['Wrong', 38, 'r'],
                ['Mean WER', 58, 'r'], ['Mean CER', 58, 'r'], ['Rating', 40, 'r']], array_map(function ($r) { return array_slice($r, 0, 10); }, $rows));
        $para('Eval. = tests a person evaluated. Ref. = tests that have a reference transcript; WER and CER exist only for those. Mean WER and CER are the average of '
            . 'per-clip rates (each clip counts equally). Verdicts and ratings are human judgements.', 8, $grey);

        $withWer = array_filter($s['asr_by_language'], function ($a) { return $a['mean_wer'] !== null; });
        if ($withWer) {
            $space(30 + 22 * count($withWer));
            $pdf->text($L, $y + 10, 'Mean word error rate by language (lower is better)', 9, true);
            $y += 18;
            $scale = max(1.0, max(array_column($withWer, 'mean_wer')));
            foreach (LANGS as $code => $name) {
                if (!isset($withWer[$code])) {
                    continue;
                }
                $v = $withWer[$code]['mean_wer'];
                $pdf->text($L, $y + 10, $name, 8.5);
                $barW = ($W - 190) * min(1.0, $v / $scale);
                $pdf->rect($L + 130, $y + 1, $W - 190, 12, [0.93, 0.95, 0.94]);
                $pdf->rect($L + 130, $y + 1, max(1.0, $barW), 12, $v <= 0.25 ? [0.12, 0.66, 0.44] : ($v <= 0.5 ? [0.88, 0.65, 0.15] : [0.84, 0.27, 0.36]));
                $pdf->text($L + 130 + $W - 182, $y + 10, $pct($v), 8.5, true);
                $y += 20;
            }
            $y += 4;
        }
    }

    // ---- translation
    $h2('Translation');
    if (!$s['translation_by_pair']) {
        $para('No translations match these filters.');
    } else {
        $rows = [];
        foreach ($s['translation_by_pair'] as $t) {
            $rows[] = [(LANGS[$t['source']] ?? $t['source']) . ' to ' . (LANGS[$t['target']] ?? $t['target']), (string)$t['total'], (string)$t['ok'],
                       (string)$t['failed'], (string)$t['direct'], (string)$t['pivot'], $num($t['mean_ms'])];
        }
        $table([['Pair', 190, 'l'], ['Total', 50, 'r'], ['OK', 45, 'r'], ['Failed', 50, 'r'], ['Direct', 50, 'r'], ['Pivot', 50, 'r'], ['Mean ms', 80, 'r']], $rows);
        $para('Translations are machine output and were not scored for quality here. Quality needs human judgement of each pair.', 8, $grey);
    }

    // ---- text to speech
    $h2('Text to speech');
    if (!$s['tts_by_language']) {
        $para('No voice outputs match these filters.');
    } else {
        $rows = [];
        foreach (LANGS as $code => $name) {
            if (isset($s['tts_by_language'][$code])) {
                $t = $s['tts_by_language'][$code];
                $rows[] = [$name, (string)$t['ok'], (string)$t['failed'], (string)$t['unavailable']];
            }
        }
        $table([['Language', 215, 'l'], ['Made', 100, 'r'], ['Failed', 100, 'r'], ['No voice available', 100, 'r']], $rows);
    }

    // ---- VoiceBridge
    $h2('VoiceBridge conversations');
    $t = $s['turns'];
    $para($t['total'] . ' turns in ' . $t['conversations'] . ' conversations. ' . $t['confirmed'] . ' turns were confirmed by the speaker, and the speaker changed the '
        . 'recognised text in ' . $t['edited'] . ' of them (' . $pct($t['edited_share']) . '). ' . $t['translated'] . ' turns reached translation and '
        . $t['spoken'] . ' were also spoken aloud. ' . $t['failed'] . ' turns failed at speech recognition.');

    // ---- models
    $h2('Models recorded in the data');
    $list = function (array $a): string { return $a ? implode(', ', $a) : 'none recorded'; };
    $para('Speech recognition: ' . $list($s['models']['asr']));
    $para('Translation: ' . $list($s['models']['translation']));
    $para('Text to speech: ' . $list($s['models']['tts']));

    // ---- examples
    if ($examples) {
        $h2('Examples of evaluated clips');
        $rows = [];
        foreach ($examples as $e) {
            $rows[] = [$e['test_code'], $e['language_code'], (string)$e['verdict'], $pct($e['wer']), (string)$e['reference_text'], (string)$e['natlas_text']];
        }
        $table([['Test', 62, 'l'], ['Lang', 30, 'l'], ['Verdict', 50, 'l'], ['WER', 42, 'r'], ['Reference (what was said)', 165, 'l'], ['Model output', 166, 'l']], $rows);
        $para('The PDF uses built-in fonts, so Hausa hooked letters and Yoruba tone marks are shown as plain letters here. The CSV and Excel exports contain the exact text.', 8, $grey);
    }

    // ---- method note
    $h2('How to read this report');
    $para('WER and CER compare the raw model output with a reference transcript typed by an evaluator, after lower-casing and removing punctuation (letters and '
        . 'tone marks are kept). Only tests with a reference are scored. This is a small, prototype evaluation set and not a benchmark: do not generalise it to '
        . 'all speakers, accents or noise conditions.');
    $para('Models are used under the NCAIR1 N-ATLaS terms of use on Hugging Face.');

    // ---- footers
    $n = $pdf->pageCount();
    for ($i = 0; $i < $n; $i++) {
        $pdf->setPage($i);
        $pdf->line($L, 812, $L + $W, 812);
        $pdf->text($L, 826, $meta['app'] . ' - research prototype report', 7.5, false, $grey);
        $label = 'Page ' . ($i + 1) . ' of ' . $n;
        $pdf->text($L + $W - SimplePdf::width($label, 7.5), 826, $label, 7.5, false, $grey);
    }
    return $pdf->output($meta['app'] . ' evaluation report');
}
