/* ARC N-BRIDGE Evaluation Lab. Plain JavaScript, no build step.
   All server calls go to evaluation_lab.php. The AI service secret is never available here. */
(function () {
    'use strict';
    var cfgEl = document.getElementById('lab-config');
    if (!cfgEl) { return; }
    var CFG = {
        endpoint: cfgEl.dataset.endpoint,
        csrf: cfgEl.dataset.csrf,
        maxSeconds: parseInt(cfgEl.dataset.maxSeconds, 10) || 30,
        maxMb: parseInt(cfgEl.dataset.maxMb, 10) || 10
    };

    function $(id) { return document.getElementById(id); }

    function show(el, type, text) {
        if (!el) { return; }
        el.innerHTML = '';
        if (!text) { return; }
        var d = document.createElement('div');
        d.className = 'alert alert-' + type + ' mb-0 py-2';
        d.textContent = text;           // textContent: never interpret server text as HTML
        el.appendChild(d);
    }

    function busy(btn, on, label) {
        if (!btn) { return; }
        if (on) {
            btn.dataset.html = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>' + (label || 'Working…');
        } else {
            btn.disabled = false;
            if (btn.dataset.html) { btn.innerHTML = btn.dataset.html; }
        }
    }

    /** POSTs FormData and always resolves to a {success, ...} object, even when the server or network fails. */
    function post(fd) {
        return fetch(CFG.endpoint, {
            method: 'POST',
            body: fd,
            credentials: 'same-origin',
            headers: { 'X-CSRF-Token': CFG.csrf, 'X-Requested-With': 'fetch', 'Accept': 'application/json' }
        }).then(function (res) {
            return res.text().then(function (text) {
                try { return JSON.parse(text); } catch (e) {
                    return { success: false, error_code: 'BAD_RESPONSE',
                             message: 'The server sent an unreadable answer (HTTP ' + res.status + '). Check the PHP error log.' };
                }
            });
        }).catch(function () {
            return { success: false, error_code: 'NETWORK', message: 'Could not reach the server. Check your connection and that Apache is running.' };
        });
    }

    function pct(v) { return (v === null || v === undefined) ? '—' : (v * 100).toFixed(1) + '%'; }

    /* ======================================================= speech to text */
    if ($('asr-go')) {
        var recorder = null, stream = null, chunks = [], timer = null, startedAt = 0, discarded = false;
        var clip = null;                // {blob|file, name, source}
        var go = $('asr-go');

        function setClip(blob, name, source) {
            clip = { data: blob, name: name, source: source };
            go.disabled = false;
            $('rec-discard').disabled = (source !== 'microphone');
            $('up-clear').classList.toggle('d-none', source !== 'upload');
        }

        function clearPreview(el) {
            if (el.src && el.src.indexOf('blob:') === 0) { URL.revokeObjectURL(el.src); }
            el.removeAttribute('src');
            el.load();
            el.classList.add('d-none');
        }

        /** Throws away the current recording or chosen file so a new one can be made. */
        function resetClip() {
            clip = null;
            chunks = [];
            go.disabled = true;
            clearPreview($('rec-preview'));
            clearPreview($('up-preview'));
            $('up-file').value = '';
            $('up-clear').classList.add('d-none');
            $('rec-status').textContent = '';
            $('rec-start').disabled = false;
            $('rec-stop').disabled = true;
            $('rec-discard').disabled = true;
            show($('asr-msg'), 'info', '');
        }

        function extFor(mime) {
            if (mime.indexOf('webm') > -1) { return 'webm'; }
            if (mime.indexOf('ogg') > -1) { return 'ogg'; }
            if (mime.indexOf('mp4') > -1) { return 'm4a'; }
            return 'webm';
        }

        function pickMime() {
            var wanted = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus', 'audio/mp4'];
            if (!window.MediaRecorder) { return ''; }
            for (var i = 0; i < wanted.length; i++) {
                if (MediaRecorder.isTypeSupported(wanted[i])) { return wanted[i]; }
            }
            return '';
        }

        function stopTimer() { if (timer) { clearInterval(timer); timer = null; } }

        function releaseStream() {
            if (stream) { stream.getTracks().forEach(function (t) { t.stop(); }); stream = null; }
        }

        $('rec-start').addEventListener('click', function () {
            var status = $('rec-status');
            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || !window.MediaRecorder) {
                show($('asr-msg'), 'warning', 'This browser cannot record audio here. Use the Upload tab, or open the site at http://localhost.');
                return;
            }
            show($('asr-msg'), 'info', '');
            navigator.mediaDevices.getUserMedia({ audio: true }).then(function (s) {
                stream = s;
                chunks = [];
                var mime = pickMime();
                recorder = mime ? new MediaRecorder(s, { mimeType: mime }) : new MediaRecorder(s);
                recorder.ondataavailable = function (ev) { if (ev.data && ev.data.size) { chunks.push(ev.data); } };
                recorder.onstop = function () {
                    stopTimer();
                    releaseStream();
                    if (discarded) { discarded = false; resetClip(); return; }
                    var type = recorder.mimeType || mime || 'audio/webm';
                    var blob = new Blob(chunks, { type: type });
                    var prev = $('rec-preview');
                    prev.src = URL.createObjectURL(blob);
                    prev.classList.remove('d-none');
                    status.textContent = 'Recorded ' + ((Date.now() - startedAt) / 1000).toFixed(1) + ' s';
                    $('rec-start').disabled = false;
                    $('rec-stop').disabled = true;
                    if (blob.size > 0) { setClip(blob, 'recording.' + extFor(type), 'microphone'); }
                    else { show($('asr-msg'), 'warning', 'Nothing was recorded. Please try again.'); }
                };
                recorder.start();
                startedAt = Date.now();
                $('rec-start').disabled = true;
                $('rec-stop').disabled = false;
                $('rec-discard').disabled = false;
                go.disabled = true;
                clip = null;
                status.innerHTML = '<span class="rec-dot"></span> Recording… 0 s';
                timer = setInterval(function () {
                    var sec = (Date.now() - startedAt) / 1000;
                    status.innerHTML = '<span class="rec-dot"></span> Recording… ' + Math.floor(sec) + ' s';
                    if (sec >= CFG.maxSeconds && recorder && recorder.state === 'recording') { recorder.stop(); }
                }, 250);
            }).catch(function (err) {
                var denied = err && (err.name === 'NotAllowedError' || err.name === 'SecurityError');
                show($('asr-msg'), 'warning', denied ? 'Microphone permission was refused. Allow it in the browser address bar, or use the Upload tab.'
                                                     : 'No microphone could be opened. Plug one in, or use the Upload tab.');
            });
        });

        $('rec-stop').addEventListener('click', function () {
            if (recorder && recorder.state === 'recording') { recorder.stop(); }
        });

        $('rec-discard').addEventListener('click', function () {
            if (recorder && recorder.state === 'recording') {
                discarded = true;        // onstop will clean everything up
                recorder.stop();
                return;
            }
            resetClip();
        });

        $('up-clear').addEventListener('click', resetClip);

        $('up-file').addEventListener('change', function (ev) {
            var f = ev.target.files && ev.target.files[0];
            var prev = $('up-preview');
            if (!f) { prev.classList.add('d-none'); go.disabled = true; clip = null; return; }
            if (f.size > CFG.maxMb * 1024 * 1024) {
                show($('asr-msg'), 'warning', 'That file is larger than ' + CFG.maxMb + ' MB.');
                ev.target.value = ''; prev.classList.add('d-none'); go.disabled = true; clip = null; return;
            }
            show($('asr-msg'), 'info', '');
            prev.src = URL.createObjectURL(f);
            prev.classList.remove('d-none');
            setClip(f, f.name, 'upload');
        });

        go.addEventListener('click', function () {
            if (!clip) { return; }
            var fd = new FormData();
            fd.append('action', 'asr_run');
            fd.append('language', $('asr-lang').value);
            fd.append('source', clip.source);
            fd.append('audio', clip.data, clip.name);
            show($('asr-msg'), 'info', 'Sending the clip to the AI service. The first request for a language loads its model and can take a few minutes.');
            busy(go, true, 'Transcribing…');
            post(fd).then(function (r) {
                if (r.success) { window.location.href = r.redirect; return; }
                busy(go, false);
                show($('asr-msg'), 'danger', r.message || 'The transcription failed.');
            });
        });
    }

    /* =========================================================== translation */
    if ($('tr-go')) {
        $('tr-go').addEventListener('click', function () {
            var btn = $('tr-go');
            var fd = new FormData();
            fd.append('action', 'translate_run');
            fd.append('source_language', $('tr-src').value);
            fd.append('target_language', $('tr-tgt').value);
            fd.append('engine', $('tr-engine').value);
            fd.append('mode', $('tr-mode').value);
            fd.append('text', $('tr-text').value);
            $('tr-out').classList.add('d-none');
            show($('tr-msg'), 'info', 'Translating… the first request loads the model and can take a while.');
            busy(btn, true, 'Translating…');
            post(fd).then(function (r) {
                busy(btn, false);
                if (!r.success) { show($('tr-msg'), 'danger', r.message || 'The translation failed.'); return; }
                show($('tr-msg'), 'info', '');
                $('tr-text-out').textContent = r.translation;
                $('tr-meta').textContent = (r.engine || '') + ' · ' + (r.model || '') + ' · ' + (r.mode || '') + ' · model ' +
                    (r.processing_ms === null ? '—' : r.processing_ms + ' ms') + ' · round trip ' + r.roundtrip_ms + ' ms';
                var wrap = $('tr-pivot-wrap');
                if (r.pivot_text) { $('tr-pivot').textContent = r.pivot_text; wrap.classList.remove('d-none'); } else { wrap.classList.add('d-none'); }
                $('tr-out').classList.remove('d-none');
            });
        });
    }

    /* ============================================================ text to speech */
    if ($('tts-go')) {
        $('tts-go').addEventListener('click', function () {
            var btn = $('tts-go');
            var fd = new FormData();
            fd.append('action', 'tts_run');
            fd.append('language', $('tts-lang').value);
            fd.append('text', $('tts-text').value);
            var audio = $('tts-audio');
            audio.classList.add('d-none');
            $('tts-meta').textContent = '';
            show($('tts-msg'), 'info', 'Generating speech… the first request loads the voice model and can take a while.');
            busy(btn, true, 'Generating…');
            post(fd).then(function (r) {
                busy(btn, false);
                if (!r.success) { show($('tts-msg'), 'danger', r.message || 'Speech generation failed.'); return; }
                show($('tts-msg'), 'info', '');
                audio.src = 'data:' + r.mime + ';base64,' + r.audio_base64;
                audio.classList.remove('d-none');
                audio.play().catch(function () { /* autoplay may be blocked; the controls are visible */ });
                $('tts-meta').textContent = (r.model || '') + ' · model ' + (r.processing_ms === null ? '—' : r.processing_ms + ' ms') +
                    ' · round trip ' + r.roundtrip_ms + ' ms';
            });
        });
    }

    /* =========================================================== evaluation form */
    var form = $('eval-form');
    if (form) {
        var copy = $('copy-model-text');
        if (copy) {
            copy.addEventListener('click', function () { $('corrected_text').value = copy.dataset.text || ''; });
        }
        form.addEventListener('submit', function (ev) {
            ev.preventDefault();
            var btn = $('eval-save');
            var fd = new FormData(form);
            fd.append('action', 'asr_evaluate');
            busy(btn, true, 'Saving…');
            post(fd).then(function (r) {
                busy(btn, false);
                if (!r.success) { show($('eval-msg'), 'danger', r.message || 'The evaluation could not be saved.'); return; }
                $('wer-out').textContent = pct(r.wer);
                $('cer-out').textContent = pct(r.cer);
                show($('eval-msg'), 'success', 'Evaluation saved.');
            });
        });
    }
})();
