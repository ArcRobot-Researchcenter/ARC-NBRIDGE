/* ARC N-BRIDGE VoiceBridge. Plain JavaScript, no build step. All server calls go to voicebridge.php.
   Server text is only ever inserted with textContent, never as HTML. The AI service secret is never available here. */
(function () {
    'use strict';
    var cfgEl = document.getElementById('vb-config');
    if (!cfgEl) { return; }
    var CFG = {
        endpoint: cfgEl.dataset.endpoint, csrf: cfgEl.dataset.csrf, conv: parseInt(cfgEl.dataset.conversation, 10) || 0,
        active: cfgEl.dataset.active === '1', maxSeconds: parseInt(cfgEl.dataset.maxSeconds, 10) || 30, tts: cfgEl.dataset.tts === '1',
        autoTranslate: cfgEl.dataset.autoTranslate !== '0', autoTts: cfgEl.dataset.autoTts !== '0',
        names: { A: cfgEl.dataset.nameA || 'Person A', B: cfgEl.dataset.nameB || 'Person B' }
    };
    var ERRORS = {
        MODEL_NOT_DOWNLOADED: 'The AI service does not have this model downloaded yet.',
        MODEL_ACCESS_DENIED: 'The AI service was refused access to the model on Hugging Face.',
        AI_UNREACHABLE: 'The AI service is not reachable.', AI_TIMEOUT: 'The AI service took too long to answer.',
        TTS_DISABLED: 'Voice output is switched off.', MODEL_LOAD_FAILED: 'The model could not be loaded.', DEPENDENCY_MISSING: 'The AI service is missing its AI libraries.'
    };

    function $(id) { return document.getElementById(id); }
    function el(tag, cls, text) { var n = document.createElement(tag); if (cls) { n.className = cls; } if (text !== undefined) { n.textContent = text; } return n; }

    function show(target, type, text) {
        if (!target) { return; }
        target.innerHTML = '';
        if (!text) { return; }
        var d = el('div', 'alert alert-' + type + ' mb-0 py-2', text);
        target.appendChild(d);
    }

    function busy(btn, on, label) {
        if (!btn) { return; }
        if (on) { btn.dataset.html = btn.innerHTML; btn.disabled = true; btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>' + (label || 'Working…'); }
        else { btn.disabled = false; if (btn.dataset.html) { btn.innerHTML = btn.dataset.html; } }
    }

    /** POSTs FormData and always resolves to a {success, ...} object, even when the server or network fails. */
    function post(fd) {
        return fetch(CFG.endpoint, { method: 'POST', body: fd, credentials: 'same-origin',
            headers: { 'X-CSRF-Token': CFG.csrf, 'X-Requested-With': 'fetch', 'Accept': 'application/json' } })
            .then(function (res) {
                return res.text().then(function (text) {
                    try { return JSON.parse(text); } catch (e) {
                        return { success: false, error_code: 'BAD_RESPONSE', message: 'The server sent an unreadable answer (HTTP ' + res.status + '). Check the PHP error log.' };
                    }
                });
            })
            .catch(function () { return { success: false, error_code: 'NETWORK', message: 'Could not reach the server. Check your connection and that Apache is running.' }; });
    }

    function form(action, fields) {
        var fd = new FormData();
        fd.append('action', action);
        Object.keys(fields || {}).forEach(function (k) { fd.append(k, fields[k]); });
        return fd;
    }

    /* =============================================================== list page */
    var createBtn = $('vb-create');
    if (createBtn) {
        createBtn.addEventListener('click', function () {
            var f = { lang_a: $('new-a').value, lang_b: $('new-b').value };
            if ($('new-pa')) { f.person_a = $('new-pa').value; f.person_b = $('new-pb').value; }
            busy(createBtn, true, 'Starting…');
            post(form('conv_create', f)).then(function (r) {
                if (r.success) { window.location.href = r.redirect; return; }
                busy(createBtn, false);
                show($('vb-msg'), 'danger', r.message || 'The conversation could not be started.');
            });
        });
    }

    /* ======================================================= conversation page */
    var timeline = $('vb-timeline');
    if (!timeline) { return; }
    var turns = {};
    var statusBox = $('vb-status');

    function note(id, type, text) {
        var n = document.querySelector('#turn-' + id + ' .vb-note');
        if (n) { show(n, type, text); }
    }

    function errText(r) { return r.message || ERRORS[r.error_code] || 'Something went wrong (' + (r.error_code || 'unknown') + ').'; }

    function upsert(t) {
        if (!t) { return; }
        turns[t.id] = t;
        var old = $('turn-' + t.id);
        var node = build(t);
        if (old) { old.replaceWith(node); } else { timeline.appendChild(node); }
        var empty = $('vb-empty');
        if (empty) { empty.remove(); }
        node.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }

    function audioEl(src, cls) {
        var a = el('audio', 'vb-audio ' + cls);
        a.controls = true; a.preload = 'none'; a.src = src;
        return a;
    }

    function button(label, cls, fn) {
        var b = el('button', 'btn btn-sm ' + cls, label);
        b.type = 'button';
        b.addEventListener('click', function () { fn(b); });
        return b;
    }

    function build(t) {
        var row = el('div', 'vb-turn vb-turn-' + t.speaker);
        row.id = 'turn-' + t.id;
        var bubble = el('div', 'vb-bubble');
        var meta = el('div', 'vb-meta', '#' + t.turn_no + ' · Person ' + t.speaker + ' · ' + t.source_name);
        if (t.was_edited) { meta.appendChild(el('span', 'badge text-bg-warning ms-2', 'edited by speaker')); }
        bubble.appendChild(meta);

        var heard = t.confirmed_text || t.asr_text;
        if (t.status === 'failed') {
            bubble.appendChild(el('div', 'vb-orig text-danger', 'The speech could not be recognised.'));
        } else if (heard) {
            bubble.appendChild(el('div', 'vb-orig', heard));
        } else {
            bubble.appendChild(el('div', 'vb-orig text-muted', '(nothing was recognised)'));
        }
        if (t.status === 'transcribed' && heard) { bubble.appendChild(el('div', 'small text-muted', 'Waiting for the speaker to confirm this text.')); }
        if (t.audio_url) { bubble.appendChild(audioEl(t.audio_url, 'vb-audio-src')); }

        var tr = t.translation;
        if (tr && tr.status === 'ok') {
            bubble.appendChild(el('div', 'vb-arrow', '↓ ' + t.target_name + (tr.mode === 'pivot' ? ' (through English)' : '')));
            bubble.appendChild(el('div', 'vb-trans', tr.text));
            if (tr.pivot_text) { bubble.appendChild(el('div', 'small text-muted', 'English in between: ' + tr.pivot_text)); }
            if (t.tts && t.tts.audio_url) { bubble.appendChild(audioEl(t.tts.audio_url, 'vb-tts-audio')); }
            else if (t.tts && t.tts.status !== 'ok') { bubble.appendChild(el('div', 'small text-muted', 'No voice: ' + (ERRORS[t.tts.error_code] || t.tts.status))); }
        } else if (tr && tr.status === 'failed') {
            bubble.appendChild(el('div', 'small text-danger', 'Translation failed: ' + (ERRORS[tr.error_code] || tr.error_code || 'unknown error')));
        }

        var actions = el('div', 'vb-actions');
        if (CFG.active) {
            if (t.status === 'failed') { actions.appendChild(button('Try again', 'btn-outline-danger', function (b) { retryAsr(t.id, b); })); }
            if (t.status === 'transcribed' && heard) { actions.appendChild(button('Review text', 'btn-outline-arc', function () { openReview(t); })); }
            if (t.status === 'confirmed') { actions.appendChild(button('Translate', 'btn-arc', function (b) { doTranslate(t.id, b).then(function (ok) { if (ok && CFG.autoTts && CFG.tts) { doTts(t.id, true); } }); })); }
            if (t.status === 'translated' || t.status === 'spoken') {
                if (CFG.tts) { actions.appendChild(button(t.status === 'spoken' ? 'Speak again' : 'Speak it', 'btn-arc', function (b) { doTts(t.id, true, b); })); }
                actions.appendChild(button('Translate again', 'btn-outline-secondary', function (b) { doTranslate(t.id, b); }));
            }
        }
        bubble.appendChild(actions);
        bubble.appendChild(el('div', 'vb-note mt-2'));
        row.appendChild(bubble);
        return row;
    }

    function route() { return $('vb-route') ? $('vb-route').value : 'direct'; }

    function step(action, fields, btn, label) {
        busy(btn, true, label);
        return post(form(action, fields)).then(function (r) {
            busy(btn, false);
            if (r.turn) { upsert(r.turn); }
            return r;
        });
    }

    function retryAsr(id, btn) {
        step('turn_retry_asr', { id: id }, btn, 'Recognising…').then(function (r) {
            if (!r.success) { note(id, 'danger', errText(r)); return; }
            afterAsr(r);
        });
    }

    function doTranslate(id, btn) {
        return step('turn_translate', { id: id, mode: route() }, btn, 'Translating…').then(function (r) {
            if (!r.success) { note(id, 'danger', errText(r)); return false; }
            return true;
        });
    }

    function doTts(id, autoplay, btn) {
        return step('turn_tts', { id: id }, btn, 'Making the voice…').then(function (r) {
            if (!r.success) {
                note(id, r.error_code === 'TTS_DISABLED' ? 'info' : 'warning', errText(r) + ' The translated text is shown above.');
                return false;
            }
            if (autoplay) {
                var a = document.querySelector('#turn-' + id + ' .vb-tts-audio');
                if (a) { a.play().catch(function () { /* the browser may block autoplay; the player is visible */ }); }
            }
            return true;
        });
    }

    function chain(id) {
        if (!CFG.autoTranslate) { return; }
        doTranslate(id).then(function (ok) { if (ok && CFG.autoTts && CFG.tts) { doTts(id, true); } });
    }

    /* ---------------------------------------------------------------- review box */
    var review = $('vb-review');
    var reviewId = null;

    function openReview(t) {
        if (!review) { return; }
        reviewId = t.id;
        $('vb-review-text').value = t.confirmed_text || t.asr_text || '';
        $('vb-review-lang').textContent = '(' + t.source_name + ', Person ' + t.speaker + ')';
        var a = $('vb-review-audio');
        if (t.audio_url) { a.src = t.audio_url; a.classList.remove('d-none'); } else { a.removeAttribute('src'); a.classList.add('d-none'); }
        review.classList.remove('d-none');
        $('vb-review-text').focus();
        review.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }

    function closeReview() {
        if (!review) { return; }
        review.classList.add('d-none');
        var a = $('vb-review-audio'); a.pause(); a.removeAttribute('src');
        reviewId = null;
    }

    if ($('vb-confirm')) {
        $('vb-confirm').addEventListener('click', function () {
            var id = reviewId, btn = $('vb-confirm');
            if (!id) { return; }
            step('turn_confirm', { id: id, text: $('vb-review-text').value }, btn, 'Saving…').then(function (r) {
                if (!r.success) { show(statusBox, 'danger', errText(r)); return; }
                show(statusBox, 'info', '');
                closeReview();
                chain(id);
            });
        });
        $('vb-review-skip').addEventListener('click', closeReview);
    }

    function afterAsr(r) {
        var t = r.turn;
        if (r.empty || !(t.asr_text || t.confirmed_text)) {
            show(statusBox, 'warning', 'Nothing was recognised. Please speak again, a little closer to the microphone.');
            return;
        }
        show(statusBox, 'info', r.low_energy ? 'The recording was very quiet; check the text carefully.' : '');
        if (t.status === 'confirmed') { chain(t.id); } else { openReview(t); }
    }

    /* ------------------------------------------------------------------ recording */
    var recorder = null, stream = null, chunks = [], timer = null, startedAt = 0, side = null, recBusy = false;

    function pickMime() {
        if (!window.MediaRecorder) { return ''; }
        var wanted = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus', 'audio/mp4'];
        for (var i = 0; i < wanted.length; i++) { if (MediaRecorder.isTypeSupported(wanted[i])) { return wanted[i]; } }
        return '';
    }
    function extFor(m) { return m.indexOf('ogg') > -1 ? 'ogg' : (m.indexOf('mp4') > -1 ? 'm4a' : 'webm'); }

    function setMics(state) {   // state: 'idle' | 'recording' | 'working'
        ['A', 'B'].forEach(function (s) {
            var b = $('rec-' + s);
            if (!b) { return; }
            var mine = (side === s);
            b.disabled = (state === 'working') || (state === 'recording' && !mine);
            b.classList.toggle('recording', state === 'recording' && mine);
            b.querySelector('span').textContent = (state === 'recording' && mine) ? 'Stop' : 'Speak';
            b.querySelector('i').className = 'bi ' + ((state === 'recording' && mine) ? 'bi-stop-fill' : 'bi-mic-fill');
        });
    }

    function release() { if (stream) { stream.getTracks().forEach(function (t) { t.stop(); }); stream = null; } if (timer) { clearInterval(timer); timer = null; } }

    function upload(blob, speaker, ext) {
        setMics('working');
        show(statusBox, 'info', 'Recognising the speech. The first request for a language loads its model and can take a few minutes.');
        var fd = form('turn_asr', { conversation_id: CFG.conv, speaker: speaker });
        fd.append('audio', blob, 'recording.' + ext);
        post(fd).then(function (r) {
            side = null; setMics('idle');
            if (r.turn) { upsert(r.turn); }
            if (!r.success) { show(statusBox, 'danger', errText(r)); return; }
            afterAsr(r);
        });
    }

    function toggle(speaker) {
        if (recBusy) { return; }
        if (recorder && recorder.state === 'recording') { recorder.stop(); return; }
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || !window.MediaRecorder) {
            show(statusBox, 'warning', 'This browser cannot record audio here. Open the site at http://localhost in Chrome, Edge or Firefox.');
            return;
        }
        recBusy = true;
        navigator.mediaDevices.getUserMedia({ audio: true }).then(function (s) {
            recBusy = false;
            stream = s; chunks = []; side = speaker;
            var mime = pickMime();
            recorder = mime ? new MediaRecorder(s, { mimeType: mime }) : new MediaRecorder(s);
            recorder.ondataavailable = function (ev) { if (ev.data && ev.data.size) { chunks.push(ev.data); } };
            recorder.onstop = function () {
                release();
                var type = recorder.mimeType || mime || 'audio/webm';
                var blob = new Blob(chunks, { type: type });
                if (blob.size < 800) { side = null; setMics('idle'); show(statusBox, 'warning', 'That recording was too short. Press the button, speak, then press Stop.'); return; }
                upload(blob, speaker, extFor(type));
            };
            recorder.start();
            startedAt = Date.now();
            setMics('recording');
            timer = setInterval(function () {
                var sec = Math.floor((Date.now() - startedAt) / 1000);
                show(statusBox, 'danger', 'Recording ' + CFG.names[speaker] + '… ' + sec + ' s (stops at ' + CFG.maxSeconds + ' s)');
                if (sec >= CFG.maxSeconds && recorder.state === 'recording') { recorder.stop(); }
            }, 250);
        }).catch(function (err) {
            recBusy = false;
            var denied = err && (err.name === 'NotAllowedError' || err.name === 'SecurityError');
            show(statusBox, 'warning', denied ? 'Microphone permission was refused. Allow it in the browser address bar and try again.' : 'No microphone could be opened. Plug one in and try again.');
        });
    }

    ['A', 'B'].forEach(function (s) { var b = $('rec-' + s); if (b) { b.addEventListener('click', function () { toggle(s); }); } });

    if ($('vb-close')) {
        $('vb-close').addEventListener('click', function () {
            if (!window.confirm('End this conversation? You can still read it afterwards, but no one can speak in it again.')) { return; }
            post(form('conv_close', { id: CFG.conv })).then(function (r) { if (r.success) { window.location.href = r.redirect; } else { show(statusBox, 'danger', errText(r)); } });
        });
    }

    /* ----------------------------------------------------------------- first paint */
    try {
        JSON.parse($('vb-turns').textContent).forEach(function (t) { upsert(t); });
    } catch (e) { show(statusBox, 'warning', 'The conversation history could not be displayed.'); }
})();
