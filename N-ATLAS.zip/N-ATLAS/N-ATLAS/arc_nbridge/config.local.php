<?php
// Written by ARC N-BRIDGE setup. Contains secrets: never share or commit this file.
return array (
  'app_key' => 'NbS9z4PUTpZQKNXRMt2OBZOkm69jD6E384WDviN1Sfg=',
);
