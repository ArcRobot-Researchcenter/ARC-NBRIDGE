-- ============================================================================
-- ARC N-BRIDGE  |  MySQL / MariaDB schema  (XAMPP compatible, utf8mb4)
-- Import with phpMyAdmin (Import tab) or:  mysql -u root < schema.sql
-- No user accounts and no passwords are inserted here. The first administrator
-- is created through setup.php (password_hash) - never from SQL.
-- ============================================================================

CREATE DATABASE IF NOT EXISTS `arc_nbridge`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `arc_nbridge`;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------- roles ----
CREATE TABLE IF NOT EXISTS `roles` (
  `id`          TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`        VARCHAR(32)  NOT NULL,
  `label`       VARCHAR(64)  NOT NULL,
  `description` VARCHAR(255) NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_roles_name` (`name`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------- users ----
CREATE TABLE IF NOT EXISTS `users` (
  `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid`          CHAR(36)     NOT NULL,
  `username`      VARCHAR(64)  NOT NULL,
  `email`         VARCHAR(190) NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `full_name`     VARCHAR(120) NOT NULL,
  `role_id`       TINYINT UNSIGNED NOT NULL,
  `is_active`     TINYINT(1)   NOT NULL DEFAULT 1,
  `failed_logins` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  `locked_until`  DATETIME     NULL,
  `last_login_at` DATETIME     NULL,
  `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_uuid` (`uuid`),
  UNIQUE KEY `uq_users_username` (`username`),
  KEY `ix_users_role` (`role_id`),
  CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB;

-- ----------------------------------------------------------- evaluators ----
CREATE TABLE IF NOT EXISTS `evaluators` (
  `id`             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`        INT UNSIGNED NOT NULL,
  `organisation`   VARCHAR(160) NULL,
  `specialisation` VARCHAR(160) NULL,
  `native_languages` VARCHAR(120) NULL,
  `created_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_evaluators_user` (`user_id`),
  CONSTRAINT `fk_evaluators_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- --------------------------------------------------------- participants ----
-- Deliberately minimal personal data: no NIN, BVN, phone, address or real name.
CREATE TABLE IF NOT EXISTS `participants` (
  `id`             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code`           VARCHAR(16)  NULL,                      -- P-0001 (assigned after insert)
  `language_code`  ENUM('ha','yo','ig','en') NOT NULL,
  `age_group`      ENUM('under_18','18_25','26_35','36_50','51_65','over_65','unspecified') NOT NULL DEFAULT 'unspecified',
  `gender`         ENUM('female','male','other','prefer_not_to_say') NULL,
  `consent_status` ENUM('none','granted','withdrawn') NOT NULL DEFAULT 'none',
  `notes`          TEXT NULL,
  `is_demo`        TINYINT(1) NOT NULL DEFAULT 0,
  `created_by`     INT UNSIGNED NULL,
  `created_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_participants_code` (`code`),
  KEY `ix_participants_lang` (`language_code`),
  KEY `ix_participants_demo` (`is_demo`),
  CONSTRAINT `fk_participants_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------- consents ----
CREATE TABLE IF NOT EXISTS `consents` (
  `id`             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `participant_id` INT UNSIGNED NOT NULL,
  `consent_text`   VARCHAR(500) NOT NULL,
  `status`         ENUM('granted','withdrawn') NOT NULL,
  `recorded_by`    INT UNSIGNED NULL,
  `recorded_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_consents_participant` (`participant_id`, `recorded_at`),
  CONSTRAINT `fk_consents_participant` FOREIGN KEY (`participant_id`) REFERENCES `participants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_consents_user` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------ asr_tests ----
CREATE TABLE IF NOT EXISTS `asr_tests` (
  `id`                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `test_code`           VARCHAR(16)  NULL,                 -- ASR-000001 (assigned after insert)
  `participant_id`      INT UNSIGNED NULL,
  `evaluator_id`        INT UNSIGNED NULL,                 -- users.id of the person who ran/evaluated
  `language_code`       ENUM('ha','yo','ig','en') NOT NULL,
  `source`              ENUM('microphone','upload') NOT NULL,
  `audio_path`          VARCHAR(255) NULL,                 -- relative to STORAGE_PATH
  `audio_sha256`        CHAR(64)     NULL,
  `audio_mime`          VARCHAR(64)  NULL,
  `audio_bytes`         INT UNSIGNED NULL,
  `audio_duration_sec`  DECIMAL(8,2) NULL,
  `request_id`          VARCHAR(64)  NULL,
  `model_repo`          VARCHAR(160) NULL,
  `model_name`          VARCHAR(160) NULL,
  `natlas_text`         TEXT NULL,                          -- raw N-ATLaS output, never overwritten
  `reference_text`      TEXT NULL,
  `corrected_text`      TEXT NULL,                          -- evaluator correction
  `verdict`             ENUM('correct','partial','incorrect') NULL,
  `rating`              TINYINT UNSIGNED NULL,
  `comments`            TEXT NULL,
  `wer`                 DECIMAL(7,4) NULL,                  -- word error rate vs reference
  `cer`                 DECIMAL(7,4) NULL,                  -- character error rate vs reference
  `ai_time_ms`          INT UNSIGNED NULL,                  -- inference time reported by Python
  `roundtrip_ms`        INT UNSIGNED NULL,                  -- PHP -> Python -> PHP
  `status`              ENUM('transcribed','evaluated') NOT NULL DEFAULT 'transcribed',
  `is_demo`             TINYINT(1) NOT NULL DEFAULT 0,
  `created_at`          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `evaluated_at`        DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_asr_code` (`test_code`),
  KEY `ix_asr_lang` (`language_code`),
  KEY `ix_asr_created` (`created_at`),
  KEY `ix_asr_verdict` (`verdict`),
  KEY `ix_asr_demo_status` (`is_demo`, `status`),
  KEY `ix_asr_participant` (`participant_id`),
  CONSTRAINT `fk_asr_participant` FOREIGN KEY (`participant_id`) REFERENCES `participants` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_asr_evaluator`   FOREIGN KEY (`evaluator_id`)   REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `ck_asr_rating` CHECK (`rating` IS NULL OR (`rating` BETWEEN 1 AND 5))
) ENGINE=InnoDB;

-- -------------------------------------------------------- conversations ----
CREATE TABLE IF NOT EXISTS `conversations` (
  `id`               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `conv_code`        VARCHAR(16) NULL,                     -- CNV-000001
  `created_by`       INT UNSIGNED NULL,
  `person_a_part_id` INT UNSIGNED NULL,
  `person_b_part_id` INT UNSIGNED NULL,
  `lang_a`           ENUM('ha','yo','ig','en') NOT NULL,
  `lang_b`           ENUM('ha','yo','ig','en') NOT NULL,
  `status`           ENUM('active','closed') NOT NULL DEFAULT 'active',
  `is_demo`          TINYINT(1) NOT NULL DEFAULT 0,
  `created_at`       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `closed_at`        DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_conv_code` (`conv_code`),
  KEY `ix_conv_user` (`created_by`),
  KEY `ix_conv_demo` (`is_demo`),
  CONSTRAINT `fk_conv_user`  FOREIGN KEY (`created_by`)       REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_conv_part_a` FOREIGN KEY (`person_a_part_id`) REFERENCES `participants` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_conv_part_b` FOREIGN KEY (`person_b_part_id`) REFERENCES `participants` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------- conversation_turns ----
CREATE TABLE IF NOT EXISTS `conversation_turns` (
  `id`              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `conversation_id` BIGINT UNSIGNED NOT NULL,
  `turn_no`         INT UNSIGNED NOT NULL,
  `speaker`         ENUM('A','B') NOT NULL,
  `source_lang`     ENUM('ha','yo','ig','en') NOT NULL,
  `target_lang`     ENUM('ha','yo','ig','en') NOT NULL,
  `audio_path`      VARCHAR(255) NULL,
  `audio_sha256`    CHAR(64) NULL,
  `asr_request_id`  VARCHAR(64) NULL,
  `asr_model`       VARCHAR(160) NULL,
  `asr_text`        TEXT NULL,                              -- raw N-ATLaS output, never overwritten
  `confirmed_text`  TEXT NULL,                              -- what the speaker approved
  `was_edited`      TINYINT(1) NOT NULL DEFAULT 0,
  `asr_ms`          INT UNSIGNED NULL,
  `status`          ENUM('transcribed','confirmed','translated','spoken','failed') NOT NULL DEFAULT 'transcribed',
  `is_demo`         TINYINT(1) NOT NULL DEFAULT 0,
  `created_at`      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `confirmed_at`    DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_turn_order` (`conversation_id`, `turn_no`),
  KEY `ix_turn_status` (`status`),
  CONSTRAINT `fk_turn_conv` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- --------------------------------------------------------- translations ----
CREATE TABLE IF NOT EXISTS `translations` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `turn_id`        BIGINT UNSIGNED NULL,
  `source_lang`    ENUM('ha','yo','ig','en') NOT NULL,
  `target_lang`    ENUM('ha','yo','ig','en') NOT NULL,
  `source_text`    TEXT NOT NULL,
  `translated_text` TEXT NULL,
  `provider`       VARCHAR(48)  NOT NULL,
  `model`          VARCHAR(160) NULL,
  `mode`           ENUM('direct','pivot') NOT NULL DEFAULT 'direct',
  `pivot_text`     TEXT NULL,                               -- English intermediate when mode = pivot
  `request_id`     VARCHAR(64) NULL,
  `processing_ms`  INT UNSIGNED NULL,
  `status`         ENUM('ok','failed') NOT NULL,
  `error_code`     VARCHAR(48) NULL,
  `is_demo`        TINYINT(1) NOT NULL DEFAULT 0,
  `created_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_trans_turn` (`turn_id`),
  KEY `ix_trans_pair` (`source_lang`, `target_lang`),
  CONSTRAINT `fk_trans_turn` FOREIGN KEY (`turn_id`) REFERENCES `conversation_turns` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------- tts_outputs ----
CREATE TABLE IF NOT EXISTS `tts_outputs` (
  `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `turn_id`       BIGINT UNSIGNED NULL,
  `translation_id` BIGINT UNSIGNED NULL,
  `language_code` ENUM('ha','yo','ig','en') NOT NULL,
  `provider`      VARCHAR(48) NOT NULL,
  `voice`         VARCHAR(120) NULL,
  `model`         VARCHAR(160) NULL,
  `audio_path`    VARCHAR(255) NULL,
  `audio_mime`    VARCHAR(64) NULL,
  `request_id`    VARCHAR(64) NULL,
  `processing_ms` INT UNSIGNED NULL,
  `status`        ENUM('ok','failed','unavailable') NOT NULL,
  `error_code`    VARCHAR(48) NULL,
  `is_demo`       TINYINT(1) NOT NULL DEFAULT 0,
  `created_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_tts_turn` (`turn_id`),
  KEY `ix_tts_lang` (`language_code`),
  CONSTRAINT `fk_tts_turn`  FOREIGN KEY (`turn_id`)        REFERENCES `conversation_turns` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tts_trans` FOREIGN KEY (`translation_id`) REFERENCES `translations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------- system_settings ----
CREATE TABLE IF NOT EXISTS `system_settings` (
  `setting_key`   VARCHAR(96) NOT NULL,
  `setting_value` TEXT NULL,
  `is_secret`     TINYINT(1) NOT NULL DEFAULT 0,           -- secrets are stored encrypted (APP_KEY)
  `updated_by`    INT UNSIGNED NULL,
  `updated_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB;

-- ------------------------------------------------------------- api_logs ----
CREATE TABLE IF NOT EXISTS `api_logs` (
  `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `request_id`    VARCHAR(64) NOT NULL,
  `operation`     VARCHAR(48) NOT NULL,                     -- asr | translate | tts | health | ...
  `provider`      VARCHAR(48) NULL,
  `status`        ENUM('ok','error','timeout') NOT NULL,
  `http_code`     SMALLINT UNSIGNED NULL,
  `processing_ms` INT UNSIGNED NULL,
  `error_code`    VARCHAR(48) NULL,
  `user_id`       INT UNSIGNED NULL,
  `created_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_api_req` (`request_id`),
  KEY `ix_api_op` (`operation`, `created_at`)
) ENGINE=InnoDB;

-- -------------------------------------------------------- activity_logs ----
CREATE TABLE IF NOT EXISTS `activity_logs` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`     INT UNSIGNED NULL,
  `action`      VARCHAR(64) NOT NULL,
  `entity_type` VARCHAR(48) NULL,
  `entity_id`   VARCHAR(48) NULL,
  `ip_address`  VARCHAR(45) NULL,
  `metadata`    JSON NULL,
  `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_act_user` (`user_id`, `created_at`),
  KEY `ix_act_action` (`action`)
) ENGINE=InnoDB;

-- --------------------------------------------------------- model_status ----
-- Latest REAL health-check result per component (written by the health checks).
CREATE TABLE IF NOT EXISTS `model_status` (
  `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `component`     VARCHAR(48) NOT NULL,                     -- asr | translation | tts | ai_service ...
  `language_code` VARCHAR(8)  NOT NULL DEFAULT '*',
  `status`        ENUM('connected','disconnected','warning','not_configured') NOT NULL,
  `detail`        VARCHAR(500) NULL,
  `checked_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_model_component` (`component`, `language_code`)
) ENGINE=InnoDB;

-- ------------------------------------------------------------ rate_limits ----
CREATE TABLE IF NOT EXISTS `rate_limits` (
  `bucket_key`   VARCHAR(120) NOT NULL,
  `window_start` DATETIME NOT NULL,
  `hits`         INT UNSIGNED NOT NULL DEFAULT 1,
  PRIMARY KEY (`bucket_key`)
) ENGINE=InnoDB;

-- --------------------------------------------------------------- exports ----
-- Evidence Center registry of generated reports / exports (files in storage/).
CREATE TABLE IF NOT EXISTS `exports` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `kind`       ENUM('report','export') NOT NULL,
  `format`     ENUM('pdf','csv','xlsx','zip') NOT NULL,
  `dataset`    VARCHAR(48) NOT NULL,
  `filename`   VARCHAR(160) NOT NULL,
  `row_count`  INT UNSIGNED NULL,
  `include_demo` TINYINT(1) NOT NULL DEFAULT 0,
  `created_by` INT UNSIGNED NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_exports_created` (`created_at`),
  CONSTRAINT `fk_exports_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

SET FOREIGN_KEY_CHECKS = 1;

-- ------------------------------------------------------ safe seed data ----
INSERT IGNORE INTO `roles` (`id`,`name`,`label`,`description`) VALUES
 (1,'admin','Administrator','Manage users, settings, system health, exports and all data'),
 (2,'researcher','Researcher / Evaluator','Run ASR tests, manage participants, run conversations, evaluate, report'),
 (3,'participant','Participant','Voice conversation access with limited history');

-- Non-secret defaults only. Secrets (API secret, TTS keys) are entered in Settings.
INSERT IGNORE INTO `system_settings` (`setting_key`,`setting_value`,`is_secret`) VALUES
 ('app.name','ARC N-BRIDGE',0),
 ('app.organization','ARC Robotics',0),
 ('app.version','0.1.0-prototype',0),
 ('app.environment','development',0),
 ('app.timezone','Africa/Lagos',0),
 ('app.default_language','en',0),
 ('app.demo_mode','0',0),
 ('ai.backend_url','http://127.0.0.1:8000',0),
 ('ai.api_secret','',1),
 ('ai.timeout_sec','120',0),
 ('natlas.enabled.ha','1',0),
 ('natlas.enabled.yo','1',0),
 ('natlas.enabled.ig','1',0),
 ('natlas.enabled.en','1',0),
 ('translation.provider','ai_service',0),
 ('translation.engine','nllb',0),
 ('translation.direct_enabled','1',0),
 ('translation.pivot_enabled','1',0),
 ('translation.direct_pairs','',0),
 ('translation.pivot_pairs','',0),
 ('translation.timeout_sec','90',0),
 ('tts.provider','disabled',0),
 ('tts.elevenlabs_key','',1),
 ('tts.elevenlabs_model','eleven_multilingual_v2',0),
 ('tts.voices','{}',0),
 ('conversation.tts_enabled','1',0),
 ('conversation.require_confirmation','1',0),
 ('conversation.auto_translate','1',0),
 ('conversation.auto_tts','1',0),
 ('conversation.save_audio','1',0),
 ('conversation.save_transcripts','1',0),
 ('recording.max_seconds','30',0),
 ('recording.max_upload_mb','10',0),
 ('recording.allowed_formats','wav,webm,ogg,mp3,m4a,flac',0),
 ('recording.save_original','1',0),
 ('recording.save_generated','1',0),
 ('evaluation.rating_max','5',0),
 ('evaluation.require_reference','0',0),
 ('evaluation.require_verdict','1',0),
 ('evaluation.require_rating','1',0),
 ('privacy.require_consent','1',0),
 ('privacy.anonymize','1',0),
 ('privacy.retention_days','0',0),
 ('privacy.allow_audio_delete','1',0);
