<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
$user = require_role(['admin']);

const SETTINGS_FORMATS = ['wav', 'webm', 'ogg', 'mp3', 'm4a', 'flac'];

/** Section => icon + fields. Field = [key, type, label, help, options]. */
function settings_sections(): array
{
    $langFields = [];
    foreach (LANGS as $code => $name) {
        $langFields[] = ["natlas.enabled.$code", 'bool', $name, ''];
    }
    return [
        'General' => ['bi-gear', [
            ['app.demo_mode', 'bool', 'Demo mode', 'New records are flagged as demo and are left out of the dashboard figures and reports.'],
        ]],
        'AI service (Python)' => ['bi-cpu', [
            ['ai.backend_url', 'url', 'Backend URL', 'Where the FastAPI service runs, e.g. http://127.0.0.1:8000'],
            ['ai.api_secret', 'secret', 'API secret', 'Must match AI_API_SECRET in the Python service .env file. Stored encrypted and never shown again.'],
            ['ai.timeout_sec', 'int', 'Request timeout (seconds)', 'The first call to each model can be slow because the model is loaded then.', ['min' => 10, 'max' => 900]],
        ]],
        'Languages' => ['bi-translate', array_merge($langFields, [
            ['_note', 'note', '', 'This switch hides a language in this web app only. The Python service has its own NATLAS_ENABLED_LANGUAGES setting.'],
        ])],
        'Translation' => ['bi-arrow-left-right', [
            ['translation.engine', 'select', 'Default engine', 'NLLB is light. The N-ATLaS 8B model needs a GPU and ENABLE_NATLAS_LLM=true in the Python service.',
                ['nllb' => 'NLLB-200 (light)', 'natlas_llm' => 'N-ATLaS LLM (GPU)']],
            ['translation.direct_enabled', 'bool', 'Allow direct translation', ''],
            ['translation.pivot_enabled', 'bool', 'Allow pivot through English', 'Source to English to target. Useful for pairs such as Hausa to Yoruba.'],
            ['translation.timeout_sec', 'int', 'Translation timeout (seconds)', '', ['min' => 10, 'max' => 900]],
        ]],
        'Text to speech' => ['bi-volume-up', [
            ['tts.provider', 'select', 'Provider', 'Local MMS-TTS runs inside the Python service. Quality and availability per language are checked at run time.',
                ['disabled' => 'Disabled', 'local_mms' => 'Local MMS-TTS (Python service)']],
        ]],
        'Recording' => ['bi-mic', [
            ['recording.max_seconds', 'int', 'Maximum clip length (seconds)', 'The ASR models handle at most 30 seconds per clip.', ['min' => 5, 'max' => 30]],
            ['recording.max_upload_mb', 'int', 'Maximum upload size (MB)', 'The Python service has its own MAX_UPLOAD_MB (default 25).', ['min' => 1, 'max' => 25]],
            ['recording.allowed_formats', 'formats', 'Allowed formats', 'Comma separated. Allowed values: ' . implode(', ', SETTINGS_FORMATS) . '. Browser recordings are webm or ogg and need ffmpeg on the Python side.'],
            ['recording.save_original', 'bool', 'Keep uploaded and recorded audio', 'Needed to play a clip back during evaluation.'],
            ['recording.save_generated', 'bool', 'Keep generated speech', ''],
        ]],
        'VoiceBridge' => ['bi-chat-dots', [
            ['conversation.require_confirmation', 'bool', 'Speaker must confirm the recognised text', 'Recommended. The speaker can fix mistakes before anything is translated.'],
            ['conversation.auto_translate', 'bool', 'Translate straight after confirmation', 'When off, each turn shows a Translate button.'],
            ['conversation.auto_tts', 'bool', 'Speak the translation automatically', 'Needs text to speech to be switched on above.'],
            ['conversation.tts_enabled', 'bool', 'Allow voice output in conversations', ''],
            ['conversation.save_audio', 'bool', 'Keep conversation recordings', 'Needed to retry a failed recognition and for the integrity check.'],
        ]],
        'Privacy' => ['bi-shield-check', [
            ['privacy.require_consent', 'bool', 'Require recorded consent', 'Participants must have consent on file before they can take part in a conversation.'],
        ]],
        'Evaluation' => ['bi-clipboard-check', [
            ['evaluation.rating_max', 'int', 'Highest rating', '', ['min' => 2, 'max' => 5]],
            ['evaluation.require_reference', 'bool', 'Require a reference transcript', 'Without a reference, WER and CER cannot be calculated.'],
            ['evaluation.require_verdict', 'bool', 'Require a verdict', ''],
            ['evaluation.require_rating', 'bool', 'Require a rating', ''],
        ]],
    ];
}

function model_status_set(string $component, string $lang, string $status, ?string $detail): void
{
    try {
        db_exec('INSERT INTO model_status (component, language_code, status, detail, checked_at) VALUES (?,?,?,?,NOW())
                 ON DUPLICATE KEY UPDATE status = VALUES(status), detail = VALUES(detail), checked_at = NOW()',
            [$component, $lang, $status, $detail === null ? null : mb_substr($detail, 0, 500)]);
    } catch (Throwable $e) {
        error_log('model_status write failed: ' . $e->getMessage());
    }
}

/* ------------------------------------------------------------------ POST */
$testResult = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = (string)($_POST['action'] ?? '');

    if ($action === 'save') {
        $in = is_array($_POST['s'] ?? null) ? $_POST['s'] : [];
        $clear = is_array($_POST['clear'] ?? null) ? $_POST['clear'] : [];
        $errors = [];
        $updates = [];
        foreach (settings_sections() as $section => [$icon, $fields]) {
            foreach ($fields as $f) {
                $key = $f[0];
                $type = $f[1];
                $label = $f[2];
                $opt = $f[4] ?? [];
                if ($type === 'note') {
                    continue;
                }
                $raw = isset($in[$key]) && is_string($in[$key]) ? trim($in[$key]) : '';
                switch ($type) {
                    case 'secret':
                        if (!empty($clear[$key])) {
                            $updates[$key] = '';
                        } elseif ($raw !== '') {
                            $updates[$key] = $raw;
                        }
                        break;
                    case 'bool':
                        $updates[$key] = $raw === '1' ? '1' : '0';
                        break;
                    case 'url':
                        $raw = rtrim($raw, '/');
                        if (!preg_match('#^https?://#i', $raw) || filter_var($raw, FILTER_VALIDATE_URL) === false || strlen($raw) > 255) {
                            $errors[] = "$label must be a valid http:// or https:// address.";
                        } else {
                            $updates[$key] = $raw;
                        }
                        break;
                    case 'int':
                        if (!ctype_digit($raw) || (int)$raw < $opt['min'] || (int)$raw > $opt['max']) {
                            $errors[] = "$label must be a whole number from {$opt['min']} to {$opt['max']}.";
                        } else {
                            $updates[$key] = (string)(int)$raw;
                        }
                        break;
                    case 'select':
                        if (!array_key_exists($raw, $opt)) {
                            $errors[] = "$label has an invalid choice.";
                        } else {
                            $updates[$key] = $raw;
                        }
                        break;
                    case 'formats':
                        $list = array_values(array_unique(array_filter(array_map('trim', explode(',', strtolower($raw))))));
                        $bad = array_diff($list, SETTINGS_FORMATS);
                        if (!$list || $bad) {
                            $errors[] = "$label must list one or more of: " . implode(', ', SETTINGS_FORMATS) . '.';
                        } else {
                            $updates[$key] = implode(',', $list);
                        }
                        break;
                }
            }
        }
        if ($errors) {
            foreach ($errors as $m) {
                flash('danger', $m);
            }
        } else {
            $failedSecret = false;
            foreach ($updates as $k => $v) {
                if (!setting_set($k, $v, (int)$user['id'])) {
                    $failedSecret = true;
                }
            }
            activity('settings.update', 'settings', null, ['keys' => array_keys($updates)]);
            if ($failedSecret) {
                flash('warning', 'The API secret could not be stored because no valid APP_KEY is configured. Run setup again or add app_key to config.local.php. Other settings were saved.');
            } else {
                flash('success', 'Settings saved.');
            }
        }
        redirect('settings.php');
    }

    if ($action === 'test' || $action === 'test_load') {
        $load = $action === 'test_load';
        if ($load) {
            @set_time_limit(900);
        }
        $health = ai_health();
        if (!$health['ok']) {
            model_status_set('ai_service', '*', 'disconnected', (string)$health['message']);
            $testResult = ['ok' => false, 'message' => (string)$health['message'], 'checks' => [], 'overall' => 'fail', 'load' => $load];
        } else {
            $st = ai_system_test($load);
            if (!$st['ok']) {
                model_status_set('ai_service', '*', 'warning', (string)$st['message']);
                $msg = $st['error_code'] === 'UNAUTHORIZED'
                    ? 'The service is running but refused the API secret. Make the secret below match AI_API_SECRET in the Python .env file.'
                    : (string)$st['message'];
                $testResult = ['ok' => false, 'message' => $msg, 'checks' => [], 'overall' => 'fail', 'load' => $load];
            } else {
                $checks = $st['data']['checks'] ?? [];
                $overall = (string)($st['data']['overall'] ?? 'fail');
                model_status_set('ai_service', '*', $overall === 'pass' ? 'connected' : ($overall === 'warn' ? 'warning' : 'disconnected'),
                    'system test ' . $overall);
                foreach ($checks as $c) {
                    if (preg_match('/^asr_([a-z]{2})$/', (string)$c['name'], $m) && in_array($c['status'], ['pass', 'fail'], true)) {
                        model_status_set('asr', $m[1], $c['status'] === 'pass' ? 'connected' : 'disconnected', (string)$c['detail']);
                    }
                }
                $testResult = ['ok' => true, 'message' => '', 'checks' => $checks, 'overall' => $overall, 'load' => $load];
            }
        }
        activity('settings.test', 'ai_service', null, ['load_models' => $load]);
    }
}

/* ---------------------------------------------------------------- render */
$pageTitle = 'Settings';
$active = 'settings';
require __DIR__ . '/includes/header.php';

$badge = ['pass' => 'success', 'warn' => 'warning', 'fail' => 'danger', 'skip' => 'secondary'];
?>
<div class="mb-3">
    <h1 class="h3 page-title mb-0">Settings</h1>
    <div class="text-muted">Administrators only. Secrets are encrypted in the database and are never sent to the browser.</div>
</div>

<?php if ($testResult !== null): ?>
<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span><i class="bi bi-activity"></i> <?= $testResult['load'] ? 'Model loading test' : 'Connection test' ?></span>
        <?php if ($testResult['checks']): ?>
            <span class="badge text-bg-<?= e($badge[$testResult['overall']] ?? 'secondary') ?>">Overall: <?= e($testResult['overall']) ?></span>
        <?php endif; ?>
    </div>
    <div class="card-body">
        <?php if (!$testResult['ok']): ?>
            <div class="alert alert-danger mb-0"><?= e($testResult['message']) ?></div>
        <?php else: ?>
            <table class="table table-sm align-middle mb-2">
                <tbody>
                <?php foreach ($testResult['checks'] as $c): ?>
                    <tr>
                        <td style="width:9rem"><?= e($c['name']) ?></td>
                        <td style="width:6rem"><span class="badge text-bg-<?= e($badge[$c['status']] ?? 'secondary') ?>"><?= e($c['status']) ?></span></td>
                        <td class="text-muted small"><?= e($c['detail']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <div class="small text-muted">A pass here means the model loaded and ran on one second of silence. It does not measure accuracy.</div>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<form method="post" action="<?= e(url('settings.php')) ?>" autocomplete="off">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="save">
    <div class="row g-3">
    <?php foreach (settings_sections() as $section => [$icon, $fields]): ?>
        <div class="col-lg-6">
            <div class="card h-100">
                <div class="card-header"><i class="bi <?= e($icon) ?>"></i> <?= e($section) ?></div>
                <div class="card-body">
                <?php foreach ($fields as $f):
                    $key = $f[0]; $type = $f[1]; $label = $f[2]; $help = $f[3]; $opt = $f[4] ?? [];
                    $id = 'f_' . preg_replace('/[^a-z0-9]+/i', '_', $key);
                    if ($type === 'note'): ?>
                        <div class="form-text"><?= e($help) ?></div>
                    <?php continue; endif; ?>
                    <div class="mb-3">
                    <?php if ($type === 'bool'): ?>
                        <input type="hidden" name="s[<?= e($key) ?>]" value="0">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" role="switch" id="<?= e($id) ?>" name="s[<?= e($key) ?>]" value="1" <?= setting_bool($key, false) ? 'checked' : '' ?>>
                            <label class="form-check-label" for="<?= e($id) ?>"><?= e($label) ?></label>
                        </div>
                    <?php else: ?>
                        <label class="form-label" for="<?= e($id) ?>"><?= e($label) ?></label>
                        <?php if ($type === 'secret'): $isSet = setting_secret_is_set($key); ?>
                            <input class="form-control" type="password" id="<?= e($id) ?>" name="s[<?= e($key) ?>]" autocomplete="new-password"
                                   placeholder="<?= $isSet ? 'A secret is saved. Type a new one to replace it.' : 'Not set' ?>">
                            <?php if ($isSet): ?>
                                <div class="form-check mt-1"><input class="form-check-input" type="checkbox" id="<?= e($id) ?>_clear" name="clear[<?= e($key) ?>]" value="1">
                                <label class="form-check-label small" for="<?= e($id) ?>_clear">Remove the saved secret</label></div>
                            <?php endif; ?>
                        <?php elseif ($type === 'select'): $cur = (string)setting($key, array_key_first($opt)); ?>
                            <select class="form-select" id="<?= e($id) ?>" name="s[<?= e($key) ?>]">
                                <?php foreach ($opt as $val => $text): ?>
                                    <option value="<?= e($val) ?>" <?= $cur === (string)$val ? 'selected' : '' ?>><?= e($text) ?></option>
                                <?php endforeach; ?>
                            </select>
                        <?php elseif ($type === 'int'): ?>
                            <input class="form-control" type="number" id="<?= e($id) ?>" name="s[<?= e($key) ?>]" min="<?= (int)$opt['min'] ?>" max="<?= (int)$opt['max'] ?>"
                                   value="<?= e((string)setting($key, (string)$opt['min'])) ?>">
                        <?php else: ?>
                            <input class="form-control" type="text" id="<?= e($id) ?>" name="s[<?= e($key) ?>]" value="<?= e((string)setting($key, '')) ?>">
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if ($help !== '' && $type !== 'note'): ?><div class="form-text"><?= e($help) ?></div><?php endif; ?>
                    </div>
                <?php endforeach; ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
    </div>
    <div class="d-flex flex-wrap gap-2 mt-4">
        <button class="btn btn-arc" type="submit"><i class="bi bi-save"></i> Save settings</button>
    </div>
</form>

<div class="card mt-4">
    <div class="card-header"><i class="bi bi-activity"></i> Test the AI service</div>
    <div class="card-body">
        <p class="text-muted mb-3">Tests use the <strong>saved</strong> settings, so save first. The quick test checks Python, PyTorch, ffmpeg, GPU, the Hugging Face token and the network.
           The loading test loads every enabled ASR model once. It can take several minutes and downloads model files on first use.</p>
        <form method="post" action="<?= e(url('settings.php')) ?>" class="d-flex flex-wrap gap-2">
            <?= csrf_field() ?>
            <button class="btn btn-outline-arc" type="submit" name="action" value="test"><i class="bi bi-plug"></i> Quick connection test</button>
            <button class="btn btn-outline-secondary" type="submit" name="action" value="test_load"
                    onclick="return confirm('This loads all enabled ASR models and may take several minutes. Continue?');"><i class="bi bi-hdd-stack"></i> Load models test</button>
        </form>
    </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
