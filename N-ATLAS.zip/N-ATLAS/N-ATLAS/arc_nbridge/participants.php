<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
$user = require_role(['admin', 'researcher']);

const CONSENT_TEXT = 'I agree that my voice and the text of what I say may be recorded, processed by the N-ATLaS speech and translation models, and used for this research. I can withdraw at any time.';
const AGE_GROUPS = ['unspecified' => 'Prefer not to say', 'under_18' => 'Under 18', '18_25' => '18 to 25', '26_35' => '26 to 35', '36_50' => '36 to 50', '51_65' => '51 to 65', 'over_65' => 'Over 65'];
const GENDERS = ['' => 'Prefer not to say', 'female' => 'Female', 'male' => 'Male', 'other' => 'Other'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = (string)($_POST['action'] ?? '');
    if ($action === 'create') {
        $lang = (string)($_POST['language_code'] ?? '');
        $age = (string)($_POST['age_group'] ?? 'unspecified');
        $gender = (string)($_POST['gender'] ?? '');
        $consent = !empty($_POST['consent']);
        if (!isset(LANGS[$lang])) {
            flash('danger', 'Choose the participant\'s main language.');
        } elseif (!isset(AGE_GROUPS[$age]) || !isset(GENDERS[$gender])) {
            flash('danger', 'Please choose from the lists.');
        } elseif (setting_bool('privacy.require_consent', true) && !$consent) {
            flash('danger', 'Consent must be confirmed before a participant can be added.');
        } else {
            db_exec('INSERT INTO participants (language_code, age_group, gender, consent_status, is_demo, created_by) VALUES (?,?,?,?,?,?)',
                [$lang, $age, $gender === '' ? null : $gender, $consent ? 'granted' : 'none', setting_bool('app.demo_mode', false) ? 1 : 0, (int)$user['id']]);
            $id = (int)db()->lastInsertId();
            db_exec('UPDATE participants SET code = ? WHERE id = ?', [sprintf('P-%04d', $id), $id]);
            if ($consent) {
                db_exec('INSERT INTO consents (participant_id, consent_text, status, recorded_by) VALUES (?,?,?,?)', [$id, CONSENT_TEXT, 'granted', (int)$user['id']]);
            }
            activity('participant.create', 'participant', $id);
            flash('success', 'Participant ' . sprintf('P-%04d', $id) . ' added.');
        }
        redirect('participants.php');
    }
    if (in_array($action, ['grant', 'withdraw'], true)) {
        $id = (int)($_POST['id'] ?? 0);
        $p = db_row('SELECT id, code, consent_status FROM participants WHERE id = ?', [$id]);
        if ($p === null) {
            flash('danger', 'That participant was not found.');
        } else {
            $status = $action === 'grant' ? 'granted' : 'withdrawn';
            db_exec('UPDATE participants SET consent_status = ? WHERE id = ?', [$status, $id]);
            db_exec('INSERT INTO consents (participant_id, consent_text, status, recorded_by) VALUES (?,?,?,?)',
                [$id, $action === 'grant' ? CONSENT_TEXT : 'Consent withdrawn by or for the participant.', $status, (int)$user['id']]);
            activity('participant.' . $action, 'participant', $id);
            flash($action === 'grant' ? 'success' : 'warning', $action === 'grant' ? $p['code'] . ': consent recorded.'
                : $p['code'] . ': consent withdrawn. Their data is now left out of reports and exports, and they cannot join new conversations.');
        }
        redirect('participants.php');
    }
    http_response_code(400);
    exit('Unknown request.');
}

$pageTitle = 'Participants';
$active = 'participants';
$rows = db_all('SELECT p.id, p.code, p.language_code, p.age_group, p.gender, p.consent_status, p.is_demo, p.created_at,
                       (SELECT COUNT(*) FROM conversations c WHERE c.person_a_part_id = p.id OR c.person_b_part_id = p.id) AS convs
                FROM participants p ORDER BY p.id DESC LIMIT 200');
require __DIR__ . '/includes/header.php';
?>
<div class="mb-3"><h1 class="h3 page-title mb-0">Participants</h1>
    <div class="text-muted">Pseudonymous research participants. No names, phone numbers or addresses are stored here.</div></div>
<div class="row g-3">
    <div class="col-lg-4"><div class="card h-100"><div class="card-header">Add a participant</div><div class="card-body">
        <form method="post" autocomplete="off">
            <?= csrf_field() ?><input type="hidden" name="action" value="create">
            <div class="mb-2"><label class="form-label" for="language_code">Main language</label>
                <select class="form-select" id="language_code" name="language_code" required>
                    <?php foreach (LANGS as $c => $n): ?><option value="<?= e($c) ?>"><?= e($n) ?></option><?php endforeach; ?></select></div>
            <div class="mb-2"><label class="form-label" for="age_group">Age group</label>
                <select class="form-select" id="age_group" name="age_group"><?php foreach (AGE_GROUPS as $k => $l): ?><option value="<?= e($k) ?>"><?= e($l) ?></option><?php endforeach; ?></select></div>
            <div class="mb-3"><label class="form-label" for="gender">Gender</label>
                <select class="form-select" id="gender" name="gender"><?php foreach (GENDERS as $k => $l): ?><option value="<?= e($k) ?>"><?= e($l) ?></option><?php endforeach; ?></select></div>
            <div class="form-check mb-3"><input class="form-check-input" type="checkbox" id="consent" name="consent" value="1">
                <label class="form-check-label small" for="consent"><?= e(CONSENT_TEXT) ?></label></div>
            <button class="btn btn-arc w-100" type="submit"><i class="bi bi-person-plus"></i> Add participant</button>
        </form>
    </div></div></div>
    <div class="col-lg-8"><div class="card h-100"><div class="card-header">Participants</div>
    <?php if (!$rows): ?><div class="card-body text-muted">No participants yet.</div>
    <?php else: ?><div class="table-responsive"><table class="table align-middle mb-0">
        <thead><tr><th>Code</th><th>Language</th><th>Age</th><th>Consent</th><th class="text-end">Convs</th><th></th></tr></thead><tbody>
        <?php foreach ($rows as $r): $cls = ['granted' => 'success', 'withdrawn' => 'danger', 'none' => 'secondary'][$r['consent_status']]; ?>
            <tr><td><?= e($r['code']) ?><?= (int)$r['is_demo'] === 1 ? ' <span class="badge text-bg-secondary">demo</span>' : '' ?></td>
                <td><?= e(lang_name($r['language_code'])) ?></td><td class="small"><?= e(AGE_GROUPS[$r['age_group']] ?? $r['age_group']) ?></td>
                <td><span class="badge text-bg-<?= e($cls) ?>"><?= e($r['consent_status'] === 'none' ? 'not recorded' : $r['consent_status']) ?></span></td>
                <td class="text-end"><?= (int)$r['convs'] ?></td>
                <td class="text-end"><form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                    <?php if ($r['consent_status'] === 'granted'): ?>
                        <input type="hidden" name="action" value="withdraw"><button class="btn btn-sm btn-outline-danger" type="submit" onclick="return confirm('Withdraw consent for <?= e($r['code']) ?>? Their data will be left out of reports and exports.')">Withdraw consent</button>
                    <?php else: ?>
                        <input type="hidden" name="action" value="grant"><button class="btn btn-sm btn-outline-arc" type="submit">Record consent</button>
                    <?php endif; ?></form></td></tr>
        <?php endforeach; ?></tbody></table></div><?php endif; ?></div></div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
