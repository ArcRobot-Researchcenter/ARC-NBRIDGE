<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';

$state = setup_state();
if ($state === 'ready') {
    redirect('setup.php');
}
if ($state === 'no_database') {
    redirect('setup.php');          // setup.php explains how to fix the database
}
if (current_user()) {
    redirect('index.php');
}

$error = '';
$username = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $username = trim((string)($_POST['username'] ?? ''));
    $result = auth_attempt($username, (string)($_POST['password'] ?? ''));
    if ($result['ok']) {
        redirect('index.php');
    }
    $error = $result['message'];
}

$pageTitle = 'Sign in';
$active = '';
require __DIR__ . '/includes/header.php';
?>
<div class="auth-wrap">
<div class="card auth-card"><div class="card-body p-4">
    <div class="brand"><span class="arc-logo"><i class="bi bi-soundwave"></i></span>
        <h1 class="h4 mt-2 mb-0"><?= e((string)setting('app.name', 'ARC N-BRIDGE')) ?></h1>
        <div class="text-muted small">Nigerian-language speech research platform</div></div>
    <?php if ($error): ?><div class="alert alert-danger py-2"><?= e($error) ?></div><?php endif; ?>
    <form method="post" autocomplete="on">
        <?= csrf_field() ?>
        <div class="mb-3"><label class="form-label" for="username">Username</label>
            <input class="form-control" id="username" name="username" value="<?= e($username) ?>" autocomplete="username" required autofocus></div>
        <div class="mb-3"><label class="form-label" for="password">Password</label>
            <input class="form-control" type="password" id="password" name="password" autocomplete="current-password" required></div>
        <button class="btn btn-arc w-100" type="submit"><i class="bi bi-box-arrow-in-right"></i> Sign in</button>
    </form>
</div></div></div>
<?php require __DIR__ . '/includes/footer.php'; ?>
