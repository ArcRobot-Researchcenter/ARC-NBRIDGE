<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/evidence.php';
$user = require_role(['admin', 'researcher']);

/* ------------------------------------------------------ download a stored file */
if (isset($_GET['dl'])) {
    $row = db_row('SELECT filename, format FROM exports WHERE id = ?', [(int)$_GET['dl']]);
    $path = $row ? export_path((string)$row['filename']) : null;
    if ($path === null) {
        http_response_code(404);
        exit('That file is no longer available.');
    }
    activity('evidence.download', 'export', (int)$_GET['dl']);
    storage_stream($path, export_mime((string)$row['format']), (string)$row['filename']);
}

$f = report_filters($_SERVER['REQUEST_METHOD'] === 'POST' ? $_POST : []);
$integrity = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = (string)($_POST['action'] ?? '');
    if ($action === 'integrity') {
        @set_time_limit(300);
        $integrity = evidence_audio_integrity();
        activity('evidence.integrity', 'audio', null, ['ok' => $integrity['ok'], 'bad' => $integrity['mismatch'] + $integrity['missing']]);
    } elseif ($action === 'pack') {
        @set_time_limit(300);
        $schema = evidence_ensure_schema();
        if ($schema !== null) {
            flash('danger', $schema);
            redirect('evidence.php');
        }
        try {
            $pack = evidence_pack($f, $user, ai_models());
            $packId = export_register('export', 'zip', 'evidence_pack', $pack['filename'], null, $f['include_demo'], (int)$user['id']);
            activity('evidence.pack', 'export', $packId);
            flash('success', 'Evidence pack created. Download it from the list below.');
        } catch (Throwable $e) {
            error_log('ARC N-BRIDGE evidence pack failed: ' . $e->getMessage());
            flash('danger', $e instanceof RuntimeException ? $e->getMessage() : 'The evidence pack could not be created. Details are in the PHP error log.');
        }
        redirect('evidence.php');
    }
}

$pageTitle = 'Evidence Center';
$active = 'evidence';
$sum = report_summary(report_filters([]));
$ai = ai_models();
$files = db_all('SELECT e.id, e.kind, e.format, e.dataset, e.filename, e.row_count, e.created_at, u.full_name FROM exports e LEFT JOIN users u ON u.id = e.created_by ORDER BY e.id DESC LIMIT 25');
require __DIR__ . '/includes/header.php';
$n = function ($v): string { return number_format((int)$v); };
$counts = [
    ['Speech-to-text tests', array_sum(array_column($sum['asr_by_language'], 'total')), 'bi-mic'],
    ['  with a reference transcript', array_sum(array_column($sum['asr_by_language'], 'with_reference')), 'bi-chevron-right'],
    ['Translations (successful)', array_sum(array_column($sum['translation_by_pair'], 'ok')), 'bi-translate'],
    ['Voice outputs made', array_sum(array_column($sum['tts_by_language'], 'ok')), 'bi-volume-up'],
    ['Conversations / turns', $sum['turns']['conversations'] . ' / ' . $sum['turns']['total'], 'bi-chat-dots'],
    ['Participants with consent', $sum['participants'], 'bi-people'],
];
?>
<div class="mb-3"><h1 class="h3 page-title mb-0">Evidence Center</h1>
    <div class="text-muted">Everything you need to back up your results: live counts, a recording integrity check, and a verifiable evidence pack.</div></div>

<div class="row g-3 mb-3">
    <div class="col-lg-6"><div class="card h-100"><div class="card-header">What the database holds (demo records excluded)</div>
        <ul class="list-group list-group-flush">
            <?php foreach ($counts as [$label, $v, $icon]): ?>
                <li class="list-group-item d-flex justify-content-between"><span><i class="bi <?= e($icon) ?> text-muted"></i> <?= e(trim($label)) ?></span><strong><?= e(is_int($v) ? $n($v) : $v) ?></strong></li>
            <?php endforeach; ?>
            <li class="list-group-item small text-muted">Models recorded: <?= e($sum['models']['asr'] ? implode(', ', $sum['models']['asr']) : 'none yet') ?></li>
            <?php if (!empty($sum['date_range']['first'])): ?><li class="list-group-item small text-muted">Records span <?= e($sum['date_range']['first']) ?> to <?= e($sum['date_range']['last']) ?></li><?php endif; ?>
        </ul></div></div>
    <div class="col-lg-6"><div class="card h-100"><div class="card-header">AI service environment (live)</div><div class="card-body small">
        <?php if (!$ai['ok']): ?>
            <div class="text-danger"><i class="bi bi-x-circle"></i> Not reachable: <?= e((string)$ai['message']) ?></div>
            <div class="text-muted mt-2">The evidence pack can still be built; it will say the AI service was not reachable.</div>
        <?php else: $rt = $ai['data']['runtime'] ?? []; $lib = $rt['libraries'] ?? []; ?>
            <div>Python <?= e((string)($rt['python'] ?? '?')) ?> · PyTorch <?= e((string)($lib['torch'] ?? 'not installed')) ?> · Transformers <?= e((string)($lib['transformers'] ?? 'not installed')) ?></div>
            <div>Compute: <?= e((string)($rt['gpu'] ?? 'CPU only')) ?> · ffmpeg <?= !empty($rt['ffmpeg']) ? 'found' : 'missing' ?></div>
            <div>Translation/voice model downloads: <?= !empty($ai['data']['downloads_allowed']) ? 'allowed' : 'off (cached models only)' ?></div>
            <hr class="my-2"><div class="text-muted">Model repositories</div>
            <?php foreach (($ai['data']['asr'] ?? []) as $code => $m): ?><div><?= e(lang_name($code)) ?>: <code><?= e((string)$m['repo']) ?></code></div><?php endforeach; ?>
            <?php foreach (($ai['data']['translation'] ?? []) as $name => $m): if (!empty($m['enabled'])): ?><div>Translation (<?= e($name) ?>): <code><?= e((string)$m['repo']) ?></code></div><?php endif; endforeach; ?>
        <?php endif; ?>
    </div></div></div>
</div>

<div class="row g-3 mb-3">
    <div class="col-lg-6"><div class="card h-100"><div class="card-header"><i class="bi bi-patch-check"></i> Recording integrity check</div><div class="card-body">
        <p class="small text-muted">Re-calculates the SHA-256 of every stored recording and compares it with the one saved when it was uploaded. It shows whether any audio was changed or deleted afterwards.</p>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="integrity"><button class="btn btn-outline-arc" type="submit"><i class="bi bi-shield-check"></i> Run the check</button></form>
        <?php if ($integrity): $bad = $integrity['mismatch'] + $integrity['missing'] + $integrity['no_hash']; ?>
            <div class="alert alert-<?= $bad === 0 ? 'success' : 'warning' ?> mt-3 mb-0">
                Checked <?= $n($integrity['checked']) ?> recordings at <?= e($integrity['checked_at']) ?>: <strong><?= $n($integrity['ok']) ?> match</strong>,
                <?= $n($integrity['mismatch']) ?> changed, <?= $n($integrity['missing']) ?> missing, <?= $n($integrity['no_hash']) ?> without a stored hash.
                <?= $integrity['limit_reached'] ? ' (Only the first 5,000 were checked.)' : '' ?>
                <?php if ($integrity['problems']): ?><ul class="mb-0 mt-2"><?php foreach ($integrity['problems'] as $p): ?><li><?= e($p['ref']) ?>: <?= e($p['problem']) ?></li><?php endforeach; ?></ul><?php endif; ?>
            </div>
        <?php endif; ?>
    </div></div></div>
    <div class="col-lg-6"><div class="card h-100"><div class="card-header"><i class="bi bi-archive"></i> Evidence pack (ZIP)</div><div class="card-body">
        <p class="small text-muted">One file with the exact data (CSV), the summary PDF, software and model versions, the integrity result, and a manifest listing the SHA-256 of every file. Recordings are not included.</p>
        <form method="post" class="row g-2 align-items-end"><?= csrf_field() ?><input type="hidden" name="action" value="pack">
            <div class="col-6"><label class="form-label small" for="date_from">From</label><input class="form-control form-control-sm" type="date" id="date_from" name="date_from"></div>
            <div class="col-6"><label class="form-label small" for="date_to">To</label><input class="form-control form-control-sm" type="date" id="date_to" name="date_to"></div>
            <div class="col-12"><div class="form-check"><input class="form-check-input" type="checkbox" id="include_demo" name="include_demo" value="1"><label class="form-check-label small" for="include_demo">Include demo records</label></div></div>
            <div class="col-12"><button class="btn btn-arc" type="submit" <?= class_exists('ZipArchive') ? '' : 'disabled' ?>><i class="bi bi-box-seam"></i> Build evidence pack</button></div>
        </form>
        <?php if (!class_exists('ZipArchive')): ?><div class="text-danger small mt-2">Needs the PHP zip extension (enable <code>extension=zip</code> in php.ini).</div><?php endif; ?>
    </div></div></div>
</div>

<div class="card"><div class="card-header">Files you generated</div>
<?php if (!$files): ?><div class="card-body text-muted">Nothing yet. Files from the Reports page and evidence packs appear here.</div>
<?php else: ?><div class="table-responsive"><table class="table table-hover align-middle mb-0">
    <thead><tr><th>File</th><th>Type</th><th class="text-end">Rows</th><th>Created</th><th>By</th><th></th></tr></thead><tbody>
    <?php foreach ($files as $x): $avail = export_path((string)$x['filename']) !== null; ?>
        <tr><td class="small text-break"><?= e($x['filename']) ?></td><td><span class="badge lang-badge"><?= e($x['format']) ?></span></td>
            <td class="text-end"><?= $x['row_count'] === null ? '—' : $n($x['row_count']) ?></td><td class="small text-muted"><?= e($x['created_at']) ?></td><td class="small"><?= e((string)$x['full_name']) ?></td>
            <td class="text-end"><?= $avail ? '<a class="btn btn-sm btn-outline-arc" href="' . e(url('evidence.php?dl=' . (int)$x['id'])) . '"><i class="bi bi-download"></i></a>' : '<span class="small text-muted">removed</span>' ?></td></tr>
    <?php endforeach; ?></tbody></table></div><?php endif; ?></div>
<?php require __DIR__ . '/includes/footer.php'; ?>
