<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
$user = require_login();

$pageTitle = 'Dashboard';
$active = 'dashboard';
require __DIR__ . '/includes/header.php';

if ($user['role'] === 'participant'): ?>
    <h1 class="h3 page-title">Welcome, <?= e($user['full_name']) ?></h1>
    <div class="card mt-3"><div class="card-body d-flex flex-wrap align-items-center justify-content-between gap-3">
        <div><div class="fw-semibold">Talk across languages</div>
            <div class="text-muted">Speak in your language, check the text, and the other person hears the translation.</div></div>
        <a class="btn btn-arc" href="<?= e(url('voicebridge.php')) ?>"><i class="bi bi-chat-dots"></i> Open VoiceBridge</a>
    </div></div>
<?php require __DIR__ . '/includes/footer.php'; exit; endif;

/* ------------------------------------------------------------- real numbers */
$asr = db_row("SELECT COUNT(*) AS total, SUM(status='evaluated') AS evaluated, AVG(wer) AS avg_wer, AVG(cer) AS avg_cer
               FROM asr_tests WHERE is_demo = 0") ?: [];
$participants = (int)db_value('SELECT COUNT(*) FROM participants WHERE is_demo = 0');
$conversations = (int)db_value('SELECT COUNT(*) FROM conversations WHERE is_demo = 0');
$byLang = db_all("SELECT language_code, COUNT(*) AS total, SUM(status='evaluated') AS evaluated, AVG(wer) AS avg_wer,
                         SUM(verdict='correct') AS correct
                  FROM asr_tests WHERE is_demo = 0 GROUP BY language_code");
$byLang = array_column($byLang, null, 'language_code');
$recent = db_all("SELECT id, test_code, language_code, verdict, wer, status, created_at
                  FROM asr_tests WHERE is_demo = 0 ORDER BY id DESC LIMIT 8");

/* ------------------------------------------------ live AI service status */
$health = ai_health();
$models = $health['ok'] ? ai_models() : null;
$aiState = 'bad';
$aiText = 'Not reachable';
if ($health['ok']) {
    $aiState = !empty($health['data']['auth_configured']) ? 'ok' : 'warn';
    $aiText = 'Running · ' . $health['ms'] . ' ms';
}
$fmt = function ($v, int $d = 1) { return $v === null ? '—' : number_format((float)$v * 100, $d) . '%'; };
?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3">
    <div><h1 class="h3 page-title mb-0">Dashboard</h1><div class="text-muted">Live figures from the research database. Demo records are excluded.</div></div>
    <div class="d-flex gap-2">
        <a class="btn btn-outline-arc" href="<?= e(url('voicebridge.php')) ?>"><i class="bi bi-chat-dots"></i> VoiceBridge</a>
        <a class="btn btn-arc" href="<?= e(url('evaluation_lab.php')) ?>"><i class="bi bi-mic"></i> Open Evaluation Lab</a>
    </div>
</div>

<div class="row g-3 mb-4">
    <?php foreach ([
        ['bi-clipboard2-pulse', (int)($asr['total'] ?? 0), 'ASR tests run'],
        ['bi-check2-square', (int)($asr['evaluated'] ?? 0), 'Evaluated by a person'],
        ['bi-people', $participants, 'Participants'],
        ['bi-chat-dots', $conversations, 'Conversations'],
    ] as [$icon, $value, $label]): ?>
    <div class="col-6 col-lg-3"><div class="card stat-card h-100"><div class="card-body d-flex align-items-center gap-3">
        <span class="stat-icon"><i class="bi <?= e($icon) ?>"></i></span>
        <div><div class="stat-value"><?= number_format($value) ?></div><div class="text-muted small"><?= e($label) ?></div></div>
    </div></div></div>
    <?php endforeach; ?>
</div>

<div class="row g-3">
    <div class="col-lg-7">
        <div class="card h-100"><div class="card-header">ASR results by language</div>
        <div class="table-responsive"><table class="table align-middle mb-0">
            <thead><tr><th>Language</th><th class="text-end">Tests</th><th class="text-end">Evaluated</th><th class="text-end">Marked correct</th><th class="text-end">Mean WER</th></tr></thead>
            <tbody>
            <?php foreach (LANGS as $code => $name): $r = $byLang[$code] ?? null; ?>
                <tr><td><span class="badge lang-badge"><?= e($code) ?></span> <?= e($name) ?></td>
                    <td class="text-end"><?= (int)($r['total'] ?? 0) ?></td>
                    <td class="text-end"><?= (int)($r['evaluated'] ?? 0) ?></td>
                    <td class="text-end"><?= $r && (int)$r['evaluated'] > 0 ? e(number_format(100 * (int)$r['correct'] / (int)$r['evaluated'], 0)) . '%' : '—' ?></td>
                    <td class="text-end"><?= $fmt($r['avg_wer'] ?? null) ?></td></tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
        <div class="card-footer bg-transparent small text-muted">Mean WER uses only tests that have a reference transcript.</div></div>
    </div>

    <div class="col-lg-5">
        <div class="card h-100"><div class="card-header">AI service</div><div class="card-body">
            <div class="mb-2"><span class="status-dot <?= e($aiState) ?>"></span><strong><?= e($aiText) ?></strong></div>
            <?php if (!$health['ok']): ?>
                <div class="small text-danger"><?= e((string)$health['message']) ?></div>
            <?php elseif ($aiState === 'warn'): ?>
                <div class="small text-warning-emphasis">The service has no API secret configured, so protected calls will be refused.</div>
            <?php endif; ?>
            <?php if ($models && $models['ok']): $rt = $models['data']['runtime'] ?? []; ?>
                <ul class="list-unstyled small mt-3 mb-2">
                    <li><span class="status-dot <?= !empty($rt['libraries']['torch']) ? 'ok' : 'bad' ?>"></span>PyTorch: <?= e((string)($rt['libraries']['torch'] ?? 'not installed')) ?></li>
                    <li><span class="status-dot <?= !empty($rt['libraries']['transformers']) ? 'ok' : 'bad' ?>"></span>Transformers: <?= e((string)($rt['libraries']['transformers'] ?? 'not installed')) ?></li>
                    <li><span class="status-dot <?= !empty($rt['ffmpeg']) ? 'ok' : 'warn' ?>"></span>ffmpeg: <?= !empty($rt['ffmpeg']) ? 'found' : 'not found (browser recordings cannot be decoded)' ?></li>
                    <li><span class="status-dot <?= !empty($rt['cuda_available']) ? 'ok' : 'warn' ?>"></span>GPU: <?= e((string)($rt['gpu'] ?? 'none (CPU only)')) ?></li>
                    <li><span class="status-dot <?= !empty($models['data']['hf_token_configured']) ? 'ok' : 'warn' ?>"></span>Hugging Face token: <?= !empty($models['data']['hf_token_configured']) ? 'configured' : 'not set' ?></li>
                </ul>
                <div class="small text-muted mb-1">ASR models (load on first use)</div>
                <?php foreach (($models['data']['asr'] ?? []) as $code => $m): ?>
                    <div class="small"><span class="status-dot <?= !empty($m['loaded']) ? 'ok' : (!empty($m['last_error']) ? 'bad' : '') ?>"></span>
                        <?= e(lang_name($code)) ?> — <?= !empty($m['loaded']) ? 'loaded' : (!empty($m['enabled']) ? 'not loaded yet' : 'disabled') ?></div>
                <?php endforeach; ?>
            <?php elseif ($models && !$models['ok']): ?>
                <div class="small text-danger mt-2">Model details unavailable: <?= e((string)$models['message']) ?></div>
            <?php endif; ?>
        </div></div>
    </div>

    <div class="col-12">
        <div class="card"><div class="card-header">Recent ASR tests</div>
        <?php if (!$recent): ?>
            <div class="card-body text-muted">No ASR tests yet. Open the Evaluation Lab to record or upload a clip.</div>
        <?php else: ?>
        <div class="table-responsive"><table class="table table-hover align-middle mb-0">
            <thead><tr><th>Test</th><th>Language</th><th>Status</th><th>Verdict</th><th class="text-end">WER</th><th>When</th></tr></thead><tbody>
            <?php foreach ($recent as $t): ?>
                <tr><td><a href="<?= e(url('evaluation_lab.php?id=' . (int)$t['id'])) ?>"><?= e($t['test_code']) ?></a></td>
                    <td><?= e(lang_name($t['language_code'])) ?></td>
                    <td><?= e($t['status']) ?></td><td><?= e($t['verdict'] ?? '—') ?></td>
                    <td class="text-end"><?= $fmt($t['wer']) ?></td><td class="text-muted small"><?= e($t['created_at']) ?></td></tr>
            <?php endforeach; ?></tbody></table></div>
        <?php endif; ?></div>
    </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
