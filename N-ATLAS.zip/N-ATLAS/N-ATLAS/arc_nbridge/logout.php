<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_valid() && current_user()) {
    auth_logout();
    session_start();                 // fresh session just to carry the confirmation message
    flash('success', 'You have been signed out.');
}
redirect('login.php');
