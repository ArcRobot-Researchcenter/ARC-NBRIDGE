<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/voicebridge.php';
$user = require_role(['admin', 'researcher', 'participant']);

function vb_json_error(string $code, string $message, int $status = 422, array $extra = []): void
{
    json_out(['success' => false, 'error_code' => $code, 'message' => $message] + $extra, $status);
}

/** Maps a failed vb_* result to the JSON error the browser shows. */
function vb_json_from_result(array $r, ?int $turnId = null): void
{
    $msg = $r['message'];
    $status = 502;
    if (in_array($r['code'], ['UNAUTHORIZED', 'AUTH_NOT_CONFIGURED'], true)) {
        $msg = 'The AI service refused the request because the API secret does not match. An administrator should check Settings and the Python .env file.';
    } elseif (in_array($r['code'], ['TEXT_EMPTY', 'TEXT_TOO_LONG', 'BAD_STATE', 'NOT_CONFIRMED', 'NOT_TRANSLATED', 'BAD_REQUEST', 'MODE_DISABLED', 'CONVERSATION_CLOSED',
        'NOT_FOUND', 'TTS_DISABLED', 'AUDIO_NOT_SAVED'], true)) {
        $status = 409;
    }
    $extra = $turnId !== null ? ['turn' => vb_turn_payload($turnId)] : [];
    vb_json_error($r['code'], $msg, $status, $extra);
}

/** Loads a turn and refuses access to other people's conversations. */
function vb_turn_for(array $user, int $turnId): array
{
    $t = vb_turn($turnId);
    if ($t === null || !vb_can_access(['created_by' => $t['conv_owner']], $user)) {
        vb_json_error('NOT_FOUND', 'This turn was not found.', 404);
    }
    return $t;
}

/* ------------------------------------------------- authenticated audio */
if (isset($_GET['audio'])) {
    $kind = (string)$_GET['audio'];
    $id = (int)($_GET['id'] ?? 0);
    $row = null;
    if ($kind === 'turn') {
        $row = db_row('SELECT t.audio_path, c.created_by FROM conversation_turns t JOIN conversations c ON c.id = t.conversation_id WHERE t.id = ?', [$id]);
    } elseif ($kind === 'tts') {
        $row = db_row('SELECT o.audio_path, c.created_by FROM tts_outputs o JOIN conversation_turns t ON t.id = o.turn_id JOIN conversations c ON c.id = t.conversation_id WHERE o.id = ?', [$id]);
    }
    $path = ($row && !empty($row['audio_path']) && vb_can_access($row, $user)) ? storage_safe_path((string)$row['audio_path']) : null;
    if ($path === null) {
        http_response_code(404);
        exit('Audio is not available.');
    }
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    storage_stream($path, VB_AUDIO_EXT[$ext] ?? 'application/octet-stream');
}

/* ------------------------------------------------------------ POST actions */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = (string)($_POST['action'] ?? '');
    $isDemo = setting_bool('app.demo_mode', false);

    if ($action === 'conv_create') {
        $staff = in_array($user['role'], ['admin', 'researcher'], true);
        $pa = ($staff && ctype_digit((string)($_POST['person_a'] ?? ''))) ? (int)$_POST['person_a'] : null;
        $pb = ($staff && ctype_digit((string)($_POST['person_b'] ?? ''))) ? (int)$_POST['person_b'] : null;
        $r = vb_create_conversation($user, (string)($_POST['lang_a'] ?? ''), (string)($_POST['lang_b'] ?? ''), $pa, $pb, $isDemo);
        if (!$r['ok']) {
            vb_json_error($r['code'], $r['message']);
        }
        activity('voicebridge.create', 'conversation', $r['id']);
        json_out(['success' => true, 'redirect' => url('voicebridge.php?id=' . $r['id'])]);
    }

    if ($action === 'conv_close') {
        $conv = vb_conv((int)($_POST['id'] ?? 0));
        if (!vb_can_access($conv, $user)) {
            vb_json_error('NOT_FOUND', 'This conversation was not found.', 404);
        }
        vb_close_conversation((int)$conv['id']);
        activity('voicebridge.close', 'conversation', $conv['id']);
        json_out(['success' => true, 'redirect' => url('voicebridge.php?id=' . (int)$conv['id'])]);
    }

    if ($action === 'turn_asr') {
        $conv = vb_conv((int)($_POST['conversation_id'] ?? 0));
        if (!vb_can_access($conv, $user)) {
            vb_json_error('NOT_FOUND', 'This conversation was not found.', 404);
        }
        if ($conv['status'] !== 'active') {
            vb_json_error('CONVERSATION_CLOSED', 'This conversation is closed.', 409);
        }
        $speaker = (string)($_POST['speaker'] ?? '');
        if (!in_array($speaker, ['A', 'B'], true)) {
            vb_json_error('BAD_REQUEST', 'Unknown speaker.');
        }
        $f = $_FILES['audio'] ?? null;
        $v = vb_validate_upload($f);
        if (!$v['ok']) {
            vb_json_error($v['code'], $v['message'], $v['code'] === 'FILE_TOO_LARGE' ? 413 : 422);
        }
        if (!is_uploaded_file($f['tmp_name'])) {
            vb_json_error('UPLOAD_FAILED', 'The upload could not be verified.');
        }
        $sha = hash_file('sha256', $f['tmp_name']);
        $abs = $f['tmp_name'];
        $rel = null;
        if (setting_bool('conversation.save_audio', true)) {
            $stored = vb_store_file($f['tmp_name'], $v['ext'], 'turns', true);
            if ($stored !== null) {
                [$rel, $abs] = $stored;
            }
        }
        $tid = vb_create_turn($conv, $speaker, $rel, $rel !== null ? $sha : null);
        $r = vb_run_asr($tid, $abs, $v['mime'], 'clip.' . $v['ext']);
        activity('voicebridge.turn', 'turn', $tid, ['speaker' => $speaker, 'ok' => $r['ok']]);
        if (!$r['ok']) {
            if ($rel === null) {                      // no saved audio, so a retry is impossible: do not keep an empty turn
                db_exec('DELETE FROM conversation_turns WHERE id = ?', [$tid]);
                vb_json_error($r['code'], $r['message'], 502);
            }
            vb_json_from_result($r, $tid);
        }
        json_out(['success' => true, 'turn' => vb_turn_payload($tid), 'empty' => $r['empty'], 'low_energy' => $r['low_energy']]);
    }

    if ($action === 'turn_retry_asr') {
        $turn = vb_turn_for($user, (int)($_POST['id'] ?? 0));
        $abs = ($turn['status'] === 'failed' && !empty($turn['audio_path'])) ? storage_safe_path((string)$turn['audio_path']) : null;
        if ($abs === null) {
            vb_json_error('BAD_STATE', 'This turn has no saved recording to try again. Record it again.', 409);
        }
        $ext = strtolower(pathinfo($abs, PATHINFO_EXTENSION));
        $r = vb_run_asr((int)$turn['id'], $abs, VB_AUDIO_EXT[$ext] ?? 'audio/webm', 'clip.' . $ext);
        if (!$r['ok']) {
            vb_json_from_result($r, (int)$turn['id']);
        }
        json_out(['success' => true, 'turn' => vb_turn_payload((int)$turn['id']), 'empty' => $r['empty']]);
    }

    if (in_array($action, ['turn_confirm', 'turn_translate', 'turn_tts'], true)) {
        $turn = vb_turn_for($user, (int)($_POST['id'] ?? 0));
        $tid = (int)$turn['id'];
        if ($action === 'turn_confirm') {
            $r = vb_confirm($tid, (string)($_POST['text'] ?? ''));
        } elseif ($action === 'turn_translate') {
            $r = vb_translate($tid, (string)($_POST['mode'] ?? 'direct'));
        } else {
            $r = vb_tts($tid);
        }
        if (!$r['ok']) {
            vb_json_from_result($r, $tid);
        }
        json_out(['success' => true, 'turn' => vb_turn_payload($tid)]);
    }

    vb_json_error('UNKNOWN_ACTION', 'Unknown request.', 400);
}

/* ------------------------------------------------------------------- page */
$pageTitle = 'VoiceBridge';
$active = 'voicebridge';
$extraScripts = ['assets/js/voicebridge.js'];
$staff = in_array($user['role'], ['admin', 'researcher'], true);
$langs = vb_enabled_languages();
$ttsOn = (string)setting('tts.provider', 'disabled') === 'local_mms' && setting_bool('conversation.tts_enabled', true);
require __DIR__ . '/includes/header.php';

/* =============================================================== conversation */
if (isset($_GET['id'])):
    $conv = vb_conv((int)$_GET['id']);
    if (!vb_can_access($conv, $user)): ?>
        <div class="alert alert-warning">That conversation was not found. <a href="<?= e(url('voicebridge.php')) ?>">Back to VoiceBridge</a></div>
    <?php require __DIR__ . '/includes/footer.php'; exit; endif;
    $turns = vb_conversation_turns((int)$conv['id']);
    $isActive = $conv['status'] === 'active';
    $defaultRoute = setting_bool('translation.direct_enabled', true) ? 'direct' : 'pivot';
    $names = ['A' => lang_name($conv['lang_a']), 'B' => lang_name($conv['lang_b'])];
?>
<div id="vb-config" class="d-none"
     data-endpoint="<?= e(url('voicebridge.php')) ?>" data-csrf="<?= e(csrf_token()) ?>" data-conversation="<?= (int)$conv['id'] ?>"
     data-active="<?= $isActive ? '1' : '0' ?>" data-max-seconds="<?= (int)setting_int('recording.max_seconds', 30) ?>"
     data-tts="<?= $ttsOn ? '1' : '0' ?>" data-require-confirm="<?= setting_bool('conversation.require_confirmation', true) ? '1' : '0' ?>"
     data-auto-translate="<?= setting_bool('conversation.auto_translate', true) ? '1' : '0' ?>"
     data-auto-tts="<?= setting_bool('conversation.auto_tts', true) ? '1' : '0' ?>"
     data-name-a="<?= e($names['A']) ?>" data-name-b="<?= e($names['B']) ?>"></div>
<script type="application/json" id="vb-turns"><?= json_encode($turns, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?></script>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
    <div>
        <h1 class="h3 page-title mb-0"><?= e($conv['conv_code']) ?>
            <?php if ((int)$conv['is_demo'] === 1): ?><span class="badge text-bg-secondary fs-6">demo</span><?php endif; ?>
            <span class="badge text-bg-<?= $isActive ? 'success' : 'secondary' ?> fs-6"><?= $isActive ? 'open' : 'closed' ?></span></h1>
        <div class="text-muted"><span class="badge lang-badge"><?= e($conv['lang_a']) ?></span> <?= e($names['A']) ?>
            <i class="bi bi-arrow-left-right mx-1"></i> <span class="badge lang-badge"><?= e($conv['lang_b']) ?></span> <?= e($names['B']) ?>
            · started <?= e($conv['created_at']) ?></div>
    </div>
    <div class="d-flex gap-2">
        <a class="btn btn-outline-arc" href="<?= e(url('voicebridge.php')) ?>"><i class="bi bi-arrow-left"></i> All conversations</a>
        <?php if ($isActive): ?><button class="btn btn-outline-secondary" type="button" id="vb-close"><i class="bi bi-check2-circle"></i> End conversation</button><?php endif; ?>
    </div>
</div>

<?php if ($isActive && !$ttsOn): ?>
    <div class="alert alert-info py-2"><i class="bi bi-volume-mute"></i> Voice output is off, so translations appear as text only.
        <?= has_role(['admin']) ? '<a href="' . e(url('settings.php')) . '">Turn it on in Settings</a>.' : '' ?></div>
<?php endif; ?>

<div class="card mb-3"><div class="card-body vb-timeline" id="vb-timeline" aria-live="polite">
    <div class="text-muted text-center py-4" id="vb-empty">No one has spoken yet. Press a microphone button below to begin.</div>
</div></div>

<?php if ($isActive): ?>
<div class="card vb-review d-none mb-3" id="vb-review"><div class="card-body">
    <div class="fw-semibold mb-1"><i class="bi bi-pencil-square"></i> Is this what was said? <span class="text-muted fw-normal small" id="vb-review-lang"></span></div>
    <div class="small text-muted mb-2">Fix any mistakes. The translation uses the text below.</div>
    <audio controls class="w-100 mb-2 d-none" id="vb-review-audio"></audio>
    <textarea class="form-control mb-2" id="vb-review-text" rows="2" maxlength="<?= VB_TEXT_MAX ?>"></textarea>
    <div class="d-flex flex-wrap gap-2 align-items-center">
        <button class="btn btn-arc" type="button" id="vb-confirm"><i class="bi bi-check2"></i> Confirm and translate</button>
        <button class="btn btn-outline-secondary" type="button" id="vb-review-skip">Record again instead</button>
        <span class="small text-muted ms-auto">Translate through:
            <select class="form-select form-select-sm d-inline-block w-auto" id="vb-route">
                <option value="direct" <?= $defaultRoute === 'direct' ? 'selected' : '' ?>>Direct</option>
                <option value="pivot" <?= $defaultRoute === 'pivot' ? 'selected' : '' ?>>English in between</option>
            </select></span>
    </div>
</div></div>

<div class="row g-3 mb-2" id="vb-speak">
    <?php foreach (['A', 'B'] as $side): ?>
    <div class="col-md-6"><div class="card vb-person vb-person-<?= strtolower($side) ?> h-100"><div class="card-body text-center">
        <div class="small text-uppercase text-muted">Person <?= $side ?></div>
        <div class="h5 mb-3"><?= e($names[$side]) ?></div>
        <button class="btn btn-lg vb-mic" type="button" id="rec-<?= $side ?>" data-speaker="<?= $side ?>"><i class="bi bi-mic-fill"></i> <span>Speak</span></button>
    </div></div></div>
    <?php endforeach; ?>
</div>
<div id="vb-status" class="mb-3" aria-live="polite"></div>
<?php endif; ?>
<?php
    require __DIR__ . '/includes/footer.php';
    exit;
endif;

/* ======================================================================= list */
$participants = $staff ? db_all("SELECT id, code, language_code FROM participants WHERE consent_status = 'granted' ORDER BY code") : [];
$rows = db_all('SELECT c.id, c.conv_code, c.lang_a, c.lang_b, c.status, c.is_demo, c.created_at, (SELECT COUNT(*) FROM conversation_turns t WHERE t.conversation_id = c.id) AS turns
                FROM conversations c ' . ($staff ? '' : 'WHERE c.created_by = ' . (int)$user['id']) . ' ORDER BY c.id DESC LIMIT 30');
$opts = function (string $sel) use ($langs): string {
    $h = '';
    foreach ($langs as $c => $n) {
        $h .= '<option value="' . e($c) . '"' . ($c === $sel ? ' selected' : '') . '>' . e($n) . '</option>';
    }
    return $h;
};
$codes = array_keys($langs);
?>
<div id="vb-config" class="d-none" data-endpoint="<?= e(url('voicebridge.php')) ?>" data-csrf="<?= e(csrf_token()) ?>" data-conversation="0"></div>
<div class="mb-3"><h1 class="h3 page-title mb-0">VoiceBridge</h1>
    <div class="text-muted">Two people, two languages. Each person speaks, checks the text, and the other person gets the translation.</div></div>

<?php if (count($langs) < 2): ?>
    <div class="alert alert-warning">At least two languages must be enabled. An administrator can enable languages in Settings.</div>
<?php else: ?>
<div class="row g-3">
    <div class="col-lg-5"><div class="card h-100"><div class="card-header">Start a conversation</div><div class="card-body">
        <div class="row g-2 mb-3">
            <div class="col-6"><label class="form-label" for="new-a">Person A speaks</label><select class="form-select" id="new-a"><?= $opts($codes[0]) ?></select></div>
            <div class="col-6"><label class="form-label" for="new-b">Person B speaks</label><select class="form-select" id="new-b"><?= $opts($codes[1]) ?></select></div>
        </div>
        <?php if ($staff): ?>
        <div class="row g-2 mb-3">
            <?php foreach (['a' => 'A', 'b' => 'B'] as $k => $L): ?>
            <div class="col-6"><label class="form-label" for="new-p<?= $k ?>">Participant <?= $L ?> <span class="text-muted small">(optional)</span></label>
                <select class="form-select" id="new-p<?= $k ?>"><option value="">Not recorded</option>
                    <?php foreach ($participants as $p): ?><option value="<?= (int)$p['id'] ?>"><?= e($p['code']) ?> · <?= e($p['language_code']) ?></option><?php endforeach; ?>
                </select></div>
            <?php endforeach; ?>
            <div class="form-text">Only participants with recorded consent are listed. <a href="<?= e(url('participants.php')) ?>">Manage participants</a></div>
        </div>
        <?php endif; ?>
        <div class="d-grid"><button class="btn btn-arc" type="button" id="vb-create"><i class="bi bi-chat-dots"></i> Start</button></div>
        <div id="vb-msg" class="mt-3"></div>
    </div></div></div>
    <div class="col-lg-7"><div class="card h-100"><div class="card-header">Recent conversations</div>
    <?php if (!$rows): ?><div class="card-body text-muted">No conversations yet.</div>
    <?php else: ?><div class="table-responsive"><table class="table table-hover align-middle mb-0">
        <thead><tr><th>Conversation</th><th>Languages</th><th class="text-end">Turns</th><th>Status</th><th>Started</th></tr></thead><tbody>
        <?php foreach ($rows as $r): ?>
            <tr><td><a href="<?= e(url('voicebridge.php?id=' . (int)$r['id'])) ?>"><?= e($r['conv_code']) ?></a><?= (int)$r['is_demo'] === 1 ? ' <span class="badge text-bg-secondary">demo</span>' : '' ?></td>
                <td><?= e(lang_name($r['lang_a'])) ?> · <?= e(lang_name($r['lang_b'])) ?></td><td class="text-end"><?= (int)$r['turns'] ?></td>
                <td><span class="badge text-bg-<?= $r['status'] === 'active' ? 'success' : 'secondary' ?>"><?= $r['status'] === 'active' ? 'open' : 'closed' ?></span></td>
                <td class="text-muted small"><?= e($r['created_at']) ?></td></tr>
        <?php endforeach; ?></tbody></table></div><?php endif; ?></div></div>
</div>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
