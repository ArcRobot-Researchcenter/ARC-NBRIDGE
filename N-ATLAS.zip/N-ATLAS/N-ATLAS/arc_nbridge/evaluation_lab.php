<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
$user = require_role(['admin', 'researcher']);

const LAB_AUDIO_EXT = ['wav' => 'audio/wav', 'webm' => 'audio/webm', 'ogg' => 'audio/ogg', 'mp3' => 'audio/mpeg',
                       'm4a' => 'audio/mp4', 'flac' => 'audio/flac'];
const LAB_TRANSLATE_MAX_CHARS = 1000;   // keep in step with MAX_TRANSLATION_CHARS in the Python service
const LAB_TTS_MAX_CHARS = 500;          // keep in step with MAX_TTS_CHARS in the Python service

/* ------------------------------------------------------------- helpers */
function lab_fail(string $code, string $message, int $status = 422): void
{
    json_out(['success' => false, 'error_code' => $code, 'message' => $message], $status);
}

/** Message and status to show for a failed AI service call. */
function lab_ai_fail(array $res): void
{
    $code = (string)$res['error_code'];
    $msg = (string)$res['message'];
    if ($code === 'UNAUTHORIZED' || $code === 'AUTH_NOT_CONFIGURED') {
        $msg = 'The AI service refused the request because the API secret does not match. An administrator should check Settings and the Python .env file.';
        lab_fail($code, $msg, 502);
    }
    lab_fail($code, $msg, ($res['http'] >= 400 && $res['http'] < 600 && $res['http'] !== 401) ? $res['http'] : 502);
}

function lab_enabled_languages(): array
{
    $out = [];
    foreach (LANGS as $code => $name) {
        if (setting_bool("natlas.enabled.$code", true)) {
            $out[$code] = $name;
        }
    }
    return $out;
}

/** @return array{0:string,1:string}|null [absolute dir, relative dir] (created if needed) */
function lab_storage_dir(string $kind): ?array
{
    $rel = 'audio/' . $kind . '/' . date('Y/m');
    $abs = rtrim((string)cfg('storage_path'), '/\\') . '/' . $rel;
    if (!is_dir($abs) && !@mkdir($abs, 0775, true) && !is_dir($abs)) {
        error_log('ARC N-BRIDGE: cannot create storage directory ' . $abs);
        return null;
    }
    return [$abs, $rel];
}

/** Resolves a stored relative path and refuses anything outside the storage folder. */
function lab_safe_path(string $relative): ?string
{
    $root = realpath((string)cfg('storage_path'));
    $full = realpath(rtrim((string)cfg('storage_path'), '/\\') . '/' . $relative);
    if ($root === false || $full === false || strpos($full, $root . DIRECTORY_SEPARATOR) !== 0 || !is_file($full)) {
        return null;
    }
    return $full;
}

function lab_pct($v, int $d = 1): string
{
    return $v === null ? '—' : number_format((float)$v * 100, $d) . '%';
}

function lab_ms($seconds): ?int
{
    return is_numeric($seconds) ? (int)round((float)$seconds * 1000) : null;
}

$isDemo = setting_bool('app.demo_mode', false) ? 1 : 0;

/* ------------------------------------------------- authenticated audio */
if (isset($_GET['audio'])) {
    $kind = (string)$_GET['audio'];
    $id = (int)($_GET['id'] ?? 0);
    $row = null;
    if ($kind === 'asr') {
        $row = db_row('SELECT audio_path, audio_mime FROM asr_tests WHERE id = ?', [$id]);
    } elseif ($kind === 'tts') {
        $row = db_row('SELECT audio_path, audio_mime FROM tts_outputs WHERE id = ?', [$id]);
    }
    $path = ($row && !empty($row['audio_path'])) ? lab_safe_path((string)$row['audio_path']) : null;
    if ($path === null) {
        http_response_code(404);
        exit('Audio is not available.');
    }
    $mime = in_array($row['audio_mime'], LAB_AUDIO_EXT, true) ? $row['audio_mime'] : 'application/octet-stream';
    header('Content-Type: ' . $mime);
    header('Content-Length: ' . filesize($path));
    header('Cache-Control: private, max-age=3600');
    readfile($path);
    exit;
}

/* ------------------------------------------------------------ POST actions */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = (string)($_POST['action'] ?? '');
    $enabled = lab_enabled_languages();

    /* ---- speech to text ---- */
    if ($action === 'asr_run') {
        $lang = (string)($_POST['language'] ?? '');
        if (!isset($enabled[$lang])) {
            lab_fail('LANGUAGE_UNSUPPORTED', 'Choose one of the enabled languages.');
        }
        $source = (($_POST['source'] ?? '') === 'microphone') ? 'microphone' : 'upload';
        $f = $_FILES['audio'] ?? null;
        if (!is_array($f) || ($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            lab_fail('NO_AUDIO', 'Record or choose an audio clip first.');
        }
        if ($f['error'] !== UPLOAD_ERR_OK) {
            $tooBig = in_array($f['error'], [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true);
            lab_fail('UPLOAD_FAILED', $tooBig ? 'The file is larger than the PHP upload limit (upload_max_filesize in php.ini).'
                                               : 'The upload did not finish. Please try again.', $tooBig ? 413 : 422);
        }
        if ((int)$f['size'] <= 0) {
            lab_fail('AUDIO_EMPTY', 'The audio file is empty.');
        }
        if ((int)$f['size'] > setting_int('recording.max_upload_mb', 10) * 1024 * 1024) {
            lab_fail('FILE_TOO_LARGE', 'The audio file is larger than the limit of ' . setting_int('recording.max_upload_mb', 10) . ' MB set in Settings.', 413);
        }
        $ext = strtolower(pathinfo((string)$f['name'], PATHINFO_EXTENSION));
        $allowed = array_filter(array_map('trim', explode(',', (string)setting('recording.allowed_formats', 'wav,webm,ogg,mp3,m4a,flac'))));
        if (!isset(LAB_AUDIO_EXT[$ext]) || !in_array($ext, $allowed, true)) {
            lab_fail('FORMAT_NOT_ALLOWED', 'This file type is not allowed. Allowed: ' . implode(', ', $allowed) . '.');
        }
        if (!is_uploaded_file($f['tmp_name'])) {
            lab_fail('UPLOAD_FAILED', 'The upload could not be verified.');
        }
        $mime = LAB_AUDIO_EXT[$ext];
        $sha = hash_file('sha256', $f['tmp_name']);

        $res = ai_asr($f['tmp_name'], 'clip.' . $ext, $mime, $lang);
        if (!$res['ok']) {
            lab_ai_fail($res);
        }
        $d = $res['data'];

        $rel = null;
        if (setting_bool('recording.save_original', true)) {
            $dir = lab_storage_dir('asr');
            if ($dir !== null) {
                $name = uuid4() . '.' . $ext;
                if (move_uploaded_file($f['tmp_name'], $dir[0] . '/' . $name)) {
                    $rel = $dir[1] . '/' . $name;
                }
            }
        }
        db_exec('INSERT INTO asr_tests (language_code, source, audio_path, audio_sha256, audio_mime, audio_bytes, audio_duration_sec,
                    request_id, model_repo, model_name, natlas_text, ai_time_ms, roundtrip_ms, evaluator_id, status, is_demo)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', [
            $lang, $source, $rel, $sha, $mime, (int)$f['size'], $d['audio_duration'] ?? null, $res['request_id'],
            $d['model_repo'] ?? null, $d['model'] ?? null, (string)($d['transcription'] ?? ''), lab_ms($d['processing_time'] ?? null),
            $res['ms'], (int)$user['id'], 'transcribed', $isDemo,
        ]);
        $id = (int)db()->lastInsertId();
        db_exec('UPDATE asr_tests SET test_code = ? WHERE id = ?', [sprintf('ASR-%06d', $id), $id]);
        activity('asr.run', 'asr_test', $id, ['language' => $lang]);
        json_out(['success' => true, 'id' => $id, 'test_code' => sprintf('ASR-%06d', $id),
                  'redirect' => url('evaluation_lab.php?id=' . $id)]);
    }

    /* ---- evaluate an ASR test ---- */
    if ($action === 'asr_evaluate') {
        $id = (int)($_POST['id'] ?? 0);
        $row = db_row('SELECT id, natlas_text FROM asr_tests WHERE id = ?', [$id]);
        if (!$row) {
            lab_fail('NOT_FOUND', 'This test no longer exists.', 404);
        }
        $ref = mb_substr(trim((string)($_POST['reference_text'] ?? '')), 0, 5000);
        $cor = mb_substr(trim((string)($_POST['corrected_text'] ?? '')), 0, 5000);
        $comments = mb_substr(trim((string)($_POST['comments'] ?? '')), 0, 2000);
        $verdict = (string)($_POST['verdict'] ?? '');
        $verdict = in_array($verdict, ['correct', 'partial', 'incorrect'], true) ? $verdict : null;
        $max = max(2, min(5, setting_int('evaluation.rating_max', 5)));
        $ratingRaw = (string)($_POST['rating'] ?? '');
        $rating = (ctype_digit($ratingRaw) && (int)$ratingRaw >= 1 && (int)$ratingRaw <= $max) ? (int)$ratingRaw : null;

        if (setting_bool('evaluation.require_reference', false) && $ref === '') {
            lab_fail('REFERENCE_REQUIRED', 'A reference transcript is required.');
        }
        if (setting_bool('evaluation.require_verdict', true) && $verdict === null) {
            lab_fail('VERDICT_REQUIRED', 'Choose a verdict: correct, partial or incorrect.');
        }
        if (setting_bool('evaluation.require_rating', true) && $rating === null) {
            lab_fail('RATING_REQUIRED', "Choose a rating from 1 to $max.");
        }
        $wer = $cer = null;
        if ($ref !== '') {
            $wer = metrics_wer($ref, (string)$row['natlas_text']);   // always scored against the raw N-ATLaS output
            $cer = metrics_cer($ref, (string)$row['natlas_text']);
        }
        $evaluated = ($verdict !== null || $ref !== '' || $cor !== '');
        db_exec('UPDATE asr_tests SET reference_text = ?, corrected_text = ?, verdict = ?, rating = ?, comments = ?, wer = ?, cer = ?,
                    status = ?, evaluator_id = ?, evaluated_at = ? WHERE id = ?', [
            $ref === '' ? null : $ref, $cor === '' ? null : $cor, $verdict, $rating, $comments === '' ? null : $comments,
            $wer, $cer, $evaluated ? 'evaluated' : 'transcribed', (int)$user['id'], $evaluated ? date('Y-m-d H:i:s') : null, $id,
        ]);
        activity('asr.evaluate', 'asr_test', $id);
        json_out(['success' => true, 'wer' => $wer, 'cer' => $cer, 'status' => $evaluated ? 'evaluated' : 'transcribed']);
    }

    /* ---- translation ---- */
    if ($action === 'translate_run') {
        $src = (string)($_POST['source_language'] ?? '');
        $tgt = (string)($_POST['target_language'] ?? '');
        $text = trim((string)($_POST['text'] ?? ''));
        $engine = (string)($_POST['engine'] ?? setting('translation.engine', 'nllb'));
        $mode = (string)($_POST['mode'] ?? 'direct');
        if (!isset($enabled[$src]) || !isset($enabled[$tgt])) {
            lab_fail('LANGUAGE_UNSUPPORTED', 'Choose two enabled languages.');
        }
        if ($src === $tgt) {
            lab_fail('SAME_LANGUAGE', 'Source and target language must be different.');
        }
        if ($text === '') {
            lab_fail('TEXT_EMPTY', 'Type the text to translate.');
        }
        if (mb_strlen($text) > LAB_TRANSLATE_MAX_CHARS) {
            lab_fail('TEXT_TOO_LONG', 'The text is longer than ' . LAB_TRANSLATE_MAX_CHARS . ' characters.');
        }
        if (!in_array($engine, ['nllb', 'natlas_llm'], true) || !in_array($mode, ['direct', 'pivot'], true)) {
            lab_fail('BAD_REQUEST', 'Unknown engine or mode.');
        }
        if (($mode === 'direct' && !setting_bool('translation.direct_enabled', true)) || ($mode === 'pivot' && !setting_bool('translation.pivot_enabled', true))) {
            lab_fail('MODE_DISABLED', 'This translation mode is switched off in Settings.');
        }
        $res = ai_request('POST', '/translate', ['json' => ['source_language' => $src, 'target_language' => $tgt, 'text' => $text,
                          'engine' => $engine, 'mode' => $mode], 'timeout' => setting_int('translation.timeout_sec', 90), 'operation' => 'translate']);
        $d = $res['data'] ?? [];
        db_exec('INSERT INTO translations (source_lang, target_lang, source_text, translated_text, provider, model, mode, pivot_text,
                    request_id, processing_ms, status, error_code, is_demo) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)', [
            $src, $tgt, $text, $res['ok'] ? (string)($d['translation'] ?? '') : null, $res['ok'] ? (string)($d['provider'] ?? $engine) : $engine,
            $res['ok'] ? ($d['model'] ?? null) : null, $res['ok'] ? ($d['mode'] ?? $mode) : $mode, $res['ok'] ? ($d['pivot_text'] ?? null) : null,
            $res['request_id'], $res['ok'] ? lab_ms($d['processing_time'] ?? null) : $res['ms'], $res['ok'] ? 'ok' : 'failed',
            $res['ok'] ? null : mb_substr((string)$res['error_code'], 0, 48), $isDemo,
        ]);
        if (!$res['ok']) {
            lab_ai_fail($res);
        }
        json_out(['success' => true, 'translation' => (string)($d['translation'] ?? ''), 'pivot_text' => $d['pivot_text'] ?? null,
                  'mode' => $d['mode'] ?? $mode, 'engine' => $d['provider'] ?? $engine, 'model' => $d['model'] ?? null,
                  'processing_ms' => lab_ms($d['processing_time'] ?? null), 'roundtrip_ms' => $res['ms']]);
    }

    /* ---- text to speech ---- */
    if ($action === 'tts_run') {
        $provider = (string)setting('tts.provider', 'disabled');
        if ($provider !== 'local_mms') {
            lab_fail('TTS_DISABLED', 'Text to speech is switched off. An administrator can turn it on in Settings.', 409);
        }
        $lang = (string)($_POST['language'] ?? '');
        $text = trim((string)($_POST['text'] ?? ''));
        if (!isset($enabled[$lang])) {
            lab_fail('LANGUAGE_UNSUPPORTED', 'Choose one of the enabled languages.');
        }
        if ($text === '') {
            lab_fail('TEXT_EMPTY', 'Type the text to speak.');
        }
        if (mb_strlen($text) > LAB_TTS_MAX_CHARS) {
            lab_fail('TEXT_TOO_LONG', 'The text is longer than ' . LAB_TTS_MAX_CHARS . ' characters.');
        }
        $res = ai_request('POST', '/tts', ['json' => ['language' => $lang, 'text' => $text], 'timeout' => 180, 'operation' => 'tts']);
        $d = $res['data'] ?? [];
        $unavailable = ['MODEL_LOAD_FAILED', 'MODEL_ACCESS_DENIED', 'DEPENDENCY_MISSING', 'MODEL_DISABLED'];
        $status = $res['ok'] ? 'ok' : (in_array((string)$res['error_code'], $unavailable, true) ? 'unavailable' : 'failed');

        $rel = null;
        $audio64 = $res['ok'] ? (string)($d['audio_base64'] ?? '') : '';
        if ($res['ok'] && setting_bool('recording.save_generated', true) && $audio64 !== '') {
            $bin = base64_decode($audio64, true);
            $dir = ($bin !== false && substr($bin, 0, 4) === 'RIFF') ? lab_storage_dir('tts') : null;
            if ($dir !== null) {
                $name = uuid4() . '.wav';
                if (@file_put_contents($dir[0] . '/' . $name, $bin) !== false) {
                    $rel = $dir[1] . '/' . $name;
                }
            }
        }
        db_exec('INSERT INTO tts_outputs (language_code, provider, model, audio_path, audio_mime, request_id, processing_ms, status, error_code, is_demo)
                 VALUES (?,?,?,?,?,?,?,?,?,?)', [
            $lang, 'local_mms', $res['ok'] ? ($d['model'] ?? null) : null, $rel, $res['ok'] ? ($d['mime'] ?? 'audio/wav') : null,
            $res['request_id'], $res['ok'] ? lab_ms($d['processing_time'] ?? null) : $res['ms'], $status,
            $res['ok'] ? null : mb_substr((string)$res['error_code'], 0, 48), $isDemo,
        ]);
        if (!$res['ok']) {
            lab_ai_fail($res);
        }
        json_out(['success' => true, 'audio_base64' => $audio64, 'mime' => (string)($d['mime'] ?? 'audio/wav'),
                  'model' => $d['model'] ?? null, 'processing_ms' => lab_ms($d['processing_time'] ?? null), 'roundtrip_ms' => $res['ms']]);
    }

    lab_fail('UNKNOWN_ACTION', 'Unknown request.', 400);
}

/* ------------------------------------------------------------------- page */
$pageTitle = 'Evaluation Lab';
$active = 'lab';
$extraScripts = ['assets/js/lab.js'];
$langs = lab_enabled_languages();
$ratingMax = max(2, min(5, setting_int('evaluation.rating_max', 5)));
$ttsOn = (string)setting('tts.provider', 'disabled') === 'local_mms';
require __DIR__ . '/includes/header.php';
?>
<div id="lab-config" class="d-none"
     data-endpoint="<?= e(url('evaluation_lab.php')) ?>"
     data-csrf="<?= e(csrf_token()) ?>"
     data-max-seconds="<?= (int)setting_int('recording.max_seconds', 30) ?>"
     data-max-mb="<?= (int)setting_int('recording.max_upload_mb', 10) ?>"></div>
<?php

/* =========================================================== detail view */
if (isset($_GET['id'])):
    $t = db_row('SELECT a.*, u.full_name AS evaluator_name FROM asr_tests a LEFT JOIN users u ON u.id = a.evaluator_id WHERE a.id = ?', [(int)$_GET['id']]);
    if (!$t): ?>
        <div class="alert alert-warning">That test was not found. <a href="<?= e(url('evaluation_lab.php')) ?>">Back to the Evaluation Lab</a></div>
    <?php require __DIR__ . '/includes/footer.php'; exit; endif;
    $hasAudio = !empty($t['audio_path']) && lab_safe_path((string)$t['audio_path']) !== null;
?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3">
    <div>
        <h1 class="h3 page-title mb-0"><?= e($t['test_code']) ?>
            <?php if ((int)$t['is_demo'] === 1): ?><span class="badge text-bg-secondary fs-6">demo</span><?php endif; ?></h1>
        <div class="text-muted"><span class="badge lang-badge"><?= e($t['language_code']) ?></span> <?= e(lang_name($t['language_code'])) ?>
            · <?= e($t['source'] === 'microphone' ? 'recorded in the browser' : 'uploaded file') ?> · <?= e($t['created_at']) ?></div>
    </div>
    <a class="btn btn-outline-arc" href="<?= e(url('evaluation_lab.php')) ?>"><i class="bi bi-arrow-left"></i> Back to the lab</a>
</div>

<div class="row g-3">
    <div class="col-lg-6">
        <div class="card h-100"><div class="card-header"><i class="bi bi-soundwave"></i> What the model heard</div><div class="card-body">
            <?php if ($hasAudio): ?>
                <audio controls class="w-100 mb-3" src="<?= e(url('evaluation_lab.php?audio=asr&id=' . (int)$t['id'])) ?>"></audio>
            <?php else: ?>
                <div class="small text-muted mb-3">The audio file was not kept (see Settings, Recording).</div>
            <?php endif; ?>
            <div class="small text-muted mb-1">Raw model output (never edited)</div>
            <div class="transcript-box p-3 mb-3"><?= $t['natlas_text'] === '' ? '<span class="text-muted">(the model returned no text)</span>' : e($t['natlas_text']) ?></div>
            <dl class="row small mb-0">
                <dt class="col-5">Model</dt><dd class="col-7"><?= e((string)$t['model_name']) ?><br><span class="text-muted"><?= e((string)$t['model_repo']) ?></span></dd>
                <dt class="col-5">Audio length</dt><dd class="col-7"><?= $t['audio_duration_sec'] !== null ? e(number_format((float)$t['audio_duration_sec'], 1)) . ' s' : '—' ?></dd>
                <dt class="col-5">Model time</dt><dd class="col-7"><?= $t['ai_time_ms'] !== null ? (int)$t['ai_time_ms'] . ' ms' : '—' ?></dd>
                <dt class="col-5">Round trip</dt><dd class="col-7"><?= $t['roundtrip_ms'] !== null ? (int)$t['roundtrip_ms'] . ' ms' : '—' ?></dd>
                <dt class="col-5">SHA-256</dt><dd class="col-7 text-break"><code><?= e(substr((string)$t['audio_sha256'], 0, 16)) ?>…</code></dd>
            </dl>
        </div></div>
    </div>

    <div class="col-lg-6">
        <div class="card h-100"><div class="card-header"><i class="bi bi-clipboard-check"></i> Evaluation</div><div class="card-body">
            <form id="eval-form" autocomplete="off">
                <input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
                <div class="mb-3">
                    <label class="form-label" for="reference_text">Reference transcript <span class="text-muted small">(what was really said)</span></label>
                    <textarea class="form-control" id="reference_text" name="reference_text" rows="2"><?= e((string)$t['reference_text']) ?></textarea>
                    <div class="form-text">Used to calculate WER and CER against the raw model output.</div>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="corrected_text">Corrected text</label>
                    <textarea class="form-control" id="corrected_text" name="corrected_text" rows="2"><?= e((string)$t['corrected_text']) ?></textarea>
                    <button type="button" class="btn btn-link btn-sm px-0" id="copy-model-text" data-text="<?= e($t['natlas_text']) ?>">Start from the model text</button>
                </div>
                <div class="mb-3">
                    <div class="form-label">Verdict</div>
                    <?php foreach (['correct' => 'Correct', 'partial' => 'Partly correct', 'incorrect' => 'Incorrect'] as $v => $lab): ?>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="verdict" id="v_<?= e($v) ?>" value="<?= e($v) ?>" <?= $t['verdict'] === $v ? 'checked' : '' ?>>
                            <label class="form-check-label" for="v_<?= e($v) ?>"><?= e($lab) ?></label>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="rating">Rating</label>
                    <select class="form-select w-auto" id="rating" name="rating">
                        <option value="">Choose…</option>
                        <?php for ($i = 1; $i <= $ratingMax; $i++): ?>
                            <option value="<?= $i ?>" <?= (int)$t['rating'] === $i ? 'selected' : '' ?>><?= $i ?> of <?= $ratingMax ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="comments">Comments</label>
                    <textarea class="form-control" id="comments" name="comments" rows="2"><?= e((string)$t['comments']) ?></textarea>
                </div>
                <div class="d-flex align-items-center gap-3 flex-wrap">
                    <button class="btn btn-arc" type="submit" id="eval-save"><i class="bi bi-save"></i> Save evaluation</button>
                    <div>WER <strong id="wer-out"><?= lab_pct($t['wer']) ?></strong> · CER <strong id="cer-out"><?= lab_pct($t['cer']) ?></strong></div>
                </div>
                <div id="eval-msg" class="mt-3"></div>
                <?php if ($t['status'] === 'evaluated'): ?>
                    <div class="small text-muted mt-2">Last evaluated <?= e((string)$t['evaluated_at']) ?><?= $t['evaluator_name'] ? ' by ' . e($t['evaluator_name']) : '' ?>.</div>
                <?php endif; ?>
            </form>
        </div></div>
    </div>
</div>
<?php
    require __DIR__ . '/includes/footer.php';
    exit;
endif;

/* ============================================================= main view */
$recentAsr = db_all('SELECT id, test_code, language_code, status, verdict, wer, created_at FROM asr_tests ORDER BY id DESC LIMIT 10');
$recentTr = db_all('SELECT id, source_lang, target_lang, mode, model, status, processing_ms, LEFT(source_text, 60) AS preview, created_at FROM translations ORDER BY id DESC LIMIT 8');
$recentTts = db_all('SELECT id, language_code, model, status, error_code, processing_ms, audio_path, created_at FROM tts_outputs ORDER BY id DESC LIMIT 8');
$langOptions = function (string $selected = '') use ($langs): string {
    $html = '';
    foreach ($langs as $code => $name) {
        $html .= '<option value="' . e($code) . '"' . ($code === $selected ? ' selected' : '') . '>' . e($name) . '</option>';
    }
    return $html;
};
?>
<div class="mb-3">
    <h1 class="h3 page-title mb-0">Evaluation Lab</h1>
    <div class="text-muted">Test each part on its own: speech to text, translation and text to speech.</div>
</div>

<?php if (!$langs): ?>
    <div class="alert alert-warning">No language is enabled. An administrator can enable languages in Settings.</div>
<?php require __DIR__ . '/includes/footer.php'; exit; endif; ?>

<ul class="nav nav-pills mb-3" role="tablist">
    <li class="nav-item"><button class="nav-link active" data-bs-toggle="pill" data-bs-target="#tab-asr" type="button"><i class="bi bi-mic"></i> Speech to text</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-tr" type="button"><i class="bi bi-arrow-left-right"></i> Translation</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-tts" type="button"><i class="bi bi-volume-up"></i> Text to speech</button></li>
</ul>

<div class="tab-content">
<!-- ===================================================== speech to text -->
<div class="tab-pane fade show active" id="tab-asr">
    <div class="row g-3">
        <div class="col-lg-5">
            <div class="card h-100"><div class="card-header">New speech-to-text test</div><div class="card-body">
                <div class="mb-3">
                    <label class="form-label" for="asr-lang">Language spoken</label>
                    <select class="form-select" id="asr-lang"><?= $langOptions() ?></select>
                </div>
                <ul class="nav nav-tabs mb-3">
                    <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#asr-rec" type="button">Record</button></li>
                    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#asr-up" type="button">Upload a file</button></li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane fade show active" id="asr-rec">
                        <div class="d-flex align-items-center gap-2 mb-2">
                            <button class="btn btn-outline-danger" type="button" id="rec-start"><i class="bi bi-record-circle"></i> Start</button>
                            <button class="btn btn-outline-secondary" type="button" id="rec-stop" disabled><i class="bi bi-stop-circle"></i> Stop</button>
                            <button class="btn btn-outline-danger" type="button" id="rec-discard" disabled><i class="bi bi-trash"></i> Discard</button>
                            <span id="rec-status" class="small text-muted"></span>
                        </div>
                        <audio controls class="w-100 d-none" id="rec-preview"></audio>
                        <div class="form-text">Clips are limited to <?= (int)setting_int('recording.max_seconds', 30) ?> seconds. The browser will ask for microphone permission.</div>
                    </div>
                    <div class="tab-pane fade" id="asr-up">
                        <input class="form-control mb-2" type="file" id="up-file" accept="audio/*,.wav,.webm,.ogg,.mp3,.m4a,.flac">
                        <audio controls class="w-100 d-none" id="up-preview"></audio>
                        <button class="btn btn-outline-danger btn-sm mt-2 d-none" type="button" id="up-clear"><i class="bi bi-trash"></i> Remove this file</button>
                        <div class="form-text">Allowed: <?= e((string)setting('recording.allowed_formats', 'wav,webm,ogg,mp3,m4a,flac')) ?> · up to <?= (int)setting_int('recording.max_upload_mb', 10) ?> MB.</div>
                    </div>
                </div>
                <div class="d-grid mt-3">
                    <button class="btn btn-arc" type="button" id="asr-go" disabled><i class="bi bi-chat-square-text"></i> Transcribe</button>
                </div>
                <div id="asr-msg" class="mt-3"></div>
            </div></div>
        </div>
        <div class="col-lg-7">
            <div class="card h-100"><div class="card-header">Recent speech-to-text tests</div>
            <?php if (!$recentAsr): ?><div class="card-body text-muted">No tests yet. Record or upload a clip to begin.</div>
            <?php else: ?><div class="table-responsive"><table class="table table-hover align-middle mb-0">
                <thead><tr><th>Test</th><th>Language</th><th>Status</th><th>Verdict</th><th class="text-end">WER</th><th>When</th></tr></thead><tbody>
                <?php foreach ($recentAsr as $r): ?>
                    <tr><td><a href="<?= e(url('evaluation_lab.php?id=' . (int)$r['id'])) ?>"><?= e($r['test_code']) ?></a></td>
                        <td><?= e(lang_name($r['language_code'])) ?></td><td><?= e($r['status']) ?></td><td><?= e($r['verdict'] ?? '—') ?></td>
                        <td class="text-end"><?= lab_pct($r['wer']) ?></td><td class="text-muted small"><?= e($r['created_at']) ?></td></tr>
                <?php endforeach; ?></tbody></table></div><?php endif; ?></div>
        </div>
    </div>
</div>

<!-- ======================================================== translation -->
<div class="tab-pane fade" id="tab-tr">
    <div class="row g-3">
        <div class="col-lg-6">
            <div class="card h-100"><div class="card-header">New translation test</div><div class="card-body">
                <div class="row g-2 mb-3">
                    <div class="col-6"><label class="form-label" for="tr-src">From</label><select class="form-select" id="tr-src"><?= $langOptions('en') ?></select></div>
                    <div class="col-6"><label class="form-label" for="tr-tgt">To</label><select class="form-select" id="tr-tgt"><?= $langOptions(array_key_first($langs) === 'en' ? (array_keys($langs)[1] ?? '') : array_key_first($langs)) ?></select></div>
                    <div class="col-6"><label class="form-label" for="tr-engine">Engine</label>
                        <select class="form-select" id="tr-engine">
                            <?php $eng = (string)setting('translation.engine', 'nllb'); ?>
                            <option value="nllb" <?= $eng === 'nllb' ? 'selected' : '' ?>>NLLB-200 (light)</option>
                            <option value="natlas_llm" <?= $eng === 'natlas_llm' ? 'selected' : '' ?>>N-ATLaS LLM (GPU)</option>
                        </select></div>
                    <div class="col-6"><label class="form-label" for="tr-mode">Route</label>
                        <select class="form-select" id="tr-mode">
                            <option value="direct">Direct</option>
                            <option value="pivot">Through English</option>
                        </select></div>
                </div>
                <label class="form-label" for="tr-text">Text</label>
                <textarea class="form-control" id="tr-text" rows="4" maxlength="<?= LAB_TRANSLATE_MAX_CHARS ?>"></textarea>
                <div class="d-grid mt-3"><button class="btn btn-arc" type="button" id="tr-go"><i class="bi bi-translate"></i> Translate</button></div>
                <div id="tr-msg" class="mt-3"></div>
                <div id="tr-out" class="d-none mt-3">
                    <div class="small text-muted mb-1">Translation</div>
                    <div class="transcript-box p-3" id="tr-text-out"></div>
                    <div class="small text-muted mt-2" id="tr-meta"></div>
                    <div class="small mt-2 d-none" id="tr-pivot-wrap"><span class="text-muted">English in between:</span> <span id="tr-pivot"></span></div>
                </div>
            </div></div>
        </div>
        <div class="col-lg-6">
            <div class="card h-100"><div class="card-header">Recent translation tests</div>
            <?php if (!$recentTr): ?><div class="card-body text-muted">No translation tests yet.</div>
            <?php else: ?><div class="table-responsive"><table class="table align-middle mb-0">
                <thead><tr><th>Pair</th><th>Text</th><th>Status</th><th class="text-end">Time</th></tr></thead><tbody>
                <?php foreach ($recentTr as $r): ?>
                    <tr><td><span class="badge lang-badge"><?= e($r['source_lang']) ?> → <?= e($r['target_lang']) ?></span></td>
                        <td class="small"><?= e($r['preview']) ?></td>
                        <td><span class="badge text-bg-<?= $r['status'] === 'ok' ? 'success' : 'danger' ?>"><?= e($r['status']) ?></span></td>
                        <td class="text-end small"><?= $r['processing_ms'] !== null ? (int)$r['processing_ms'] . ' ms' : '—' ?></td></tr>
                <?php endforeach; ?></tbody></table></div><?php endif; ?></div>
        </div>
    </div>
</div>

<!-- ===================================================== text to speech -->
<div class="tab-pane fade" id="tab-tts">
    <div class="row g-3">
        <div class="col-lg-6">
            <div class="card h-100"><div class="card-header">New text-to-speech test</div><div class="card-body">
                <?php if (!$ttsOn): ?>
                    <div class="alert alert-warning">Text to speech is switched off.
                        <?= has_role(['admin']) ? '<a href="' . e(url('settings.php')) . '">Turn it on in Settings</a>.' : 'Ask an administrator to turn it on in Settings.' ?></div>
                <?php endif; ?>
                <div class="mb-3"><label class="form-label" for="tts-lang">Language</label><select class="form-select" id="tts-lang"><?= $langOptions() ?></select></div>
                <label class="form-label" for="tts-text">Text to speak</label>
                <textarea class="form-control" id="tts-text" rows="3" maxlength="<?= LAB_TTS_MAX_CHARS ?>"></textarea>
                <div class="d-grid mt-3"><button class="btn btn-arc" type="button" id="tts-go" <?= $ttsOn ? '' : 'disabled' ?>><i class="bi bi-play-circle"></i> Speak</button></div>
                <div id="tts-msg" class="mt-3"></div>
                <audio controls class="w-100 mt-3 d-none" id="tts-audio"></audio>
                <div class="small text-muted mt-2" id="tts-meta"></div>
                <div class="form-text mt-2">Voice availability differs by language. If a language has no voice checkpoint, the test fails with a clear message instead of a fake result.</div>
            </div></div>
        </div>
        <div class="col-lg-6">
            <div class="card h-100"><div class="card-header">Recent text-to-speech tests</div>
            <?php if (!$recentTts): ?><div class="card-body text-muted">No text-to-speech tests yet.</div>
            <?php else: ?><div class="table-responsive"><table class="table align-middle mb-0">
                <thead><tr><th>Language</th><th>Status</th><th class="text-end">Time</th><th>Audio</th></tr></thead><tbody>
                <?php foreach ($recentTts as $r): ?>
                    <tr><td><?= e(lang_name($r['language_code'])) ?></td>
                        <td><span class="badge text-bg-<?= $r['status'] === 'ok' ? 'success' : ($r['status'] === 'unavailable' ? 'warning' : 'danger') ?>"><?= e($r['status']) ?></span>
                            <?php if ($r['error_code']): ?><span class="small text-muted"><?= e($r['error_code']) ?></span><?php endif; ?></td>
                        <td class="text-end small"><?= $r['processing_ms'] !== null ? (int)$r['processing_ms'] . ' ms' : '—' ?></td>
                        <td><?php if (!empty($r['audio_path'])): ?><audio controls preload="none" style="height:32px;width:170px" src="<?= e(url('evaluation_lab.php?audio=tts&id=' . (int)$r['id'])) ?>"></audio><?php else: ?>—<?php endif; ?></td></tr>
                <?php endforeach; ?></tbody></table></div><?php endif; ?></div>
        </div>
    </div>
</div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
