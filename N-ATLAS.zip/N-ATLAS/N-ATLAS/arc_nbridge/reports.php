<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/evidence.php';
$user = require_role(['admin', 'researcher']);

$f = report_filters($_SERVER['REQUEST_METHOD'] === 'POST' ? $_POST : $_GET);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = (string)($_POST['action'] ?? '');
    $back = 'reports.php?' . http_build_query(array_filter(['date_from' => $f['date_from'], 'date_to' => $f['date_to'], 'language' => $f['language'], 'include_demo' => $f['include_demo'] ? '1' : '']));
    try {
        if ($action === 'download') {
            $key = (string)($_POST['dataset'] ?? '');
            $format = (string)($_POST['format'] ?? '');
            if (!isset(REPORT_DATASETS[$key]) || !in_array($format, ['csv', 'xlsx'], true)) {
                throw new InvalidArgumentException('Unknown dataset or format.');
            }
            $d = report_dataset($key, $f);
            $bytes = $format === 'csv' ? export_csv($d['headers'], $d['rows']) : export_xlsx([$d['title'] => $d]);
            $kind = 'export';
        } elseif ($action === 'summary_pdf') {
            $key = 'summary';
            $format = 'pdf';
            $kind = 'report';
            $bytes = report_pdf(report_summary($f), report_asr_examples($f), ['app' => (string)setting('app.name', 'ARC N-BRIDGE'),
                'version' => (string)setting('app.version', '0.1.0-prototype'), 'generated_by' => $user['full_name'], 'generated_at' => date('Y-m-d H:i:s')]);
            $d = ['rows' => []];
        } else {
            throw new InvalidArgumentException('Unknown request.');
        }
    } catch (InvalidArgumentException $e) {
        flash('danger', $e->getMessage());
        redirect($back);
    } catch (RuntimeException $e) {
        flash('danger', $e->getMessage());
        redirect($back);
    }
    $filename = export_filename($key, $format);
    $exportId = null;
    if (!export_store($filename, $bytes)) {
        error_log('ARC N-BRIDGE: could not keep a copy of ' . $filename . ' in storage/exports');
    } elseif (evidence_ensure_schema() === null) {
        $exportId = export_register($kind, $format, $key, $filename, $action === 'download' ? count($d['rows']) : null, $f['include_demo'], (int)$user['id']);
    }
    activity('report.' . $format, 'export', $exportId, ['dataset' => $key]);
    header('Content-Type: ' . export_mime($format));
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . strlen($bytes));
    header('Cache-Control: no-store');
    echo $bytes;
    exit;
}

$pageTitle = 'Reports';
$active = 'reports';
$zip = class_exists('ZipArchive');
require __DIR__ . '/includes/header.php';
$hidden = function (string $action, string $extra = '') use ($f): string {
    return csrf_field() . '<input type="hidden" name="action" value="' . e($action) . '">' . $extra
        . '<input type="hidden" name="date_from" value="' . e($f['date_from']) . '"><input type="hidden" name="date_to" value="' . e($f['date_to']) . '">'
        . '<input type="hidden" name="language" value="' . e($f['language']) . '"><input type="hidden" name="include_demo" value="' . ($f['include_demo'] ? '1' : '') . '">';
};
?>
<div class="mb-3"><h1 class="h3 page-title mb-0">Reports and exports</h1>
    <div class="text-muted">Download your research data as CSV or Excel, or a summary PDF. Every figure comes from the database.</div></div>

<div class="card mb-3"><div class="card-header">Filters</div><div class="card-body">
    <form method="get" class="row g-2 align-items-end">
        <div class="col-6 col-md-3"><label class="form-label" for="date_from">From</label><input class="form-control" type="date" id="date_from" name="date_from" value="<?= e($f['date_from']) ?>"></div>
        <div class="col-6 col-md-3"><label class="form-label" for="date_to">To</label><input class="form-control" type="date" id="date_to" name="date_to" value="<?= e($f['date_to']) ?>"></div>
        <div class="col-6 col-md-3"><label class="form-label" for="language">Language</label>
            <select class="form-select" id="language" name="language"><option value="">All</option>
                <?php foreach (LANGS as $c => $n): ?><option value="<?= e($c) ?>" <?= $f['language'] === $c ? 'selected' : '' ?>><?= e($n) ?></option><?php endforeach; ?></select></div>
        <div class="col-6 col-md-3"><div class="form-check mb-2"><input class="form-check-input" type="checkbox" id="include_demo" name="include_demo" value="1" <?= $f['include_demo'] ? 'checked' : '' ?>>
            <label class="form-check-label" for="include_demo">Include demo records</label></div>
            <button class="btn btn-arc w-100" type="submit"><i class="bi bi-funnel"></i> Apply</button></div>
    </form>
    <div class="form-text mt-2">Records of participants who withdrew consent are always left out. Each file is limited to <?= number_format(REPORT_ROW_CAP) ?> rows.</div>
</div></div>

<div class="row g-3">
    <?php foreach (REPORT_DATASETS as $key => $title): ?>
    <div class="col-md-6 col-xl-4"><div class="card h-100"><div class="card-body d-flex flex-column">
        <div class="fw-semibold"><?= e($title) ?></div>
        <div class="text-muted small mb-3"><?= number_format(report_dataset_count($key, $f)) ?> rows with these filters</div>
        <div class="mt-auto d-flex gap-2">
            <form method="post"><?= $hidden('download', '<input type="hidden" name="dataset" value="' . e($key) . '"><input type="hidden" name="format" value="csv">') ?>
                <button class="btn btn-outline-arc btn-sm" type="submit"><i class="bi bi-filetype-csv"></i> CSV</button></form>
            <form method="post"><?= $hidden('download', '<input type="hidden" name="dataset" value="' . e($key) . '"><input type="hidden" name="format" value="xlsx">') ?>
                <button class="btn btn-outline-arc btn-sm" type="submit" <?= $zip ? '' : 'disabled title="Enable extension=zip in php.ini"' ?>><i class="bi bi-file-earmark-excel"></i> Excel</button></form>
        </div>
    </div></div></div>
    <?php endforeach; ?>
    <div class="col-md-6 col-xl-4"><div class="card h-100 border-success"><div class="card-body d-flex flex-column">
        <div class="fw-semibold"><i class="bi bi-file-earmark-pdf"></i> Summary report (PDF)</div>
        <div class="text-muted small mb-3">Results by language, translation and voice statistics, models used, and method notes.</div>
        <form method="post" class="mt-auto"><?= $hidden('summary_pdf') ?><button class="btn btn-arc btn-sm" type="submit"><i class="bi bi-download"></i> Download PDF</button></form>
    </div></div></div>
</div>
<?php if (!$zip): ?><div class="alert alert-warning mt-3 mb-0">Excel export needs the PHP zip extension. In XAMPP open php.ini, enable <code>extension=zip</code>, and restart Apache.</div><?php endif; ?>
<div class="mt-3 text-muted small">Need everything in one verifiable bundle for a submission? Use the <a href="<?= e(url('evidence.php')) ?>">Evidence Center</a>.</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
