"""Regression: services.asr_service.transcribe must call the transformers pipeline the way transformers accepts.

History: `generate_kwargs=None` was passed to the ASR pipeline and transformers 4.57.x crashed inside
_sanitize_parameters (it runs dict.update(None)). The route tests stub transcribe() entirely, so they could not
see it. These tests run the REAL transcribe() against a fake pipeline that fails exactly like transformers does.
"""
import threading

import numpy as np
import pytest

from models.model_manager import manager
from services import asr_service


class _FakeSlot:
    repo = "stub/asr"

    def __init__(self, pipeline):
        self.obj = pipeline
        self.run_lock = threading.Lock()


def _transformers_like_pipeline(calls):
    """Mimics AutomaticSpeechRecognitionPipeline._sanitize_parameters for the generate_kwargs argument."""
    def pipeline(inputs, **kwargs):
        calls.append((inputs, dict(kwargs)))
        if "generate_kwargs" in kwargs:
            forward_params = {}
            forward_params.update(kwargs.pop("generate_kwargs"))  # TypeError if the value is None
        return {"text": "  hello from the stub  "}
    return pipeline


@pytest.fixture()
def audio():
    return np.zeros(16000, dtype=np.float32)


def test_no_generate_kwargs_argument_is_passed_by_default(monkeypatch, audio):
    monkeypatch.delenv("NATLAS_FORCE_WHISPER_LANGUAGE", raising=False)
    calls = []
    monkeypatch.setattr(manager, "get_asr", lambda code: _FakeSlot(_transformers_like_pipeline(calls)))
    out = asr_service.transcribe("en", audio)
    assert out["text"] == "hello from the stub"
    assert out["model_repo"] == "stub/asr"
    assert "generate_kwargs" not in calls[0][1]          # key must be absent, not None
    assert calls[0][0]["sampling_rate"] == 16000


def test_forced_language_is_passed_as_a_real_dict(monkeypatch, audio):
    monkeypatch.setenv("NATLAS_FORCE_WHISPER_LANGUAGE", "yoruba")
    calls = []
    monkeypatch.setattr(manager, "get_asr", lambda code: _FakeSlot(_transformers_like_pipeline(calls)))
    asr_service.transcribe("yo", audio)
    assert calls[0][1]["generate_kwargs"] == {"language": "yoruba", "task": "transcribe"}


def test_fake_pipeline_really_fails_on_none(audio):
    """Guards the guard: proves the fake reproduces the production TypeError."""
    with pytest.raises(TypeError):
        _transformers_like_pipeline([])({"raw": audio, "sampling_rate": 16000}, generate_kwargs=None)
