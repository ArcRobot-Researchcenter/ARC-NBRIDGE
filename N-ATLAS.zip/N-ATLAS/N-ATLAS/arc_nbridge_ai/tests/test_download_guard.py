"""Translation/TTS models must never start a surprise multi-GB download on a slow connection."""
import sys
import types

import pytest

from models import model_manager as mm
from utils.errors import ApiError


@pytest.fixture(autouse=True)
def fake_libs(monkeypatch):
    monkeypatch.setattr(mm, "_require_torch", lambda: None)
    monkeypatch.setattr(mm.ModelManager, "_device_index", staticmethod(lambda: -1))


def _install_fake_transformers(monkeypatch, calls, error=None):
    class _Loader:
        @staticmethod
        def from_pretrained(repo, **kw):
            calls.append((repo, kw))
            if error:
                raise error
            return types.SimpleNamespace(to=lambda d: None)
    mod = types.SimpleNamespace(AutoTokenizer=_Loader, AutoModelForSeq2SeqLM=_Loader, VitsModel=_Loader,
                                AutoModelForCausalLM=_Loader)
    monkeypatch.setitem(sys.modules, "transformers", mod)


def test_default_blocks_download_and_reports_clearly(monkeypatch):
    monkeypatch.delenv("ALLOW_MODEL_DOWNLOAD", raising=False)
    calls = []
    _install_fake_transformers(monkeypatch, calls, error=OSError("We couldn't connect to 'https://huggingface.co'"))
    m = mm.ModelManager()
    with pytest.raises(ApiError) as exc:
        m.get_nllb()
    assert exc.value.error_code == "MODEL_NOT_DOWNLOADED" and exc.value.status_code == 503
    assert "ALLOW_MODEL_DOWNLOAD" in exc.value.message and "Colab" in exc.value.message
    assert all(kw.get("local_files_only") is True for _, kw in calls)      # it never tried the network


def test_tts_also_guarded(monkeypatch):
    monkeypatch.delenv("ALLOW_MODEL_DOWNLOAD", raising=False)
    _install_fake_transformers(monkeypatch, [], error=OSError("not found locally"))
    with pytest.raises(ApiError) as exc:
        mm.ModelManager().get_tts("ig")
    assert exc.value.error_code == "MODEL_NOT_DOWNLOADED"


def test_cached_model_loads_offline(monkeypatch):
    monkeypatch.delenv("ALLOW_MODEL_DOWNLOAD", raising=False)
    calls = []
    _install_fake_transformers(monkeypatch, calls)
    slot = mm.ModelManager().get_nllb()
    assert slot.obj is not None and calls[0][1]["local_files_only"] is True


def test_download_allowed_when_enabled(monkeypatch):
    monkeypatch.setenv("ALLOW_MODEL_DOWNLOAD", "true")
    calls = []
    _install_fake_transformers(monkeypatch, calls)
    mm.ModelManager().get_nllb()
    assert all("local_files_only" not in kw for _, kw in calls)


def test_other_errors_keep_their_own_code(monkeypatch):
    monkeypatch.setenv("ALLOW_MODEL_DOWNLOAD", "true")
    _install_fake_transformers(monkeypatch, [], error=OSError("disk full"))
    with pytest.raises(ApiError) as exc:
        mm.ModelManager().get_nllb()
    assert exc.value.error_code == "MODEL_LOAD_FAILED"


def test_status_reports_flag(monkeypatch):
    monkeypatch.delenv("ALLOW_MODEL_DOWNLOAD", raising=False)
    assert mm.ModelManager().status()["downloads_allowed"] is False
