"""Authentication and the JSON envelopes."""


def test_health_is_public_and_leaks_nothing(client, monkeypatch):
    monkeypatch.setenv("HF_TOKEN", "hf_abcdefghijklmnop1234")
    r = client.get("/health")
    assert r.status_code == 200
    body = r.json()
    assert body["success"] is True and body["status"] == "ok"
    assert body["auth_configured"] is True
    assert "test-secret-value-123" not in r.text
    assert "hf_abcdefghijklmnop1234" not in r.text


def test_protected_route_rejects_missing_secret(client):
    r = client.get("/models")
    assert r.status_code == 401
    body = r.json()
    assert body["success"] is False
    assert body["error_code"] == "UNAUTHORIZED"


def test_protected_route_rejects_wrong_secret(client):
    r = client.get("/models", headers={"X-API-Secret": "wrong"})
    assert r.status_code == 401
    assert r.json()["error_code"] == "UNAUTHORIZED"


def test_protected_route_accepts_correct_secret(client, auth, monkeypatch):
    monkeypatch.setenv("HF_TOKEN", "hf_abcdefghijklmnop1234")
    r = client.get("/models", headers=auth)
    assert r.status_code == 200
    body = r.json()
    assert body["success"] is True
    assert body["hf_token_configured"] is True
    assert set(body["asr"]) == {"ha", "yo", "ig", "en"}
    # The token and the secret must never be echoed back.
    assert "hf_abcdefghijklmnop1234" not in r.text
    assert "test-secret-value-123" not in r.text


def test_service_refuses_to_run_open_when_no_secret_configured(client, monkeypatch):
    monkeypatch.delenv("AI_API_SECRET", raising=False)
    r = client.get("/models", headers={"X-API-Secret": "anything"})
    assert r.status_code == 503
    assert r.json()["error_code"] == "AUTH_NOT_CONFIGURED"


def test_explicit_no_auth_opt_out_for_local_testing(client, monkeypatch):
    monkeypatch.delenv("AI_API_SECRET", raising=False)
    monkeypatch.setenv("ALLOW_NO_AUTH", "true")
    assert client.get("/models").status_code == 200


def test_failure_envelope_has_the_standard_fields(client):
    body = client.get("/models").json()
    assert set(body) == {"success", "request_id", "error_code", "message", "details"}
    assert body["request_id"]


def test_request_id_header_is_generated_and_echoed(client):
    assert client.get("/health").headers["X-Request-ID"]
    r = client.get("/health", headers={"X-Request-ID": "abc-123"})
    assert r.headers["X-Request-ID"] == "abc-123"
    assert r.json()["request_id"] == "abc-123"
    assert "X-Process-Time" in r.headers
