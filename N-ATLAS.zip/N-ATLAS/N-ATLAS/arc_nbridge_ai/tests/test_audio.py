"""Audio decoding limits and behaviour (no model needed)."""
import pytest

from services import audio_service
from utils.errors import ApiError


def _code(exc_info):
    return exc_info.value.error_code


def test_valid_wav_is_decoded_to_16k_mono(make_wav):
    audio, meta = audio_service.decode_audio(make_wav(seconds=1.0))
    assert audio.dtype.name == "float32" and audio.ndim == 1
    assert meta["duration_sec"] == pytest.approx(1.0, abs=0.05)
    assert meta["low_energy"] is False


def test_other_sample_rates_are_resampled_to_16k(make_wav):
    audio, _ = audio_service.decode_audio(make_wav(seconds=1.0, sr=8000))
    assert abs(len(audio) - 16000) <= 2


def test_empty_upload_is_rejected():
    with pytest.raises(ApiError) as exc:
        audio_service.decode_audio(b"")
    assert _code(exc) == "AUDIO_EMPTY"


def test_garbage_bytes_are_rejected():
    with pytest.raises(ApiError) as exc:
        audio_service.decode_audio(b"this is definitely not audio data " * 50)
    assert _code(exc) == "AUDIO_INVALID"
    assert exc.value.status_code == 422


def test_too_short_recording_is_rejected(make_wav):
    with pytest.raises(ApiError) as exc:
        audio_service.decode_audio(make_wav(seconds=0.05))
    assert _code(exc) == "AUDIO_TOO_SHORT"


def test_too_long_recording_is_rejected(make_wav, monkeypatch):
    monkeypatch.setenv("MAX_AUDIO_SECONDS", "2")
    with pytest.raises(ApiError) as exc:
        audio_service.decode_audio(make_wav(seconds=3.0))
    assert _code(exc) == "AUDIO_TOO_LONG"


def test_oversized_upload_is_rejected(make_wav, monkeypatch):
    monkeypatch.setenv("MAX_UPLOAD_MB", "0.001")  # about 1 KB
    with pytest.raises(ApiError) as exc:
        audio_service.decode_audio(make_wav(seconds=1.0))
    assert _code(exc) == "FILE_TOO_LARGE"
    assert exc.value.status_code == 413


def test_silent_audio_is_flagged_low_energy(make_wav):
    _, meta = audio_service.decode_audio(make_wav(seconds=1.0, amplitude=0.0))
    assert meta["low_energy"] is True


def test_asr_route_rejects_short_audio_before_any_model(client, auth, make_wav):
    files = {"file": ("short.wav", make_wav(seconds=0.05), "audio/wav")}
    r = client.post("/asr", files=files, data={"language": "ha"}, headers=auth)
    assert r.status_code == 422
    assert r.json()["error_code"] == "AUDIO_TOO_SHORT"


def test_asr_route_rejects_garbage_upload(client, auth):
    files = {"file": ("bad.wav", b"not audio at all " * 100, "audio/wav")}
    r = client.post("/asr", files=files, data={"language": "ha"}, headers=auth)
    assert r.status_code == 422
    assert r.json()["error_code"] == "AUDIO_INVALID"
