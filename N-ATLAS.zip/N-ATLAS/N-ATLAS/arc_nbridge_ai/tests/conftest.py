"""Shared fixtures. No test here loads a real model: they check the service's contract, not model quality."""
import io
import os
import tempfile
import wave

# Must be set BEFORE `app` is imported, because the logger creates its log folder at import time.
os.environ.setdefault("LOG_DIR", tempfile.mkdtemp(prefix="arc_ai_test_logs_"))

import numpy as np  # noqa: E402
import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

SECRET = "test-secret-value-123"


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch):
    """Every test starts with a known, authenticated configuration."""
    monkeypatch.setenv("AI_API_SECRET", SECRET)
    for name in ("ALLOW_NO_AUTH", "HF_TOKEN", "MAX_AUDIO_SECONDS", "MAX_UPLOAD_MB",
                 "NATLAS_ENABLED_LANGUAGES", "NATLAS_FORCE_WHISPER_LANGUAGE"):
        monkeypatch.delenv(name, raising=False)


@pytest.fixture()
def client():
    from app import app
    # raise_server_exceptions=False so a 500 comes back as the real JSON envelope the PHP app would see.
    return TestClient(app, raise_server_exceptions=False)


@pytest.fixture()
def auth():
    return {"X-API-Secret": SECRET}


@pytest.fixture()
def make_wav():
    """Factory returning the bytes of a mono 16-bit WAV file."""
    def _make(seconds=1.0, sr=16000, amplitude=0.3, freq=440.0):
        n = int(seconds * sr)
        t = np.arange(n) / sr
        samples = (amplitude * np.sin(2 * np.pi * freq * t) * 32767).astype("<i2")
        buf = io.BytesIO()
        with wave.open(buf, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(sr)
            w.writeframes(samples.tobytes())
        return buf.getvalue()
    return _make
