"""Input validation. Every case here is rejected BEFORE any model is touched."""
import pytest

from services import translation_service, tts_service


def _translate(client, auth, **overrides):
    payload = {"source_language": "en", "target_language": "ha", "text": "Good morning"}
    payload.update(overrides)
    return client.post("/translate", json=payload, headers=auth)


def _error(response, status, code):
    assert response.status_code == status, response.text
    body = response.json()
    assert body["success"] is False
    assert body["error_code"] == code
    return body


def test_translate_missing_fields_returns_validation_error(client, auth):
    body = _error(client.post("/translate", json={}, headers=auth), 422, "VALIDATION_ERROR")
    fields = {d["field"] for d in body["details"]}
    assert {"source_language", "target_language", "text"} <= fields


def test_translate_unsupported_language(client, auth):
    _error(_translate(client, auth, target_language="klingon"), 422, "LANGUAGE_UNSUPPORTED")


def test_translate_same_language(client, auth):
    _error(_translate(client, auth, source_language="en", target_language="English"), 422, "SAME_LANGUAGE")


def test_translate_empty_text(client, auth):
    _error(_translate(client, auth, text="   "), 422, "TEXT_EMPTY")


def test_translate_text_too_long(client, auth):
    _error(_translate(client, auth, text="a" * (translation_service.MAX_CHARS + 1)), 422, "TEXT_TOO_LONG")


def test_translate_unknown_engine(client, auth):
    _error(_translate(client, auth, engine="gpt"), 422, "ENGINE_UNSUPPORTED")


def test_translate_unknown_mode(client, auth):
    _error(_translate(client, auth, mode="sideways"), 422, "MODE_UNSUPPORTED")


def test_llm_engine_is_disabled_by_default(monkeypatch):
    # Tested on the manager directly so the result does not depend on torch being installed.
    from models.model_manager import manager
    from utils.errors import ApiError
    monkeypatch.delenv("ENABLE_NATLAS_LLM", raising=False)
    with pytest.raises(ApiError) as exc:
        manager.get_llm()
    assert exc.value.error_code == "MODEL_DISABLED"
    assert exc.value.status_code == 503


def test_tts_empty_text(client, auth):
    _error(client.post("/tts", json={"language": "ha", "text": " "}, headers=auth), 422, "TEXT_EMPTY")


def test_tts_text_too_long(client, auth):
    text = "a" * (tts_service.MAX_CHARS + 1)
    if len(text) > 2000:
        pytest.skip("MAX_TTS_CHARS exceeds the request-model limit")
    _error(client.post("/tts", json={"language": "ha", "text": text}, headers=auth), 422, "TEXT_TOO_LONG")


def test_tts_unsupported_language(client, auth):
    _error(client.post("/tts", json={"language": "zulu", "text": "hello"}, headers=auth), 422, "LANGUAGE_UNSUPPORTED")


def test_asr_requires_a_file(client, auth):
    _error(client.post("/asr", data={"language": "ha"}, headers=auth), 422, "VALIDATION_ERROR")


def test_asr_requires_a_language(client, auth, make_wav):
    files = {"file": ("a.wav", make_wav(), "audio/wav")}
    _error(client.post("/asr", files=files, headers=auth), 422, "VALIDATION_ERROR")


def test_asr_unsupported_language(client, auth, make_wav):
    files = {"file": ("a.wav", make_wav(), "audio/wav")}
    _error(client.post("/asr", files=files, data={"language": "swahili"}, headers=auth), 422, "LANGUAGE_UNSUPPORTED")


def test_validation_requires_auth_first(client):
    r = client.post("/translate", json={"source_language": "en", "target_language": "ha", "text": "hi"})
    assert r.status_code == 401
