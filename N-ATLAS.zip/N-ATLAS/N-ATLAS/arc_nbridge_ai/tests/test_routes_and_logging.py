"""Route contracts (with the model layer stubbed), error hiding, log redaction and the model manager."""
import importlib.util
import logging

import pytest

from models.model_manager import LANGUAGES, manager, normalise_language
from services import asr_service, translation_service, tts_service
from utils.errors import ApiError
from utils.logger import RedactFilter

HAS_AI_LIBS = all(importlib.util.find_spec(m) is not None for m in ("torch", "transformers"))


# --------------------------------------------------------------------------- ASR route
def test_asr_success_contract_with_stubbed_model(client, auth, make_wav, monkeypatch):
    monkeypatch.setattr(asr_service, "transcribe", lambda code, audio: {
        "text": "sannu", "processing_time": 0.01, "model": "stub model", "model_repo": "stub/repo"})
    files = {"file": ("a.wav", make_wav(seconds=1.0), "audio/wav")}
    r = client.post("/asr", files=files, data={"language": "Hausa"}, headers=auth)
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["success"] is True
    assert body["language_code"] == "ha" and body["transcription"] == "sannu"
    assert body["audio_duration"] == pytest.approx(1.0, abs=0.05)
    assert body["low_energy"] is False
    assert body["model_repo"] == "stub/repo"


def test_asr_disabled_language_is_reported(client, auth, make_wav, monkeypatch):
    monkeypatch.setenv("NATLAS_ENABLED_LANGUAGES", "en")
    files = {"file": ("a.wav", make_wav(), "audio/wav")}
    r = client.post("/asr", files=files, data={"language": "ha"}, headers=auth)
    assert r.status_code == 503
    assert r.json()["error_code"] == "MODEL_DISABLED"


@pytest.mark.skipif(HAS_AI_LIBS, reason="torch and transformers are installed here")
def test_asr_never_invents_a_transcription_without_ai_libraries(client, auth, make_wav):
    files = {"file": ("a.wav", make_wav(), "audio/wav")}
    r = client.post("/asr", files=files, data={"language": "en"}, headers=auth)
    assert r.status_code == 503
    body = r.json()
    assert body["success"] is False
    assert body["error_code"] == "DEPENDENCY_MISSING"
    assert "transcription" not in body


def test_unexpected_error_hides_traceback_and_internal_detail(client, auth, make_wav, monkeypatch):
    def boom(code, audio):
        raise RuntimeError(r"C:\private\path\secret_detail exploded")
    monkeypatch.setattr(asr_service, "transcribe", boom)
    files = {"file": ("a.wav", make_wav(), "audio/wav")}
    r = client.post("/asr", files=files, data={"language": "en"}, headers=auth)
    assert r.status_code == 500
    body = r.json()
    assert body["success"] is False and body["error_code"] == "INTERNAL_ERROR"
    assert "Traceback" not in r.text
    assert "secret_detail" not in r.text
    assert "private" not in r.text


# ----------------------------------------------------------------- translate / tts routes
def test_translate_success_contract_with_stubbed_engine(client, auth, monkeypatch):
    monkeypatch.setattr(translation_service, "translate", lambda src, tgt, text, engine, mode: {
        "translation": "Barka da safiya", "pivot_text": None, "mode": mode, "engine": engine,
        "model": "stub/nllb", "processing_time": 0.02})
    r = client.post("/translate", headers=auth,
                    json={"source_language": "english", "target_language": "hausa", "text": "Good morning"})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["translation"] == "Barka da safiya"
    assert body["source_language"] == "english" and body["target_language"] == "hausa"
    assert body["provider"] == "nllb" and body["mode"] == "direct"


def test_tts_success_contract_with_stubbed_engine(client, auth, monkeypatch):
    monkeypatch.setattr(tts_service, "synthesize", lambda code, text: {
        "audio_base64": "UklGRg==", "mime": "audio/wav", "sample_rate": 16000,
        "model": "stub/mms", "processing_time": 0.03})
    r = client.post("/tts", json={"language": "yo", "text": "bawo ni"}, headers=auth)
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["language_code"] == "yo" and body["mime"] == "audio/wav"
    assert body["audio_base64"] == "UklGRg=="


# ----------------------------------------------------------------- health helper routes
def test_test_model_rejects_unknown_component(client, auth):
    r = client.post("/test-model", json={"component": "video"}, headers=auth)
    assert r.status_code == 422
    assert r.json()["error_code"] == "COMPONENT_UNSUPPORTED"


def test_system_test_reports_checks_even_when_offline(client, auth, monkeypatch):
    import httpx

    def offline(*args, **kwargs):
        raise httpx.ConnectError("offline")
    monkeypatch.setattr(httpx, "head", offline)
    monkeypatch.setenv("HF_TOKEN", "hf_abcdefghijklmnop1234")
    r = client.post("/system-test", json={"load_models": False}, headers=auth)
    assert r.status_code == 200, r.text
    body = r.json()
    names = {c["name"] for c in body["checks"]}
    assert {"python", "torch", "transformers", "ffmpeg", "gpu", "hf_token", "huggingface_reachable"} <= names
    reach = next(c for c in body["checks"] if c["name"] == "huggingface_reachable")
    assert reach["status"] == "fail"
    assert body["overall"] == "fail"
    assert "hf_abcdefghijklmnop1234" not in r.text


# ------------------------------------------------------------------------ log redaction
def _redacted(message, *args):
    record = logging.LogRecord("t", logging.INFO, __file__, 1, message, args, None)
    RedactFilter().filter(record)
    return record.getMessage()


def test_logger_redacts_huggingface_tokens():
    assert "hf_abcdefghijklmnop" not in _redacted("loading with %s", "hf_abcdefghijklmnop")


def test_logger_redacts_key_value_secrets():
    out = _redacted("config api_key=ABC123 password: hunter2 token=xyz789 ok")
    for leaked in ("ABC123", "hunter2", "xyz789"):
        assert leaked not in out
    assert "[REDACTED]" in out


# --------------------------------------------------------------------- language + manager
@pytest.mark.parametrize("value,code", [("ha", "ha"), ("Hausa", "ha"), (" YORUBA ", "yo"), ("ig", "ig"),
                                        ("Igbo", "ig"), ("English", "en"), ("nigerian english", "en")])
def test_language_aliases(value, code):
    assert normalise_language(value) == code


@pytest.mark.parametrize("value", ["", "   ", "klingon", "pidgin"])
def test_unknown_languages_are_rejected(value):
    with pytest.raises(ApiError) as exc:
        normalise_language(value)
    assert exc.value.error_code == "LANGUAGE_UNSUPPORTED"


def test_the_four_supported_languages_and_default_asr_repos():
    assert set(LANGUAGES) == {"ha", "yo", "ig", "en"}
    assert manager.asr_repo("ha") == "NCAIR1/Hausa-ASR"
    assert manager.asr_repo("yo") == "NCAIR1/Yoruba-ASR"
    assert manager.asr_repo("ig") == "NCAIR1/Igbo-ASR"
    assert manager.asr_repo("en") == "NCAIR1/NigerianAccentedEnglish"


def test_model_repos_can_be_overridden_from_the_environment(monkeypatch):
    monkeypatch.setenv("NATLAS_HAUSA_MODEL", "my-org/my-hausa-asr")
    monkeypatch.setenv("TTS_YORUBA_MODEL", "my-org/my-yoruba-tts")
    assert manager.asr_repo("ha") == "my-org/my-hausa-asr"
    assert manager.tts_repo("yo") == "my-org/my-yoruba-tts"


def test_manager_status_loads_nothing_and_reports_honestly():
    status = manager.status()
    assert set(status) == {"asr", "translation", "tts"}
    assert set(status["translation"]) == {"nllb", "natlas_llm"}
    assert status["translation"]["natlas_llm"]["enabled"] is False  # off unless explicitly enabled
