import time

from fastapi import APIRouter, Depends, File, Form, Request, UploadFile

from models.model_manager import LANGUAGES, normalise_language
from services import asr_service, audio_service
from utils.logger import get_logger, log_request
from utils.responses import ok
from utils.security import verify_api_secret

router = APIRouter()
log = get_logger("arc_nbridge_ai.asr")


@router.post("/asr", dependencies=[Depends(verify_api_secret)])
def asr(request: Request, file: UploadFile = File(...), language: str = Form(...)):
    request_id = request.state.request_id
    started = time.perf_counter()
    code = "?"
    try:
        code = normalise_language(language)
        audio, meta = audio_service.decode_audio(file.file.read())
        result = asr_service.transcribe(code, audio)
        total = time.perf_counter() - started
        log_request(log, request_id, "asr", result["model_repo"], "ok", total)
        return ok(request_id, language=LANGUAGES[code].name, language_code=code, transcription=result["text"],
                  processing_time=result["processing_time"], total_time=round(total, 3),
                  audio_duration=meta["duration_sec"], low_energy=meta["low_energy"],
                  model=result["model"], model_repo=result["model_repo"])
    except Exception as exc:
        log_request(log, request_id, "asr", code, "error", time.perf_counter() - started,
                    getattr(exc, "error_code", "INTERNAL_ERROR"))
        raise
