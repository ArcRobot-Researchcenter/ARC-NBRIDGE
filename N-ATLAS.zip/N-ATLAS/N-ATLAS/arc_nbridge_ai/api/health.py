import importlib.metadata as md
import os
import platform
import time
from typing import Optional

import httpx
from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel

from models.model_manager import LANGUAGES, manager, normalise_language
from services import audio_service
from utils.errors import ApiError
from utils.responses import ok
from utils.security import hf_token, verify_api_secret

router = APIRouter()
STARTED = time.time()
SERVICE_VERSION = "0.1.0"


def _version(pkg: str) -> Optional[str]:
    try:
        return md.version(pkg)
    except md.PackageNotFoundError:
        return None


def _runtime() -> dict:
    cuda, gpu = False, None
    try:
        import torch
        cuda = bool(torch.cuda.is_available())
        gpu = torch.cuda.get_device_name(0) if cuda else None
    except ImportError:
        pass
    return {"python": platform.python_version(), "cuda_available": cuda, "gpu": gpu,
            "ffmpeg": audio_service.ffmpeg_available(),
            "libraries": {p: _version(p) for p in ("torch", "transformers", "fastapi", "numpy", "soundfile", "accelerate")}}


@router.get("/health")
def health(request: Request):
    """Unauthenticated liveness probe. Reveals no secrets and no model paths."""
    return ok(request.state.request_id, service="arc_nbridge_ai", status="ok", version=SERVICE_VERSION,
              uptime_sec=round(time.time() - STARTED, 1), auth_configured=bool(os.getenv("AI_API_SECRET")))


@router.get("/models", dependencies=[Depends(verify_api_secret)])
def models(request: Request):
    return ok(request.state.request_id, hf_token_configured=bool(hf_token()), runtime=_runtime(), **manager.status())


class TestModelIn(BaseModel):
    component: str                       # asr | translation | tts
    language: Optional[str] = None
    engine: Optional[str] = "nllb"
    text: Optional[str] = None


@router.post("/test-model", dependencies=[Depends(verify_api_secret)])
def test_model(body: TestModelIn, request: Request):
    """Loads the model and runs a smoke test. It proves the model loads and runs - it is NOT an accuracy test."""
    import numpy as np
    from services import asr_service, translation_service, tts_service
    rid = request.state.request_id
    if body.component == "asr":
        code = normalise_language(body.language or "")
        out = asr_service.transcribe(code, np.zeros(16000, dtype=np.float32))
        return ok(rid, component="asr", language_code=code, loaded=True, model_repo=out["model_repo"],
                  smoke_test="1 second of silence transcribed without error (output is not evaluated)",
                  output_text=out["text"], processing_time=out["processing_time"])
    if body.component == "translation":
        code = normalise_language(body.language or "ha")
        out = translation_service.translate("en", code, body.text or "Good morning", body.engine or "nllb", "direct")
        return ok(rid, component="translation", loaded=True, model=out["model"], output_text=out["translation"],
                  smoke_test="English sentence translated without error (quality is not evaluated)",
                  processing_time=out["processing_time"])
    if body.component == "tts":
        code = normalise_language(body.language or "")
        out = tts_service.synthesize(code, body.text or "")
        return ok(rid, component="tts", language_code=code, loaded=True, model=out["model"], mime=out["mime"],
                  audio_bytes_base64=len(out["audio_base64"]), processing_time=out["processing_time"])
    raise ApiError("COMPONENT_UNSUPPORTED", "component must be asr, translation or tts.", 422)


class SystemTestIn(BaseModel):
    load_models: bool = False


def _check(name: str, status: str, detail: str) -> dict:
    return {"name": name, "status": status, "detail": detail}


@router.post("/system-test", dependencies=[Depends(verify_api_secret)])
def system_test(body: SystemTestIn, request: Request):
    rt = _runtime()
    checks = [
        _check("python", "pass", rt["python"]),
        _check("torch", "pass" if rt["libraries"]["torch"] else "fail", rt["libraries"]["torch"] or "not installed"),
        _check("transformers", "pass" if rt["libraries"]["transformers"] else "fail",
               rt["libraries"]["transformers"] or "not installed"),
        _check("ffmpeg", "pass" if rt["ffmpeg"] else "warn",
               "found" if rt["ffmpeg"] else "not found: browser recordings (webm/m4a) cannot be decoded"),
        _check("gpu", "pass" if rt["cuda_available"] else "warn", rt["gpu"] or "no CUDA GPU (CPU inference is slow)"),
        _check("hf_token", "pass" if hf_token() else "warn", "configured" if hf_token() else "HF_TOKEN not set (gated models will fail)"),
    ]
    try:
        r = httpx.head("https://huggingface.co", timeout=6, follow_redirects=True)
        checks.append(_check("huggingface_reachable", "pass" if r.status_code < 500 else "warn", f"HTTP {r.status_code}"))
    except Exception as exc:  # noqa: BLE001
        checks.append(_check("huggingface_reachable", "fail", type(exc).__name__))
    if body.load_models:
        import numpy as np
        from services import asr_service
        for code in sorted(manager.enabled_languages() & set(LANGUAGES)):
            try:
                out = asr_service.transcribe(code, np.zeros(16000, dtype=np.float32))
                checks.append(_check(f"asr_{code}", "pass", f"{out['model_repo']} loaded; silence inference ok"))
            except ApiError as exc:
                checks.append(_check(f"asr_{code}", "fail", f"{exc.error_code}: {exc.message}"))
    else:
        for code, info in manager.status()["asr"].items():
            checks.append(_check(f"asr_{code}", "pass" if info["loaded"] else "skip",
                                 "loaded" if info["loaded"] else "not loaded yet (loads on first use)"))
    overall = "fail" if any(c["status"] == "fail" for c in checks) else ("warn" if any(c["status"] == "warn" for c in checks) else "pass")
    return ok(request.state.request_id, overall=overall, checks=checks)
