import time

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field

from models.model_manager import LANGUAGES, normalise_language
from services import tts_service
from utils.logger import get_logger, log_request
from utils.responses import ok
from utils.security import verify_api_secret

router = APIRouter()
log = get_logger("arc_nbridge_ai.tts")


class TtsIn(BaseModel):
    language: str
    text: str = Field(..., max_length=2000)


@router.post("/tts", dependencies=[Depends(verify_api_secret)])
def tts(body: TtsIn, request: Request):
    request_id = request.state.request_id
    started = time.perf_counter()
    try:
        code = normalise_language(body.language)
        result = tts_service.synthesize(code, body.text)
        log_request(log, request_id, "tts", result["model"], "ok", time.perf_counter() - started)
        return ok(request_id, language=LANGUAGES[code].name, language_code=code, provider="local_mms",
                  audio_base64=result["audio_base64"], mime=result["mime"], sample_rate=result["sample_rate"],
                  model=result["model"], processing_time=result["processing_time"])
    except Exception as exc:
        log_request(log, request_id, "tts", "local_mms", "error", time.perf_counter() - started,
                    getattr(exc, "error_code", "INTERNAL_ERROR"))
        raise
