import time
from typing import Optional

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field

from models.model_manager import LANGUAGES, normalise_language
from services import translation_service
from utils.logger import get_logger, log_request
from utils.responses import ok
from utils.security import verify_api_secret

router = APIRouter()
log = get_logger("arc_nbridge_ai.translation")


class TranslateIn(BaseModel):
    source_language: str
    target_language: str
    text: str = Field(..., max_length=5000)
    engine: str = "nllb"
    mode: str = "direct"   # direct | pivot (source -> English -> target)
    request_id: Optional[str] = None


@router.post("/translate", dependencies=[Depends(verify_api_secret)])
def translate(body: TranslateIn, request: Request):
    request_id = request.state.request_id
    started = time.perf_counter()
    try:
        src, tgt = normalise_language(body.source_language), normalise_language(body.target_language)
        result = translation_service.translate(src, tgt, body.text, body.engine, body.mode)
        log_request(log, request_id, "translate", result["engine"], "ok", time.perf_counter() - started)
        return ok(request_id, source_language=LANGUAGES[src].name, target_language=LANGUAGES[tgt].name,
                  translation=result["translation"], pivot_text=result["pivot_text"], mode=result["mode"],
                  provider=result["engine"], model=result["model"], processing_time=result["processing_time"])
    except Exception as exc:
        log_request(log, request_id, "translate", body.engine, "error", time.perf_counter() - started,
                    getattr(exc, "error_code", "INTERNAL_ERROR"))
        raise
