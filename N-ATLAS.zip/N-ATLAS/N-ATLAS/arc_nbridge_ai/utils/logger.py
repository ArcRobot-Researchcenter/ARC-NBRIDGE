"""Application logger. Secrets (HF tokens, API keys, secrets in key=value form) are redacted."""
import logging
import os
import re
from logging.handlers import RotatingFileHandler

_PATTERNS = [
    re.compile(r"hf_[A-Za-z0-9]{10,}"),
    re.compile(r"(?i)(api[_-]?key|secret|token|authorization|password)\s*[=:]\s*\S+"),
]


class RedactFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        text = record.getMessage()
        for pattern in _PATTERNS:
            text = pattern.sub("[REDACTED]", text)
        record.msg, record.args = text, ()
        return True


_configured = False


def get_logger(name: str = "arc_nbridge_ai") -> logging.Logger:
    global _configured
    logger = logging.getLogger(name)
    if _configured:
        return logger
    level = getattr(logging, os.getenv("LOG_LEVEL", "INFO").upper(), logging.INFO)
    root = logging.getLogger("arc_nbridge_ai")
    root.setLevel(level)
    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s")
    stream = logging.StreamHandler()
    stream.setFormatter(fmt)
    stream.addFilter(RedactFilter())
    root.addHandler(stream)
    log_dir = os.getenv("LOG_DIR", "logs")
    try:
        os.makedirs(log_dir, exist_ok=True)
        file_handler = RotatingFileHandler(os.path.join(log_dir, "ai_service.log"), maxBytes=2_000_000,
                                           backupCount=3, encoding="utf-8")
        file_handler.setFormatter(fmt)
        file_handler.addFilter(RedactFilter())
        root.addHandler(file_handler)
    except OSError:
        root.warning("File logging disabled: cannot write to %s", log_dir)
    _configured = True
    return logger


def log_request(logger: logging.Logger, request_id: str, operation: str, provider: str, status: str,
                processing_time: float, error_code: str = "-") -> None:
    """Only non-sensitive fields: request id, operation, provider, status, time, error code."""
    logger.info("request_id=%s operation=%s provider=%s status=%s processing_time=%.3f error_code=%s",
                request_id, operation, provider, status, processing_time, error_code)
