"""PHP -> Python authentication via a shared secret in the X-API-Secret header."""
import hmac
import os
from typing import Optional

from fastapi import Header

from .errors import ApiError


def verify_api_secret(x_api_secret: Optional[str] = Header(default=None)) -> None:
    expected = os.getenv("AI_API_SECRET", "")
    if not expected:
        if os.getenv("ALLOW_NO_AUTH", "false").lower() == "true":
            return  # explicit local-development opt-out
        raise ApiError("AUTH_NOT_CONFIGURED", "The AI service has no AI_API_SECRET configured.", 503)
    if not x_api_secret or not hmac.compare_digest(x_api_secret.encode("utf-8"), expected.encode("utf-8")):
        raise ApiError("UNAUTHORIZED", "Invalid or missing API secret.", 401)


def hf_token() -> Optional[str]:
    """The Hugging Face token is read from the environment only and is never returned by any endpoint."""
    return os.getenv("HF_TOKEN") or None
