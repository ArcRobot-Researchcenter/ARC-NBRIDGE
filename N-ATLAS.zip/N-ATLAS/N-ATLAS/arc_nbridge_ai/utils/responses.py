"""Consistent JSON envelopes."""
import uuid
from typing import Any, Dict


def new_request_id() -> str:
    return uuid.uuid4().hex


def ok(request_id: str, **fields: Any) -> Dict[str, Any]:
    body: Dict[str, Any] = {"success": True, "request_id": request_id}
    body.update(fields)
    body.setdefault("error", None)
    return body


def fail(request_id: str, error_code: str, message: str, details: Any = None) -> Dict[str, Any]:
    return {"success": False, "request_id": request_id, "error_code": error_code, "message": message, "details": details}
