"""Structured API errors. Raised anywhere; converted to the standard JSON failure envelope in app.py."""
from typing import Any, Optional


class ApiError(Exception):
    def __init__(self, error_code: str, message: str, status_code: int = 400, details: Optional[Any] = None):
        super().__init__(message)
        self.error_code = error_code
        self.message = message
        self.status_code = status_code
        self.details = details
