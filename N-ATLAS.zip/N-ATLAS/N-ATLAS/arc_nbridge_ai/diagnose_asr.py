"""Diagnose a failing N-ATLaS ASR inference OUTSIDE the web server, and print the REAL exception.

Usage (from C:\\xampp\\htdocs\\N-ATLAS\\arc_nbridge_ai, with the same Python/venv that runs uvicorn):

    python diagnose_asr.py --language en --audio path\\to\\recording.webm

--audio is optional; without it a synthetic 6.1 s signal is used (enough to expose a pipeline/mechanics error,
but a real recording is better). Stop uvicorn first if RAM is tight: loading the model takes minutes on CPU.

Safety: this script runs in Hugging Face OFFLINE mode, so it cannot download or re-download anything. It uses the
exact same loader (models.model_manager) and the exact same call as services/asr_service.py. It adds no model and
no fallback; the extra steps only vary HOW the SAME loaded model is called, to localise the fault.
"""
import os

os.environ["HF_HUB_OFFLINE"] = "1"          # must be set before transformers/huggingface_hub are imported
os.environ["TRANSFORMERS_OFFLINE"] = "1"

import argparse  # noqa: E402
import platform  # noqa: E402
import sys  # noqa: E402
import time  # noqa: E402
import traceback  # noqa: E402

import numpy as np  # noqa: E402

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)


def banner(title: str) -> None:
    print("\n" + "=" * 78 + f"\n{title}\n" + "=" * 78, flush=True)


def attempt(label: str, fn):
    """Run fn(); print OK/FAIL with the full traceback. Returns (ok, value)."""
    started = time.perf_counter()
    try:
        value = fn()
        print(f"[OK]   {label}  ({time.perf_counter() - started:.2f}s)", flush=True)
        return True, value
    except BaseException as exc:  # noqa: BLE001 - this is a diagnostic tool, show everything
        print(f"[FAIL] {label}  ({time.perf_counter() - started:.2f}s)", flush=True)
        print(f"       exception type   : {type(exc).__module__}.{type(exc).__name__}")
        print(f"       exception message: {str(exc)[:1500]}")
        print("       --- full traceback ---")
        traceback.print_exc()
        return False, None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--language", default="en", help="ha | yo | ig | en (default en)")
    parser.add_argument("--audio", default=None, help="path to a recording (webm/wav/...)")
    args = parser.parse_args()

    banner("1. Environment")
    import importlib.metadata as md
    print("python      :", platform.python_version(), platform.platform())
    for pkg in ("torch", "transformers", "numpy", "soundfile", "accelerate", "huggingface_hub", "tokenizers"):
        try:
            print(f"{pkg:<12}:", md.version(pkg))
        except md.PackageNotFoundError:
            print(f"{pkg:<12}: NOT INSTALLED")
    try:
        import torch
        print("cuda        :", torch.cuda.is_available(), "| torch threads:", torch.get_num_threads())
    except Exception:  # noqa: BLE001
        traceback.print_exc()
    print("HF offline  :", os.environ.get("HF_HUB_OFFLINE"), "(no downloads possible)")

    from models.model_manager import manager, normalise_language
    from services import audio_service

    code = normalise_language(args.language)

    banner("2. Audio decode (same code path as the server)")
    if args.audio:
        with open(args.audio, "rb") as fh:
            raw_bytes = fh.read()
        ok, res = attempt(f"decode_audio({args.audio}, {len(raw_bytes)} bytes)", lambda: audio_service.decode_audio(raw_bytes))
        if not ok:
            print("\nThe fault is in AUDIO DECODING, not in the model. Stop here.")
            return 1
        audio, meta = res
    else:
        t = np.arange(int(6.1 * 16000)) / 16000.0
        rng = np.random.default_rng(0)
        audio = (0.1 * np.sin(2 * np.pi * 220 * t) + 0.01 * rng.standard_normal(len(t))).astype(np.float32)
        meta = {"duration_sec": 6.1, "note": "synthetic signal"}
    print("meta        :", meta)
    print("dtype/shape :", audio.dtype, audio.shape, "| min/max:", float(audio.min()), float(audio.max()),
          "| any NaN/Inf:", bool(np.isnan(audio).any() or np.isinf(audio).any()),
          "| C-contiguous/writeable:", audio.flags["C_CONTIGUOUS"], audio.flags["WRITEABLE"])

    banner(f"3. Load the model from the local cache (offline) - language={code}")
    ok, slot = attempt("manager.get_asr()", lambda: manager.get_asr(code))
    if not ok:
        print("\nThe model could not be loaded OFFLINE. If it loads inside uvicorn, the cache location differs "
              "between the two processes (HF_HOME / user account). Nothing has been downloaded.")
        return 1
    pipe = slot.obj
    print("repo        :", slot.repo)
    print("pipeline    :", type(pipe).__name__, "| model:", type(pipe.model).__name__,
          "| dtype:", getattr(pipe.model, "dtype", None), "| device:", getattr(pipe.model, "device", None))

    banner("4. Server call (generate_kwargs is only passed when non-empty)")
    ok, out = attempt('pipe({"raw": audio, "sampling_rate": 16000})',
                      lambda: pipe({"raw": audio, "sampling_rate": 16000}))
    if ok:
        print("result      :", repr(out)[:500])
        print("\nThe exact server call SUCCEEDS here. The failure is specific to the server process "
              "(threading/locks, audio from the browser, or state). Compare with the new server log entry.")
        return 0

    banner("5. Localising the fault (same loaded model, different ways of calling it)")
    attempt('pipe({"raw","sampling_rate"}) with NO generate_kwargs argument',
            lambda: pipe({"raw": audio, "sampling_rate": 16000}))
    attempt("pipe(audio) as a bare numpy array", lambda: pipe(audio))

    ok_fe, feats = attempt("feature_extractor(audio) -> input_features",
                           lambda: pipe.feature_extractor(audio, sampling_rate=16000, return_tensors="pt"))
    if ok_fe:
        import torch
        inp = feats["input_features"].to(device=pipe.model.device, dtype=pipe.model.dtype)
        print("input_features:", tuple(inp.shape), inp.dtype)
        ok_gen, ids = attempt("model.generate(input_features=...) with default settings",
                              lambda: pipe.model.generate(input_features=inp))
        if ok_gen:
            attempt("tokenizer.batch_decode(...)",
                    lambda: print("decoded     :", pipe.tokenizer.batch_decode(ids, skip_special_tokens=True)))
    print("\nSend me the full output above (everything from section 1 on).")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
