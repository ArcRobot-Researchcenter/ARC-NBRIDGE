"""ARC N-BRIDGE AI service (FastAPI). Run:  uvicorn app:app --host 127.0.0.1 --port 8000"""
import time

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

try:  # optional: load .env if python-dotenv is installed
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from api import asr, health, translation, tts  # noqa: E402
from utils.errors import ApiError  # noqa: E402
from utils.logger import get_logger  # noqa: E402
from utils.responses import fail, new_request_id  # noqa: E402

log = get_logger()
app = FastAPI(title="ARC N-BRIDGE AI Service", version=health.SERVICE_VERSION, docs_url=None, redoc_url=None)


@app.middleware("http")
async def request_context(request: Request, call_next):
    request.state.request_id = request.headers.get("x-request-id") or new_request_id()
    started = time.perf_counter()
    response = await call_next(request)
    response.headers["X-Request-ID"] = request.state.request_id
    response.headers["X-Process-Time"] = f"{time.perf_counter() - started:.3f}"
    return response


@app.exception_handler(ApiError)
async def api_error_handler(request: Request, exc: ApiError):
    return JSONResponse(status_code=exc.status_code, content=fail(request.state.request_id, exc.error_code, exc.message, exc.details))


@app.exception_handler(RequestValidationError)
async def validation_handler(request: Request, exc: RequestValidationError):
    fields = [{"field": ".".join(str(p) for p in e.get("loc", []) if p != "body"), "problem": e.get("type")} for e in exc.errors()]
    return JSONResponse(status_code=422, content=fail(request.state.request_id, "VALIDATION_ERROR", "The request is missing or has invalid fields.", fields))


@app.exception_handler(Exception)
async def unhandled_handler(request: Request, exc: Exception):
    log.exception("unhandled error request_id=%s", getattr(request.state, "request_id", "-"))  # traceback stays in the server log
    return JSONResponse(status_code=500, content=fail(getattr(request.state, "request_id", "-"), "INTERNAL_ERROR", "Unexpected AI service error."))


for module in (health, asr, translation, tts):
    app.include_router(module.router)
