import os
import time
import traceback
from typing import Any, Dict

import numpy as np

from models.model_manager import LANGUAGES, manager
from utils.errors import ApiError
from utils.logger import get_logger

log = get_logger("arc_nbridge_ai.asr")


def transcribe(code: str, audio: np.ndarray) -> Dict[str, Any]:
    slot = manager.get_asr(code)
    spec = LANGUAGES[code]
    generate_kwargs: Dict[str, Any] = {}
    # NOT VERIFIED: whether the N-ATLaS fine-tunes expect a forced Whisper language token. Off by default.
    forced = os.getenv("NATLAS_FORCE_WHISPER_LANGUAGE", "").strip()
    if forced:
        generate_kwargs = {"language": forced, "task": "transcribe"}
    started = time.perf_counter()
    # transformers 4.57.x: passing generate_kwargs=None raises TypeError inside the pipeline's
    # _sanitize_parameters (it does dict.update(None)). Only pass the argument when it has content.
    call_kwargs: Dict[str, Any] = {}
    if generate_kwargs:
        call_kwargs["generate_kwargs"] = generate_kwargs
    try:
        with slot.run_lock:
            result = slot.obj({"raw": audio, "sampling_rate": 16000}, **call_kwargs)
    except Exception as exc:  # noqa: BLE001
        # Diagnostic: record the REAL exception. The traceback is formatted into the message so the
        # logger's RedactFilter scrubs any token/secret before it reaches the console or log file.
        log.error("asr inference exception language=%s exc_type=%s exc_message=%s audio_dtype=%s audio_shape=%s "
                  "audio_min=%.4f audio_max=%.4f device=%s\n%s",
                  code, type(exc).__name__, str(exc)[:500], getattr(audio, "dtype", None),
                  getattr(audio, "shape", None), float(np.min(audio)) if len(audio) else 0.0,
                  float(np.max(audio)) if len(audio) else 0.0, getattr(getattr(slot.obj, "model", None), "device", None),
                  traceback.format_exc())
        raise ApiError("INFERENCE_FAILED", "The speech model failed while transcribing this audio.", 500,
                       {"exception": type(exc).__name__}) from exc
    elapsed = time.perf_counter() - started
    text = ((result.get("text") or "") if isinstance(result, dict) else str(result)).strip()
    return {"text": text, "processing_time": round(elapsed, 3), "model": spec.asr_label, "model_repo": slot.repo}
