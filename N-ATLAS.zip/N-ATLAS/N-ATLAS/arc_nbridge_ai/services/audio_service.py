"""Decode uploaded audio to 16 kHz mono float32 (the input format documented by the N-ATLaS ASR model cards)."""
import io
import os
import shutil
import subprocess
from typing import Tuple

import numpy as np

from utils.errors import ApiError

TARGET_SR = 16000


def max_upload_bytes() -> int:
    return int(float(os.getenv("MAX_UPLOAD_MB", "25")) * 1024 * 1024)


def max_audio_seconds() -> float:
    # The ASR model cards state a 30 second maximum per inference.
    return float(os.getenv("MAX_AUDIO_SECONDS", "30"))


def ffmpeg_available() -> bool:
    return shutil.which("ffmpeg") is not None


def _decode_ffmpeg(data: bytes) -> np.ndarray:
    try:
        proc = subprocess.run(
            ["ffmpeg", "-v", "error", "-i", "pipe:0", "-ac", "1", "-ar", str(TARGET_SR), "-f", "f32le", "pipe:1"],
            input=data, capture_output=True, timeout=60, check=False)
    except subprocess.TimeoutExpired as exc:
        raise ApiError("AUDIO_INVALID", "Audio decoding timed out.", 422) from exc
    if proc.returncode != 0 or not proc.stdout:
        raise ApiError("AUDIO_INVALID", "The audio file could not be decoded.", 422)
    return np.frombuffer(proc.stdout, dtype=np.float32).copy()


def _decode_soundfile(data: bytes) -> np.ndarray:
    try:
        import soundfile as sf
        samples, sr = sf.read(io.BytesIO(data), dtype="float32", always_2d=True)
    except Exception as exc:  # noqa: BLE001
        raise ApiError("AUDIO_INVALID",
                       "The audio file could not be decoded. Install ffmpeg to accept browser recordings (webm/m4a).",
                       422) from exc
    mono = samples.mean(axis=1)
    if sr != TARGET_SR:
        target_len = int(round(len(mono) * TARGET_SR / sr))
        mono = np.interp(np.linspace(0, len(mono) - 1, target_len), np.arange(len(mono)), mono).astype(np.float32)
    return mono


def decode_audio(data: bytes) -> Tuple[np.ndarray, dict]:
    if not data:
        raise ApiError("AUDIO_EMPTY", "The uploaded audio file is empty.", 422)
    if len(data) > max_upload_bytes():
        raise ApiError("FILE_TOO_LARGE", "The uploaded audio file exceeds the size limit.", 413)
    audio = _decode_ffmpeg(data) if ffmpeg_available() else _decode_soundfile(data)
    duration = len(audio) / TARGET_SR
    if duration < 0.2:
        raise ApiError("AUDIO_TOO_SHORT", "The recording is too short to transcribe.", 422)
    limit = max_audio_seconds()
    if duration > limit:
        raise ApiError("AUDIO_TOO_LONG", f"The recording is {duration:.1f}s; the maximum is {limit:.0f}s.", 422)
    rms = float(np.sqrt(np.mean(np.square(audio)))) if len(audio) else 0.0
    return audio, {"duration_sec": round(duration, 2), "rms": round(rms, 5), "low_energy": rms < 0.003}
