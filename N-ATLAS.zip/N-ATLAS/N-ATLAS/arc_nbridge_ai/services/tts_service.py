import base64
import io
import os
import time
from typing import Any, Dict

from models.model_manager import manager
from utils.errors import ApiError

MAX_CHARS = int(os.getenv("MAX_TTS_CHARS", "500"))


def synthesize(code: str, text: str) -> Dict[str, Any]:
    text = (text or "").strip()
    if not text:
        raise ApiError("TEXT_EMPTY", "There is no text to speak.", 422)
    if len(text) > MAX_CHARS:
        raise ApiError("TEXT_TOO_LONG", f"Text exceeds {MAX_CHARS} characters.", 422)
    import numpy as np
    import soundfile as sf
    import torch
    slot = manager.get_tts(code)
    tok, model = slot.obj["tokenizer"], slot.obj["model"]
    started = time.perf_counter()
    try:
        with slot.run_lock:
            inputs = tok(text, return_tensors="pt")
            inputs = {k: v.to(model.device) for k, v in inputs.items()}
            torch.manual_seed(int(os.getenv("TTS_SEED", "555")))  # VITS is stochastic; fixed seed aids reproducibility
            with torch.no_grad():
                wave = model(**inputs).waveform
    except Exception as exc:  # noqa: BLE001
        raise ApiError("TTS_FAILED", "The speech synthesis model failed.", 500, {"exception": type(exc).__name__}) from exc
    samples = wave.squeeze().cpu().numpy().astype(np.float32)
    buf = io.BytesIO()
    sf.write(buf, samples, int(model.config.sampling_rate), format="WAV", subtype="PCM_16")
    return {"audio_base64": base64.b64encode(buf.getvalue()).decode("ascii"), "mime": "audio/wav",
            "sample_rate": int(model.config.sampling_rate), "model": slot.repo,
            "processing_time": round(time.perf_counter() - started, 3)}
