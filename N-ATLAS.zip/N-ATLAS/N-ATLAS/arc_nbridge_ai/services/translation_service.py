import os
import time
from typing import Any, Dict

from models.model_manager import LANGUAGES, manager
from utils.errors import ApiError

ENGINES = ("nllb", "natlas_llm")
MAX_CHARS = int(os.getenv("MAX_TRANSLATION_CHARS", "1000"))


def _nllb(src: str, tgt: str, text: str) -> str:
    import torch
    slot = manager.get_nllb()
    tok, model = slot.obj["tokenizer"], slot.obj["model"]
    tok.src_lang = LANGUAGES[src].nllb_code
    with slot.run_lock:
        inputs = tok(text, return_tensors="pt")
        inputs = {k: v.to(model.device) for k, v in inputs.items()}
        with torch.no_grad():
            out = model.generate(**inputs, forced_bos_token_id=tok.convert_tokens_to_ids(LANGUAGES[tgt].nllb_code),
                                 max_new_tokens=int(os.getenv("MAX_NEW_TOKENS", "256")))
    return tok.batch_decode(out, skip_special_tokens=True)[0].strip()


def _llm(src: str, tgt: str, text: str) -> str:
    import torch
    slot = manager.get_llm()
    tok, model = slot.obj["tokenizer"], slot.obj["model"]
    # NOT VERIFIED: prompt wording is configurable because the best N-ATLaS translation prompt was not validated.
    template = os.getenv("NATLAS_TRANSLATION_PROMPT",
                         "Translate the following {src} text into {tgt}. Reply with the translation only.\n\n{text}")
    messages = [{"role": "system", "content": os.getenv("NATLAS_SYSTEM_PROMPT", "You are a careful translator.")},
                {"role": "user", "content": template.format(src=LANGUAGES[src].display, tgt=LANGUAGES[tgt].display, text=text)}]
    with slot.run_lock:
        enc = tok.apply_chat_template(messages, add_generation_prompt=True, return_tensors="pt", return_dict=True)
        enc = {k: v.to(model.device) for k, v in enc.items()}
        with torch.no_grad():
            out = model.generate(**enc, max_new_tokens=int(os.getenv("MAX_NEW_TOKENS", "256")), do_sample=False)
    new_tokens = out[0][enc["input_ids"].shape[1]:]
    return tok.decode(new_tokens, skip_special_tokens=True).strip()


def _single(engine: str, src: str, tgt: str, text: str) -> str:
    return _nllb(src, tgt, text) if engine == "nllb" else _llm(src, tgt, text)


def translate(src: str, tgt: str, text: str, engine: str, mode: str) -> Dict[str, Any]:
    text = (text or "").strip()
    if not text:
        raise ApiError("TEXT_EMPTY", "There is no text to translate.", 422)
    if len(text) > MAX_CHARS:
        raise ApiError("TEXT_TOO_LONG", f"Text exceeds {MAX_CHARS} characters.", 422)
    if src == tgt:
        raise ApiError("SAME_LANGUAGE", "Source and target language are the same.", 422)
    if engine not in ENGINES:
        raise ApiError("ENGINE_UNSUPPORTED", f"Unknown translation engine. Supported: {', '.join(ENGINES)}.", 422)
    if mode not in ("direct", "pivot"):
        raise ApiError("MODE_UNSUPPORTED", "mode must be 'direct' or 'pivot'.", 422)
    started = time.perf_counter()
    pivot_text = None
    try:
        if mode == "pivot" and "en" not in (src, tgt):
            pivot_text = _single(engine, src, "en", text)
            result = _single(engine, "en", tgt, pivot_text)
        else:
            mode = "direct"  # a pair that already involves English has no pivot step
            result = _single(engine, src, tgt, text)
    except ApiError:
        raise
    except Exception as exc:  # noqa: BLE001
        raise ApiError("TRANSLATION_FAILED", "The translation engine failed.", 500, {"exception": type(exc).__name__}) from exc
    model = manager.nllb_repo() if engine == "nllb" else manager.llm_repo()
    return {"translation": result, "pivot_text": pivot_text, "mode": mode, "engine": engine, "model": model,
            "processing_time": round(time.perf_counter() - started, 3)}
