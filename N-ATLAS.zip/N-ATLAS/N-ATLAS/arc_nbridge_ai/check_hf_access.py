"""Checks, repo by repo, whether your HF_TOKEN may download the gated N-ATLaS models.

Run from this folder (with the virtual environment active):
    python check_hf_access.py

It reads HF_TOKEN and the model names from your .env file. It never prints the token.
It only downloads each model's small config.json, not the model weights.
"""
import os
import sys

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

try:
    from huggingface_hub import HfApi, hf_hub_download
    from huggingface_hub.utils import GatedRepoError, RepositoryNotFoundError
except ImportError:
    sys.exit("huggingface_hub is not installed. Run: pip install -r requirements.txt")

token = os.environ.get("HF_TOKEN", "").strip()
if not token:
    sys.exit("HF_TOKEN is empty or missing. Check that the file is named .env (not .env.example) and that you restarted.")

try:
    who = HfApi().whoami(token=token)
except Exception as exc:  # noqa: BLE001
    sys.exit(f"The token was rejected by Hugging Face ({type(exc).__name__}). Create a new token at https://huggingface.co/settings/tokens")

account = who.get("name", "?")
access = (who.get("auth") or {}).get("accessToken") or {}
role = access.get("role", "unknown")
print(f"Token belongs to account: {account}")
print(f"Token type: {role}")
if role == "fineGrained":
    print("  NOTE: this is a fine-grained token. It must have the permission\n"
          "  'Read access to contents of all public gated repos you can access' switched on,\n"
          "  otherwise gated models are refused even after you accept their terms.")
print()

repos = {
    "Hausa ASR": os.environ.get("NATLAS_HAUSA_MODEL", "NCAIR1/Hausa-ASR"),
    "Yoruba ASR": os.environ.get("NATLAS_YORUBA_MODEL", "NCAIR1/Yoruba-ASR"),
    "Igbo ASR": os.environ.get("NATLAS_IGBO_MODEL", "NCAIR1/Igbo-ASR"),
    "Nigerian English ASR": os.environ.get("NATLAS_ENGLISH_MODEL", "NCAIR1/NigerianAccentedEnglish"),
}

denied = []
for label, repo in repos.items():
    try:
        hf_hub_download(repo, "config.json", token=token)
        print(f"  OK       {label}: {repo}")
    except GatedRepoError:
        print(f"  DENIED   {label}: {repo}")
        denied.append(repo)
    except RepositoryNotFoundError:
        print(f"  NOT FOUND {label}: {repo}  (wrong name, or no access)")
        denied.append(repo)
    except Exception as exc:  # noqa: BLE001
        print(f"  ERROR    {label}: {repo}  ({type(exc).__name__}: {str(exc)[:120]})")

print()
if denied:
    print(f"Open each DENIED page while logged in as '{account}' and accept the terms:")
    for repo in denied:
        print(f"  https://huggingface.co/{repo}")
    print("Approval can take a moment. Then run this script again.")
else:
    print("All listed models are accessible. Restart the service and try the Evaluation Lab again.")
