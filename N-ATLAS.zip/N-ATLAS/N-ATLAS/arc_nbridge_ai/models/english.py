from .spec import LanguageSpec

# NOT VERIFIED: the MMS English TTS repo id below was not checked against the Hub in this build.
# If it cannot be loaded, /models and /system-test report it honestly; override with TTS_ENGLISH_MODEL.
SPEC = LanguageSpec("en", "english", "Nigerian-accented English", "NATLAS_ENGLISH_MODEL",
                    "NCAIR1/NigerianAccentedEnglish", "N-ATLaS Nigerian English ASR",
                    "eng_Latn", "TTS_ENGLISH_MODEL", "facebook/mms-tts-eng")
