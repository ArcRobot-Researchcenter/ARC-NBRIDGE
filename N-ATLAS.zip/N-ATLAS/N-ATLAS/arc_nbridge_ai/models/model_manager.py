"""Loads each model once per service session and caches it. Heavy libraries are imported lazily so the
service (and its health endpoints) still starts on a machine without torch/transformers."""
import os
import threading
import time
from typing import Any, Dict, Optional

from utils.errors import ApiError
from utils.logger import get_logger
from utils.security import hf_token

from . import english, hausa, igbo, yoruba

log = get_logger("arc_nbridge_ai.models")

LANGUAGES = {s.code: s for s in (hausa.SPEC, yoruba.SPEC, igbo.SPEC, english.SPEC)}
_ALIASES = {
    "ha": "ha", "hausa": "ha", "yo": "yo", "yoruba": "yo", "yorùbá": "yo", "ig": "ig", "igbo": "ig",
    "en": "en", "english": "en", "nigerian_english": "en", "nigerian-english": "en",
    "nigerian_accented_english": "en", "nigerian english": "en",
}


def normalise_language(value: str) -> str:
    code = _ALIASES.get((value or "").strip().lower())
    if not code:
        raise ApiError("LANGUAGE_UNSUPPORTED", f"Unsupported language. Supported: {', '.join(sorted(LANGUAGES))}.", 422)
    return code


def _require_torch():
    try:
        import torch  # noqa: F401
        import transformers  # noqa: F401
    except ImportError as exc:
        raise ApiError("DEPENDENCY_MISSING",
                       "AI libraries (torch / transformers) are not installed in this Python environment.", 503,
                       {"missing": exc.name}) from exc


def _load_error(exc: Exception, repo: str) -> ApiError:
    text = str(exc).lower()
    log.error("model load failed repo=%s error_type=%s", repo, type(exc).__name__)
    if any(k in text for k in ("401", "403", "gated", "restricted", "access to model", "authorized")):
        return ApiError("MODEL_ACCESS_DENIED",
                        "Access to the model was denied. Accept its terms on Hugging Face with the account that owns "
                        "HF_TOKEN, then restart the service.", 503, {"repo": repo})
    return ApiError("MODEL_LOAD_FAILED", "The model could not be loaded. Check the AI service log.", 503,
                    {"repo": repo, "exception": type(exc).__name__})


def _not_downloaded(repo: str) -> ApiError:
    return ApiError("MODEL_NOT_DOWNLOADED",
                    f"The model {repo} is not downloaded on this machine, and downloads are switched off. "
                    "Set ALLOW_MODEL_DOWNLOAD=true in the AI service .env and restart (this can download several GB), "
                    "or run the AI service on Google Colab where the connection is fast (see docs/COLAB_SETUP.md).",
                    503, {"repo": repo})


class _Slot:
    """One cached model with its own load lock and inference lock."""

    def __init__(self, repo: str):
        self.repo = repo
        self.obj: Any = None
        self.load_lock = threading.Lock()
        self.run_lock = threading.Lock()
        self.loaded_at: Optional[float] = None
        self.load_seconds: Optional[float] = None
        self.last_error: Optional[str] = None


class ModelManager:
    def __init__(self) -> None:
        self._slots: Dict[str, _Slot] = {}
        self._guard = threading.Lock()

    # ------------------------------------------------------------------ config
    @staticmethod
    def enabled_languages() -> set:
        raw = os.getenv("NATLAS_ENABLED_LANGUAGES", "ha,yo,ig,en")
        return {c.strip() for c in raw.split(",") if c.strip()}

    @staticmethod
    def asr_repo(code: str) -> str:
        spec = LANGUAGES[code]
        return os.getenv(spec.asr_env) or spec.asr_default

    @staticmethod
    def tts_repo(code: str) -> str:
        spec = LANGUAGES[code]
        return os.getenv(spec.tts_env) or spec.tts_default

    @staticmethod
    def nllb_repo() -> str:
        return os.getenv("NLLB_MODEL", "facebook/nllb-200-distilled-600M")

    @staticmethod
    def llm_repo() -> str:
        return os.getenv("NATLAS_MODEL", "NCAIR1/N-ATLaS")

    @staticmethod
    def downloads_allowed() -> bool:
        """Translation and TTS models are only downloaded when this is explicitly enabled (ASR models are not affected)."""
        return os.getenv("ALLOW_MODEL_DOWNLOAD", "false").lower() == "true"

    def _hub_kwargs(self) -> Dict[str, Any]:
        kw: Dict[str, Any] = {"token": hf_token()}
        if not self.downloads_allowed():
            kw["local_files_only"] = True
        return kw

    @staticmethod
    def llm_enabled() -> bool:
        return os.getenv("ENABLE_NATLAS_LLM", "false").lower() == "true"

    # ------------------------------------------------------------------- slots
    def _slot(self, key: str, repo: str) -> _Slot:
        with self._guard:
            slot = self._slots.get(key)
            if slot is None or slot.repo != repo:
                slot = _Slot(repo)
                self._slots[key] = slot
            return slot

    def _ensure(self, key: str, repo: str, loader, offline_guard: bool = False) -> _Slot:
        slot = self._slot(key, repo)
        if slot.obj is not None:
            return slot
        with slot.load_lock:
            if slot.obj is None:
                _require_torch()
                started = time.perf_counter()
                try:
                    slot.obj = loader(repo)
                except ApiError:
                    raise
                except Exception as exc:  # noqa: BLE001 - converted to a structured error
                    slot.last_error = type(exc).__name__
                    if offline_guard and not self.downloads_allowed() and isinstance(exc, OSError):
                        slot.last_error = "MODEL_NOT_DOWNLOADED"
                        raise _not_downloaded(repo) from exc
                    raise _load_error(exc, repo) from exc
                slot.load_seconds = round(time.perf_counter() - started, 2)
                slot.loaded_at = time.time()
                slot.last_error = None
                log.info("model loaded key=%s repo=%s seconds=%s", key, repo, slot.load_seconds)
        return slot

    @staticmethod
    def _device_index() -> int:
        import torch
        return 0 if torch.cuda.is_available() else -1

    # --------------------------------------------------------------------- ASR
    def get_asr(self, code: str) -> _Slot:
        if code not in self.enabled_languages():
            raise ApiError("MODEL_DISABLED", f"The {LANGUAGES[code].display} model is disabled in the AI service.", 503)

        def loader(repo: str):
            import torch
            from transformers import pipeline
            kwargs: Dict[str, Any] = {"model": repo, "device": self._device_index()}
            if hf_token():
                kwargs["token"] = hf_token()
            if torch.cuda.is_available():
                kwargs["torch_dtype"] = torch.float16
            return pipeline("automatic-speech-recognition", **kwargs)

        return self._ensure(f"asr:{code}", self.asr_repo(code), loader)

    # ------------------------------------------------------------- translation
    def get_nllb(self) -> _Slot:
        def loader(repo: str):
            from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
            kw = self._hub_kwargs()
            tok = AutoTokenizer.from_pretrained(repo, **kw)
            model = AutoModelForSeq2SeqLM.from_pretrained(repo, **kw)
            if self._device_index() >= 0:
                model = model.to("cuda")
            return {"tokenizer": tok, "model": model}

        return self._ensure("translate:nllb", self.nllb_repo(), loader, offline_guard=True)

    def get_llm(self) -> _Slot:
        if not self.llm_enabled():
            raise ApiError("MODEL_DISABLED", "The N-ATLaS LLM is disabled (set ENABLE_NATLAS_LLM=true; it needs a GPU).", 503)

        def loader(repo: str):
            import torch
            from transformers import AutoModelForCausalLM, AutoTokenizer
            kw = self._hub_kwargs()
            tok = AutoTokenizer.from_pretrained(repo, **kw)
            dtype = torch.bfloat16 if torch.cuda.is_available() else torch.float32
            model = AutoModelForCausalLM.from_pretrained(repo, torch_dtype=dtype, device_map="auto", **kw)
            return {"tokenizer": tok, "model": model}

        return self._ensure("translate:natlas_llm", self.llm_repo(), loader, offline_guard=True)

    # --------------------------------------------------------------------- TTS
    def get_tts(self, code: str) -> _Slot:
        def loader(repo: str):
            from transformers import AutoTokenizer, VitsModel
            kw = self._hub_kwargs()
            tok = AutoTokenizer.from_pretrained(repo, **kw)
            model = VitsModel.from_pretrained(repo, **kw)
            if self._device_index() >= 0:
                model = model.to("cuda")
            return {"tokenizer": tok, "model": model}

        return self._ensure(f"tts:{code}", self.tts_repo(code), loader, offline_guard=True)

    # ------------------------------------------------------------------ status
    def status(self) -> Dict[str, Any]:
        def info(key: str, repo: str, **extra: Any) -> Dict[str, Any]:
            slot = self._slots.get(key)
            data = {"repo": repo, "loaded": bool(slot and slot.obj is not None),
                    "load_seconds": slot.load_seconds if slot else None,
                    "last_error": slot.last_error if slot else None}
            data.update(extra)
            return data

        enabled = self.enabled_languages()
        return {
            "downloads_allowed": self.downloads_allowed(),
            "asr": {c: info(f"asr:{c}", self.asr_repo(c), enabled=c in enabled, label=s.asr_label)
                    for c, s in LANGUAGES.items()},
            "translation": {
                "nllb": info("translate:nllb", self.nllb_repo(), enabled=True),
                "natlas_llm": info("translate:natlas_llm", self.llm_repo(), enabled=self.llm_enabled()),
            },
            "tts": {c: info(f"tts:{c}", self.tts_repo(c), enabled=True) for c in LANGUAGES},
        }


manager = ModelManager()
