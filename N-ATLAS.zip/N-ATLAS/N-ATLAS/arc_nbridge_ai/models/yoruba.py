from .spec import LanguageSpec

SPEC = LanguageSpec("yo", "yoruba", "Yoruba", "NATLAS_YORUBA_MODEL", "NCAIR1/Yoruba-ASR", "N-ATLaS Yoruba-ASR",
                    "yor_Latn", "TTS_YORUBA_MODEL", "facebook/mms-tts-yor")
