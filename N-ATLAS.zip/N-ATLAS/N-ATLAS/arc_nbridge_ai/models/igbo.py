from .spec import LanguageSpec

SPEC = LanguageSpec("ig", "igbo", "Igbo", "NATLAS_IGBO_MODEL", "NCAIR1/Igbo-ASR", "N-ATLaS Igbo-ASR",
                    "ibo_Latn", "TTS_IGBO_MODEL", "facebook/mms-tts-ibo")
