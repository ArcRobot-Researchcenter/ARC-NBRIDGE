"""Static description of a supported language. Repo IDs are DEFAULTS; environment variables override them."""
from dataclasses import dataclass


@dataclass(frozen=True)
class LanguageSpec:
    code: str            # ISO 639-1 used across the whole platform
    name: str            # lower-case API name
    display: str
    asr_env: str         # env var that overrides the ASR repo
    asr_default: str     # official N-ATLaS ASR repo (verified on Hugging Face, gated)
    asr_label: str
    nllb_code: str       # FLORES-200 code used by NLLB-style translation engines
    tts_env: str
    tts_default: str     # MMS-TTS checkpoint; availability is checked at runtime, never assumed
