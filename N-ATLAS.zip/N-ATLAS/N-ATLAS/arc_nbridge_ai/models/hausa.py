from .spec import LanguageSpec

SPEC = LanguageSpec("ha", "hausa", "Hausa", "NATLAS_HAUSA_MODEL", "NCAIR1/Hausa-ASR", "N-ATLaS Hausa-ASR",
                    "hau_Latn", "TTS_HAUSA_MODEL", "facebook/mms-tts-hau")
